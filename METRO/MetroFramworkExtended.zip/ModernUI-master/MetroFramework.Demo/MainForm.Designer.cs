﻿namespace MetroFramework.Demo
{
    partial class MainForm
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            this.metroTabControl1 = new MetroFramework.Controls.MetroTabControl();
            this.metroTabPage1 = new MetroFramework.Controls.MetroTabPage();
            this.metroButtonStyled1 = new MetroFramework.Controls.MetroButtonStyled();
            this.metroStyleManager = new MetroFramework.Components.MetroStyleManager(this.components);
            this.metroSplitButton1 = new MetroFramework.Controls.MetroSplitButton();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.entry1ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.entry2ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.entry3ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.metroToggle4 = new MetroFramework.Controls.MetroToggle();
            this.metroLabel29 = new MetroFramework.Controls.MetroLabel();
            this.mlSelectedTheme = new MetroFramework.Controls.MetroLabel();
            this.metroLabel23 = new MetroFramework.Controls.MetroLabel();
            this.mlSelectedColor = new MetroFramework.Controls.MetroLabel();
            this.metroLabel21 = new MetroFramework.Controls.MetroLabel();
            this.metroLink4 = new MetroFramework.Controls.MetroLink();
            this.metroLink3 = new MetroFramework.Controls.MetroLink();
            this.metroLabel9 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.metroLink1 = new MetroFramework.Controls.MetroLink();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroButton3 = new MetroFramework.Controls.MetroButton();
            this.metroButton2 = new MetroFramework.Controls.MetroButton();
            this.metroButton1 = new MetroFramework.Controls.MetroButton();
            this.metroTileSwitch = new MetroFramework.Controls.MetroTile();
            this.metroTile2 = new MetroFramework.Controls.MetroTile();
            this.metroTile1 = new MetroFramework.Controls.MetroTile();
            this.metroTabPage4 = new MetroFramework.Controls.MetroTabPage();
            this.metroTextBox4 = new MetroFramework.Controls.MetroTextBox();
            this.metroTextBox3 = new MetroFramework.Controls.MetroTextBox();
            this.metroTextBox2 = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel15 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel12 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel13 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel14 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel11 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel10 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroTextBox1 = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroTabPage2 = new MetroFramework.Controls.MetroTabPage();
            this.metroDateTime1 = new MetroFramework.Controls.MetroDateTime();
            this.metroLabel24 = new MetroFramework.Controls.MetroLabel();
            this.metroComboBox2 = new MetroFramework.Controls.MetroComboBox();
            this.metroToggle3 = new MetroFramework.Controls.MetroToggle();
            this.metroToggle2 = new MetroFramework.Controls.MetroToggle();
            this.metroRadioButton3 = new MetroFramework.Controls.MetroRadioButton();
            this.metroRadioButton2 = new MetroFramework.Controls.MetroRadioButton();
            this.metroCheckBox3 = new MetroFramework.Controls.MetroCheckBox();
            this.metroCheckBox2 = new MetroFramework.Controls.MetroCheckBox();
            this.metroLabel19 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel18 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel17 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel16 = new MetroFramework.Controls.MetroLabel();
            this.metroComboBox1 = new MetroFramework.Controls.MetroComboBox();
            this.metroRadioButton1 = new MetroFramework.Controls.MetroRadioButton();
            this.metroToggle1 = new MetroFramework.Controls.MetroToggle();
            this.metroCheckBox1 = new MetroFramework.Controls.MetroCheckBox();
            this.metroTabPage3 = new MetroFramework.Controls.MetroTabPage();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.metroProgressSpinner3 = new MetroFramework.Controls.MetroProgressSpinner();
            this.metroProgressSpinner2 = new MetroFramework.Controls.MetroProgressSpinner();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.metroProgressBar1 = new MetroFramework.Controls.MetroProgressBar();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.metroScrollBar1 = new MetroFramework.Controls.MetroScrollBar();
            this.metroTrackBar1 = new MetroFramework.Controls.MetroTrackBar();
            this.metroProgressSpinner1 = new MetroFramework.Controls.MetroProgressSpinner();
            this.metroProgressBar = new MetroFramework.Controls.MetroProgressBar();
            this.metroTabPage6 = new MetroFramework.Controls.MetroTabPage();
            this.metroLabel26 = new MetroFramework.Controls.MetroLabel();
            this.metroButton6 = new MetroFramework.Controls.MetroButton();
            this.metroLabel20 = new MetroFramework.Controls.MetroLabel();
            this.metroPanel3 = new MetroFramework.Controls.MetroPanel();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripProgressBar1 = new System.Windows.Forms.ToolStripProgressBar();
            this.toolStripDropDownButton1 = new System.Windows.Forms.ToolStripDropDownButton();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripDropDownButton2 = new System.Windows.Forms.ToolStripDropDownButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.menuStrip3 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.metroLabel22 = new MetroFramework.Controls.MetroLabel();
            this.metroButton4 = new MetroFramework.Controls.MetroButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.metroTabPage5 = new MetroFramework.Controls.MetroTabPage();
            this.splitContainer1 = new MetroFramework.Controls.MetroSplitContainer();
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.metroLabel25 = new MetroFramework.Controls.MetroLabel();
            this.metroPanel2 = new MetroFramework.Controls.MetroPanel();
            this.metroGrid1 = new MetroFramework.Controls.MetroGrid();
            this.metroTabPage7 = new MetroFramework.Controls.MetroTabPage();
            this.metroSplitContainer1 = new MetroFramework.Controls.MetroSplitContainer();
            this.metroPropertyGrid1 = new MetroFramework.Controls.MetroPropertyGrid();
            this.metroGroupBox1 = new MetroFramework.Controls.MetroGroupBox();
            this.metroDomainUpDown1 = new MetroFramework.Controls.MetroDomainUpDown();
            this.metroLabel27 = new MetroFramework.Controls.MetroLabel();
            this.metroNumericUpDown1 = new MetroFramework.Controls.MetroNumericUpDown();
            this.metroSplitContainer2 = new MetroFramework.Controls.MetroSplitContainer();
            this.metroSplitContainer3 = new MetroFramework.Controls.MetroSplitContainer();
            this.metroPanel4 = new MetroFramework.Controls.MetroPanel();
            this.metroLabel30 = new MetroFramework.Controls.MetroLabel();
            this.lblKnobValue = new MetroFramework.Controls.MetroLabel();
            this.metroLabel28 = new MetroFramework.Controls.MetroLabel();
            this.metroKnobControl1 = new MetroFramework.Controls.MetroKnobControl();
            this.metroSplitContainer4 = new MetroFramework.Controls.MetroSplitContainer();
            this.metroGroupBox3 = new MetroFramework.Controls.MetroGroupBox();
            this.metroPanel5 = new MetroFramework.Controls.MetroPanel();
            this.metroToolTip = new MetroFramework.Components.MetroToolTip();
            this.entry1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.entry2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.entry3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripTextBox1 = new System.Windows.Forms.ToolStripTextBox();
            this.rendererManager1 = new MetroFramework.Components.MetroRendererManager(this.components);
            this.metroTabControl1.SuspendLayout();
            this.metroTabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.metroStyleManager)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.metroTabPage4.SuspendLayout();
            this.metroTabPage2.SuspendLayout();
            this.metroTabPage3.SuspendLayout();
            this.metroTabPage6.SuspendLayout();
            this.metroPanel3.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.menuStrip3.SuspendLayout();
            this.metroTabPage5.SuspendLayout();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.metroPanel1.SuspendLayout();
            this.metroPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid1)).BeginInit();
            this.metroTabPage7.SuspendLayout();
            this.metroSplitContainer1.Panel1.SuspendLayout();
            this.metroSplitContainer1.Panel2.SuspendLayout();
            this.metroSplitContainer1.SuspendLayout();
            this.metroGroupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.metroNumericUpDown1)).BeginInit();
            this.metroSplitContainer2.Panel1.SuspendLayout();
            this.metroSplitContainer2.Panel2.SuspendLayout();
            this.metroSplitContainer2.SuspendLayout();
            this.metroSplitContainer3.Panel1.SuspendLayout();
            this.metroSplitContainer3.Panel2.SuspendLayout();
            this.metroSplitContainer3.SuspendLayout();
            this.metroPanel4.SuspendLayout();
            this.metroSplitContainer4.Panel1.SuspendLayout();
            this.metroSplitContainer4.Panel2.SuspendLayout();
            this.metroSplitContainer4.SuspendLayout();
            this.SuspendLayout();
            // 
            // metroTabControl1
            // 
            this.metroTabControl1.Controls.Add(this.metroTabPage1);
            this.metroTabControl1.Controls.Add(this.metroTabPage4);
            this.metroTabControl1.Controls.Add(this.metroTabPage2);
            this.metroTabControl1.Controls.Add(this.metroTabPage3);
            this.metroTabControl1.Controls.Add(this.metroTabPage6);
            this.metroTabControl1.Controls.Add(this.metroTabPage5);
            this.metroTabControl1.Controls.Add(this.metroTabPage7);
            this.metroTabControl1.CustomBackground = false;
            this.metroTabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroTabControl1.FontSize = MetroFramework.MetroTabControlSize.Medium;
            this.metroTabControl1.FontWeight = MetroFramework.MetroTabControlWeight.Light;
            this.metroTabControl1.HotTrack = true;
            this.metroTabControl1.Location = new System.Drawing.Point(20, 60);
            this.metroTabControl1.Name = "metroTabControl1";
            this.metroTabControl1.SelectedIndex = 0;
            this.metroTabControl1.Size = new System.Drawing.Size(676, 364);
            this.metroTabControl1.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTabControl1.StyleManager = this.metroStyleManager;
            this.metroTabControl1.TabIndex = 0;
            this.metroTabControl1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.metroTabControl1.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTabControl1.UseStyleColors = false;
            // 
            // metroTabPage1
            // 
            this.metroTabPage1.AutoScroll = true;
            this.metroTabPage1.Controls.Add(this.metroButtonStyled1);
            this.metroTabPage1.Controls.Add(this.metroSplitButton1);
            this.metroTabPage1.Controls.Add(this.metroToggle4);
            this.metroTabPage1.Controls.Add(this.metroLabel29);
            this.metroTabPage1.Controls.Add(this.mlSelectedTheme);
            this.metroTabPage1.Controls.Add(this.metroLabel23);
            this.metroTabPage1.Controls.Add(this.mlSelectedColor);
            this.metroTabPage1.Controls.Add(this.metroLabel21);
            this.metroTabPage1.Controls.Add(this.metroLink4);
            this.metroTabPage1.Controls.Add(this.metroLink3);
            this.metroTabPage1.Controls.Add(this.metroLabel9);
            this.metroTabPage1.Controls.Add(this.metroLabel8);
            this.metroTabPage1.Controls.Add(this.metroLink1);
            this.metroTabPage1.Controls.Add(this.metroLabel1);
            this.metroTabPage1.Controls.Add(this.metroButton3);
            this.metroTabPage1.Controls.Add(this.metroButton2);
            this.metroTabPage1.Controls.Add(this.metroButton1);
            this.metroTabPage1.Controls.Add(this.metroTileSwitch);
            this.metroTabPage1.Controls.Add(this.metroTile2);
            this.metroTabPage1.Controls.Add(this.metroTile1);
            this.metroTabPage1.CustomBackground = false;
            this.metroTabPage1.HorizontalScrollbar = true;
            this.metroTabPage1.HorizontalScrollbarBarColor = true;
            this.metroTabPage1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage1.HorizontalScrollbarSize = 10;
            this.metroTabPage1.Location = new System.Drawing.Point(4, 35);
            this.metroTabPage1.Name = "metroTabPage1";
            this.metroTabPage1.Padding = new System.Windows.Forms.Padding(25);
            this.metroTabPage1.Size = new System.Drawing.Size(668, 325);
            this.metroTabPage1.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTabPage1.StyleManager = this.metroStyleManager;
            this.metroTabPage1.TabIndex = 0;
            this.metroTabPage1.Tag = false;
            this.metroTabPage1.Text = "Tiles && Buttons";
            this.metroTabPage1.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTabPage1.VerticalScrollbar = true;
            this.metroTabPage1.VerticalScrollbarBarColor = true;
            this.metroTabPage1.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage1.VerticalScrollbarSize = 10;
            // 
            // metroButtonStyled1
            // 
            this.metroButtonStyled1.FlatAppearance = false;
            this.metroButtonStyled1.FontSize = MetroFramework.MetroButtonSize.Medium;
            this.metroButtonStyled1.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.metroButtonStyled1.Highlight = false;
            this.metroButtonStyled1.Image = global::MetroFramework.Demo.Properties.Resources.color_swatch;
            this.metroButtonStyled1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.metroButtonStyled1.Location = new System.Drawing.Point(331, 219);
            this.metroButtonStyled1.Name = "metroButtonStyled1";
            this.metroButtonStyled1.Size = new System.Drawing.Size(127, 37);
            this.metroButtonStyled1.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroButtonStyled1.StyleManager = this.metroStyleManager;
            this.metroButtonStyled1.TabIndex = 24;
            this.metroButtonStyled1.Text = "  Styled Button";
            this.metroButtonStyled1.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroButtonStyled1.UseVisualStyleBackColor = true;
            // 
            // metroStyleManager
            // 
            this.metroStyleManager.Owner = this;
            // 
            // metroSplitButton1
            // 
            this.metroSplitButton1.AutoSize = true;
            this.metroSplitButton1.ContextMenuStrip = this.contextMenuStrip1;
            this.metroSplitButton1.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroSplitButton1.FontSize = MetroFramework.MetroButtonSize.Medium;
            this.metroSplitButton1.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.metroSplitButton1.Highlight = false;
            this.metroSplitButton1.Location = new System.Drawing.Point(331, 176);
            this.metroSplitButton1.Name = "metroSplitButton1";
            this.metroSplitButton1.Size = new System.Drawing.Size(127, 37);
            this.metroSplitButton1.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroSplitButton1.StyleManager = this.metroStyleManager;
            this.metroSplitButton1.TabIndex = 23;
            this.metroSplitButton1.Text = "SplitButton1";
            this.metroSplitButton1.Theme = MetroFramework.MetroThemeStyle.Light;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.entry1ToolStripMenuItem1,
            this.entry2ToolStripMenuItem1,
            this.entry3ToolStripMenuItem1});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(111, 70);
            // 
            // entry1ToolStripMenuItem1
            // 
            this.entry1ToolStripMenuItem1.Name = "entry1ToolStripMenuItem1";
            this.entry1ToolStripMenuItem1.Size = new System.Drawing.Size(110, 22);
            this.entry1ToolStripMenuItem1.Text = "Entry 1";
            // 
            // entry2ToolStripMenuItem1
            // 
            this.entry2ToolStripMenuItem1.Name = "entry2ToolStripMenuItem1";
            this.entry2ToolStripMenuItem1.Size = new System.Drawing.Size(110, 22);
            this.entry2ToolStripMenuItem1.Text = "Entry 2";
            // 
            // entry3ToolStripMenuItem1
            // 
            this.entry3ToolStripMenuItem1.Name = "entry3ToolStripMenuItem1";
            this.entry3ToolStripMenuItem1.Size = new System.Drawing.Size(110, 22);
            this.entry3ToolStripMenuItem1.Text = "Entry 3";
            // 
            // metroToggle4
            // 
            this.metroToggle4.AutoSize = true;
            this.metroToggle4.Checked = true;
            this.metroToggle4.CheckState = System.Windows.Forms.CheckState.Checked;
            this.metroToggle4.CustomBackground = false;
            this.metroToggle4.DisplayStatus = true;
            this.metroToggle4.FontSize = MetroFramework.MetroLinkSize.Small;
            this.metroToggle4.FontWeight = MetroFramework.MetroLinkWeight.Regular;
            this.metroToggle4.Location = new System.Drawing.Point(28, 266);
            this.metroToggle4.Name = "metroToggle4";
            this.metroToggle4.Size = new System.Drawing.Size(80, 17);
            this.metroToggle4.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroToggle4.StyleManager = this.metroStyleManager;
            this.metroToggle4.TabIndex = 22;
            this.metroToggle4.Text = "On";
            this.metroToggle4.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroToolTip.SetToolTip(this.metroToggle4, "MetroTabControl Hot Track Enable Status");
            this.metroToggle4.UseStyleColors = false;
            this.metroToggle4.UseVisualStyleBackColor = true;
            this.metroToggle4.CheckedChanged += new System.EventHandler(this.metroToggle4_CheckedChanged);
            // 
            // metroLabel29
            // 
            this.metroLabel29.AutoSize = true;
            this.metroLabel29.CustomBackground = false;
            this.metroLabel29.FontSize = MetroFramework.MetroLabelSize.Medium;
            this.metroLabel29.FontWeight = MetroFramework.MetroLabelWeight.Light;
            this.metroLabel29.LabelMode = MetroFramework.Controls.MetroLabelMode.Default;
            this.metroLabel29.Location = new System.Drawing.Point(28, 245);
            this.metroLabel29.Name = "metroLabel29";
            this.metroLabel29.Size = new System.Drawing.Size(178, 19);
            this.metroLabel29.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroLabel29.StyleManager = this.metroStyleManager;
            this.metroLabel29.TabIndex = 20;
            this.metroLabel29.Text = "MetroTabControl Hot Track: ";
            this.metroLabel29.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroLabel29.UseStyleColors = false;
            // 
            // mlSelectedTheme
            // 
            this.mlSelectedTheme.AutoSize = true;
            this.mlSelectedTheme.CustomBackground = false;
            this.mlSelectedTheme.FontSize = MetroFramework.MetroLabelSize.Medium;
            this.mlSelectedTheme.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.mlSelectedTheme.LabelMode = MetroFramework.Controls.MetroLabelMode.Default;
            this.mlSelectedTheme.Location = new System.Drawing.Point(512, 195);
            this.mlSelectedTheme.Name = "mlSelectedTheme";
            this.mlSelectedTheme.Size = new System.Drawing.Size(115, 19);
            this.mlSelectedTheme.Style = MetroFramework.MetroColorStyle.Blue;
            this.mlSelectedTheme.StyleManager = this.metroStyleManager;
            this.mlSelectedTheme.TabIndex = 19;
            this.mlSelectedTheme.Text = "Selected Theme";
            this.mlSelectedTheme.Theme = MetroFramework.MetroThemeStyle.Light;
            this.mlSelectedTheme.UseStyleColors = false;
            // 
            // metroLabel23
            // 
            this.metroLabel23.AutoSize = true;
            this.metroLabel23.CustomBackground = false;
            this.metroLabel23.FontSize = MetroFramework.MetroLabelSize.Medium;
            this.metroLabel23.FontWeight = MetroFramework.MetroLabelWeight.Light;
            this.metroLabel23.LabelMode = MetroFramework.Controls.MetroLabelMode.Default;
            this.metroLabel23.Location = new System.Drawing.Point(512, 176);
            this.metroLabel23.Name = "metroLabel23";
            this.metroLabel23.Size = new System.Drawing.Size(109, 19);
            this.metroLabel23.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroLabel23.StyleManager = this.metroStyleManager;
            this.metroLabel23.TabIndex = 18;
            this.metroLabel23.Text = "Selected Theme: ";
            this.metroLabel23.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroLabel23.UseStyleColors = false;
            // 
            // mlSelectedColor
            // 
            this.mlSelectedColor.AutoSize = true;
            this.mlSelectedColor.CustomBackground = false;
            this.mlSelectedColor.FontSize = MetroFramework.MetroLabelSize.Medium;
            this.mlSelectedColor.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.mlSelectedColor.LabelMode = MetroFramework.Controls.MetroLabelMode.Default;
            this.mlSelectedColor.Location = new System.Drawing.Point(512, 240);
            this.mlSelectedColor.Name = "mlSelectedColor";
            this.mlSelectedColor.Size = new System.Drawing.Size(107, 19);
            this.mlSelectedColor.Style = MetroFramework.MetroColorStyle.Blue;
            this.mlSelectedColor.StyleManager = this.metroStyleManager;
            this.mlSelectedColor.TabIndex = 17;
            this.mlSelectedColor.Text = "Selected Color";
            this.mlSelectedColor.Theme = MetroFramework.MetroThemeStyle.Light;
            this.mlSelectedColor.UseStyleColors = false;
            // 
            // metroLabel21
            // 
            this.metroLabel21.AutoSize = true;
            this.metroLabel21.CustomBackground = false;
            this.metroLabel21.FontSize = MetroFramework.MetroLabelSize.Medium;
            this.metroLabel21.FontWeight = MetroFramework.MetroLabelWeight.Light;
            this.metroLabel21.LabelMode = MetroFramework.Controls.MetroLabelMode.Default;
            this.metroLabel21.Location = new System.Drawing.Point(512, 221);
            this.metroLabel21.Name = "metroLabel21";
            this.metroLabel21.Size = new System.Drawing.Size(96, 19);
            this.metroLabel21.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroLabel21.StyleManager = this.metroStyleManager;
            this.metroLabel21.TabIndex = 16;
            this.metroLabel21.Text = "Selected Style: ";
            this.metroLabel21.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroLabel21.UseStyleColors = false;
            // 
            // metroLink4
            // 
            this.metroLink4.CustomBackground = false;
            this.metroLink4.Enabled = false;
            this.metroLink4.FontSize = MetroFramework.MetroLinkSize.Small;
            this.metroLink4.FontWeight = MetroFramework.MetroLinkWeight.Bold;
            this.metroLink4.Location = new System.Drawing.Point(512, 105);
            this.metroLink4.Name = "metroLink4";
            this.metroLink4.Size = new System.Drawing.Size(95, 23);
            this.metroLink4.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroLink4.StyleManager = this.metroStyleManager;
            this.metroLink4.TabIndex = 15;
            this.metroLink4.Text = "Disabled Link";
            this.metroLink4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.metroLink4.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroLink4.UseStyleColors = false;
            // 
            // metroLink3
            // 
            this.metroLink3.CustomBackground = false;
            this.metroLink3.FontSize = MetroFramework.MetroLinkSize.Small;
            this.metroLink3.FontWeight = MetroFramework.MetroLinkWeight.Bold;
            this.metroLink3.Location = new System.Drawing.Point(513, 76);
            this.metroLink3.Name = "metroLink3";
            this.metroLink3.Size = new System.Drawing.Size(95, 23);
            this.metroLink3.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroLink3.StyleManager = this.metroStyleManager;
            this.metroLink3.TabIndex = 14;
            this.metroLink3.Text = "Styled Link";
            this.metroLink3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.metroLink3.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroLink3.UseStyleColors = true;
            // 
            // metroLabel9
            // 
            this.metroLabel9.AutoSize = true;
            this.metroLabel9.CustomBackground = false;
            this.metroLabel9.FontSize = MetroFramework.MetroLabelSize.Medium;
            this.metroLabel9.FontWeight = MetroFramework.MetroLabelWeight.Light;
            this.metroLabel9.LabelMode = MetroFramework.Controls.MetroLabelMode.Default;
            this.metroLabel9.Location = new System.Drawing.Point(512, 25);
            this.metroLabel9.Name = "metroLabel9";
            this.metroLabel9.Size = new System.Drawing.Size(67, 19);
            this.metroLabel9.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroLabel9.StyleManager = this.metroStyleManager;
            this.metroLabel9.TabIndex = 12;
            this.metroLabel9.Text = "MetroLink";
            this.metroLabel9.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroLabel9.UseStyleColors = false;
            // 
            // metroLabel8
            // 
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.CustomBackground = false;
            this.metroLabel8.FontSize = MetroFramework.MetroLabelSize.Medium;
            this.metroLabel8.FontWeight = MetroFramework.MetroLabelWeight.Light;
            this.metroLabel8.LabelMode = MetroFramework.Controls.MetroLabelMode.Default;
            this.metroLabel8.Location = new System.Drawing.Point(331, 25);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(83, 19);
            this.metroLabel8.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroLabel8.StyleManager = this.metroStyleManager;
            this.metroLabel8.TabIndex = 11;
            this.metroLabel8.Text = "MetroButton";
            this.metroLabel8.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroLabel8.UseStyleColors = false;
            // 
            // metroLink1
            // 
            this.metroLink1.CustomBackground = false;
            this.metroLink1.FontSize = MetroFramework.MetroLinkSize.Small;
            this.metroLink1.FontWeight = MetroFramework.MetroLinkWeight.Bold;
            this.metroLink1.Location = new System.Drawing.Point(512, 47);
            this.metroLink1.Name = "metroLink1";
            this.metroLink1.Size = new System.Drawing.Size(95, 23);
            this.metroLink1.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroLink1.StyleManager = this.metroStyleManager;
            this.metroLink1.TabIndex = 10;
            this.metroLink1.Text = "Normal Link";
            this.metroLink1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.metroLink1.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroToolTip.SetToolTip(this.metroLink1, "Link Tooltip");
            this.metroLink1.UseStyleColors = false;
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.CustomBackground = false;
            this.metroLabel1.FontSize = MetroFramework.MetroLabelSize.Medium;
            this.metroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Light;
            this.metroLabel1.LabelMode = MetroFramework.Controls.MetroLabelMode.Default;
            this.metroLabel1.Location = new System.Drawing.Point(28, 25);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(65, 19);
            this.metroLabel1.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroLabel1.StyleManager = this.metroStyleManager;
            this.metroLabel1.TabIndex = 8;
            this.metroLabel1.Text = "MetroTile";
            this.metroLabel1.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroLabel1.UseStyleColors = false;
            // 
            // metroButton3
            // 
            this.metroButton3.Enabled = false;
            this.metroButton3.FontSize = MetroFramework.MetroButtonSize.Medium;
            this.metroButton3.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.metroButton3.Highlight = false;
            this.metroButton3.Location = new System.Drawing.Point(331, 133);
            this.metroButton3.Name = "metroButton3";
            this.metroButton3.Size = new System.Drawing.Size(127, 37);
            this.metroButton3.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroButton3.StyleManager = this.metroStyleManager;
            this.metroButton3.TabIndex = 7;
            this.metroButton3.Text = "Disabled Button";
            this.metroButton3.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroButton3.Click += new System.EventHandler(this.metroButton3_Click);
            // 
            // metroButton2
            // 
            this.metroButton2.FontSize = MetroFramework.MetroButtonSize.Medium;
            this.metroButton2.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.metroButton2.Highlight = true;
            this.metroButton2.Location = new System.Drawing.Point(331, 90);
            this.metroButton2.Name = "metroButton2";
            this.metroButton2.Size = new System.Drawing.Size(127, 37);
            this.metroButton2.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroButton2.StyleManager = this.metroStyleManager;
            this.metroButton2.TabIndex = 6;
            this.metroButton2.Text = "Highlighted Button";
            this.metroButton2.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroButton2.Click += new System.EventHandler(this.metroButton2_Click);
            // 
            // metroButton1
            // 
            this.metroButton1.FontSize = MetroFramework.MetroButtonSize.Medium;
            this.metroButton1.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.metroButton1.Highlight = false;
            this.metroButton1.Location = new System.Drawing.Point(331, 47);
            this.metroButton1.Name = "metroButton1";
            this.metroButton1.Size = new System.Drawing.Size(127, 37);
            this.metroButton1.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroButton1.StyleManager = this.metroStyleManager;
            this.metroButton1.TabIndex = 5;
            this.metroButton1.Text = "Normal Button";
            this.metroButton1.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroToolTip.SetToolTip(this.metroButton1, "Button Tooltip");
            this.metroButton1.Click += new System.EventHandler(this.metroButton1_Click);
            // 
            // metroTileSwitch
            // 
            this.metroTileSwitch.ActiveControl = null;
            this.metroTileSwitch.Location = new System.Drawing.Point(28, 133);
            this.metroTileSwitch.Name = "metroTileSwitch";
            this.metroTileSwitch.Size = new System.Drawing.Size(234, 86);
            this.metroTileSwitch.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTileSwitch.StyleManager = this.metroStyleManager;
            this.metroTileSwitch.TabIndex = 4;
            this.metroTileSwitch.Text = "Switch Style";
            this.metroTileSwitch.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTileSwitch.TileCount = 0;
            this.metroTileSwitch.Click += new System.EventHandler(this.metroTileSwitch_Click);
            // 
            // metroTile2
            // 
            this.metroTile2.ActiveControl = null;
            this.metroTile2.Enabled = false;
            this.metroTile2.Location = new System.Drawing.Point(149, 47);
            this.metroTile2.Name = "metroTile2";
            this.metroTile2.Size = new System.Drawing.Size(113, 80);
            this.metroTile2.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTile2.StyleManager = this.metroStyleManager;
            this.metroTile2.TabIndex = 3;
            this.metroTile2.Text = "Disabled";
            this.metroTile2.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTile2.TileCount = 5;
            // 
            // metroTile1
            // 
            this.metroTile1.ActiveControl = null;
            this.metroTile1.Location = new System.Drawing.Point(28, 47);
            this.metroTile1.Name = "metroTile1";
            this.metroTile1.Size = new System.Drawing.Size(113, 80);
            this.metroTile1.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTile1.StyleManager = this.metroStyleManager;
            this.metroTile1.TabIndex = 2;
            this.metroTile1.Text = "Switch Theme";
            this.metroTile1.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTile1.TileCount = 0;
            this.metroToolTip.SetToolTip(this.metroTile1, "Tile Tooltip");
            this.metroTile1.Click += new System.EventHandler(this.metroTile1_Click);
            // 
            // metroTabPage4
            // 
            this.metroTabPage4.Controls.Add(this.metroTextBox4);
            this.metroTabPage4.Controls.Add(this.metroTextBox3);
            this.metroTabPage4.Controls.Add(this.metroTextBox2);
            this.metroTabPage4.Controls.Add(this.metroLabel15);
            this.metroTabPage4.Controls.Add(this.metroLabel12);
            this.metroTabPage4.Controls.Add(this.metroLabel13);
            this.metroTabPage4.Controls.Add(this.metroLabel14);
            this.metroTabPage4.Controls.Add(this.metroLabel11);
            this.metroTabPage4.Controls.Add(this.metroLabel10);
            this.metroTabPage4.Controls.Add(this.metroLabel3);
            this.metroTabPage4.Controls.Add(this.metroTextBox1);
            this.metroTabPage4.Controls.Add(this.metroLabel2);
            this.metroTabPage4.CustomBackground = false;
            this.metroTabPage4.HorizontalScrollbar = false;
            this.metroTabPage4.HorizontalScrollbarBarColor = true;
            this.metroTabPage4.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage4.HorizontalScrollbarSize = 10;
            this.metroTabPage4.Location = new System.Drawing.Point(4, 35);
            this.metroTabPage4.Name = "metroTabPage4";
            this.metroTabPage4.Padding = new System.Windows.Forms.Padding(25);
            this.metroTabPage4.Size = new System.Drawing.Size(668, 325);
            this.metroTabPage4.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTabPage4.StyleManager = this.metroStyleManager;
            this.metroTabPage4.TabIndex = 3;
            this.metroTabPage4.Tag = false;
            this.metroTabPage4.Text = "Labels && Text";
            this.metroTabPage4.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTabPage4.VerticalScrollbar = false;
            this.metroTabPage4.VerticalScrollbarBarColor = true;
            this.metroTabPage4.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage4.VerticalScrollbarSize = 10;
            // 
            // metroTextBox4
            // 
            this.metroTextBox4.Enabled = false;
            this.metroTextBox4.Lines = new string[] {
        "Disabled Textbox"};
            this.metroTextBox4.Location = new System.Drawing.Point(323, 106);
            this.metroTextBox4.MaxLength = 32767;
            this.metroTextBox4.Name = "metroTextBox4";
            this.metroTextBox4.PasswordChar = '\0';
            this.metroTextBox4.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox4.SelectedText = "";
            this.metroTextBox4.Size = new System.Drawing.Size(318, 22);
            this.metroTextBox4.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox4.StyleManager = this.metroStyleManager;
            this.metroTextBox4.TabIndex = 13;
            this.metroTextBox4.Text = "Disabled Textbox";
            this.metroTextBox4.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox4.UseSelectable = true;
            // 
            // metroTextBox3
            // 
            this.metroTextBox3.Lines = new string[] {
        "Multiline Textbox"};
            this.metroTextBox3.Location = new System.Drawing.Point(323, 134);
            this.metroTextBox3.MaxLength = 32767;
            this.metroTextBox3.Multiline = true;
            this.metroTextBox3.Name = "metroTextBox3";
            this.metroTextBox3.PasswordChar = '\0';
            this.metroTextBox3.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox3.SelectedText = "";
            this.metroTextBox3.Size = new System.Drawing.Size(318, 91);
            this.metroTextBox3.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox3.StyleManager = this.metroStyleManager;
            this.metroTextBox3.TabIndex = 12;
            this.metroTextBox3.Text = "Multiline Textbox";
            this.metroTextBox3.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox3.UseSelectable = true;
            // 
            // metroTextBox2
            // 
            this.metroTextBox2.Lines = new string[] {
        "Styled Textbox"};
            this.metroTextBox2.Location = new System.Drawing.Point(323, 78);
            this.metroTextBox2.MaxLength = 32767;
            this.metroTextBox2.Name = "metroTextBox2";
            this.metroTextBox2.PasswordChar = '\0';
            this.metroTextBox2.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox2.SelectedText = "";
            this.metroTextBox2.Size = new System.Drawing.Size(318, 22);
            this.metroTextBox2.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox2.StyleManager = this.metroStyleManager;
            this.metroTextBox2.TabIndex = 11;
            this.metroTextBox2.Text = "Styled Textbox";
            this.metroTextBox2.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox2.UseSelectable = true;
            this.metroTextBox2.UseStyleColors = true;
            // 
            // metroLabel15
            // 
            this.metroLabel15.AutoSize = true;
            this.metroLabel15.CustomBackground = false;
            this.metroLabel15.FontSize = MetroFramework.MetroLabelSize.Medium;
            this.metroLabel15.FontWeight = MetroFramework.MetroLabelWeight.Light;
            this.metroLabel15.LabelMode = MetroFramework.Controls.MetroLabelMode.Default;
            this.metroLabel15.Location = new System.Drawing.Point(323, 25);
            this.metroLabel15.Margin = new System.Windows.Forms.Padding(3);
            this.metroLabel15.Name = "metroLabel15";
            this.metroLabel15.Size = new System.Drawing.Size(91, 19);
            this.metroLabel15.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroLabel15.StyleManager = this.metroStyleManager;
            this.metroLabel15.TabIndex = 10;
            this.metroLabel15.Text = "MetroTextBox";
            this.metroLabel15.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroLabel15.UseStyleColors = false;
            // 
            // metroLabel12
            // 
            this.metroLabel12.AutoSize = true;
            this.metroLabel12.CustomBackground = false;
            this.metroLabel12.Enabled = false;
            this.metroLabel12.FontSize = MetroFramework.MetroLabelSize.Medium;
            this.metroLabel12.FontWeight = MetroFramework.MetroLabelWeight.Light;
            this.metroLabel12.LabelMode = MetroFramework.Controls.MetroLabelMode.Selectable;
            this.metroLabel12.Location = new System.Drawing.Point(139, 100);
            this.metroLabel12.Margin = new System.Windows.Forms.Padding(3);
            this.metroLabel12.Name = "metroLabel12";
            this.metroLabel12.Size = new System.Drawing.Size(157, 19);
            this.metroLabel12.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroLabel12.StyleManager = this.metroStyleManager;
            this.metroLabel12.TabIndex = 9;
            this.metroLabel12.Text = "Disabled Selectable Label";
            this.metroLabel12.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroLabel12.UseStyleColors = false;
            // 
            // metroLabel13
            // 
            this.metroLabel13.AutoSize = true;
            this.metroLabel13.CustomBackground = false;
            this.metroLabel13.FontSize = MetroFramework.MetroLabelSize.Medium;
            this.metroLabel13.FontWeight = MetroFramework.MetroLabelWeight.Light;
            this.metroLabel13.LabelMode = MetroFramework.Controls.MetroLabelMode.Selectable;
            this.metroLabel13.Location = new System.Drawing.Point(139, 75);
            this.metroLabel13.Margin = new System.Windows.Forms.Padding(3);
            this.metroLabel13.Name = "metroLabel13";
            this.metroLabel13.Size = new System.Drawing.Size(142, 19);
            this.metroLabel13.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroLabel13.StyleManager = this.metroStyleManager;
            this.metroLabel13.TabIndex = 8;
            this.metroLabel13.Text = "Styled Selectable Label";
            this.metroLabel13.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroLabel13.UseStyleColors = true;
            // 
            // metroLabel14
            // 
            this.metroLabel14.AutoSize = true;
            this.metroLabel14.CustomBackground = false;
            this.metroLabel14.FontSize = MetroFramework.MetroLabelSize.Medium;
            this.metroLabel14.FontWeight = MetroFramework.MetroLabelWeight.Light;
            this.metroLabel14.LabelMode = MetroFramework.Controls.MetroLabelMode.Selectable;
            this.metroLabel14.Location = new System.Drawing.Point(139, 50);
            this.metroLabel14.Margin = new System.Windows.Forms.Padding(3);
            this.metroLabel14.Name = "metroLabel14";
            this.metroLabel14.Size = new System.Drawing.Size(152, 19);
            this.metroLabel14.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroLabel14.StyleManager = this.metroStyleManager;
            this.metroLabel14.TabIndex = 7;
            this.metroLabel14.Text = "Normal Selectable Label";
            this.metroLabel14.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroToolTip.SetToolTip(this.metroLabel14, "Label Tooltip");
            this.metroLabel14.UseStyleColors = false;
            // 
            // metroLabel11
            // 
            this.metroLabel11.AutoSize = true;
            this.metroLabel11.CustomBackground = false;
            this.metroLabel11.Enabled = false;
            this.metroLabel11.FontSize = MetroFramework.MetroLabelSize.Medium;
            this.metroLabel11.FontWeight = MetroFramework.MetroLabelWeight.Light;
            this.metroLabel11.LabelMode = MetroFramework.Controls.MetroLabelMode.Default;
            this.metroLabel11.Location = new System.Drawing.Point(28, 100);
            this.metroLabel11.Margin = new System.Windows.Forms.Padding(3);
            this.metroLabel11.Name = "metroLabel11";
            this.metroLabel11.Size = new System.Drawing.Size(94, 19);
            this.metroLabel11.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroLabel11.StyleManager = this.metroStyleManager;
            this.metroLabel11.TabIndex = 6;
            this.metroLabel11.Text = "Disabled Label";
            this.metroLabel11.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroLabel11.UseStyleColors = false;
            // 
            // metroLabel10
            // 
            this.metroLabel10.AutoSize = true;
            this.metroLabel10.CustomBackground = false;
            this.metroLabel10.FontSize = MetroFramework.MetroLabelSize.Medium;
            this.metroLabel10.FontWeight = MetroFramework.MetroLabelWeight.Light;
            this.metroLabel10.LabelMode = MetroFramework.Controls.MetroLabelMode.Default;
            this.metroLabel10.Location = new System.Drawing.Point(28, 75);
            this.metroLabel10.Margin = new System.Windows.Forms.Padding(3);
            this.metroLabel10.Name = "metroLabel10";
            this.metroLabel10.Size = new System.Drawing.Size(79, 19);
            this.metroLabel10.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroLabel10.StyleManager = this.metroStyleManager;
            this.metroLabel10.TabIndex = 5;
            this.metroLabel10.Text = "Styled Label";
            this.metroLabel10.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroLabel10.UseStyleColors = true;
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.CustomBackground = false;
            this.metroLabel3.FontSize = MetroFramework.MetroLabelSize.Medium;
            this.metroLabel3.FontWeight = MetroFramework.MetroLabelWeight.Light;
            this.metroLabel3.LabelMode = MetroFramework.Controls.MetroLabelMode.Default;
            this.metroLabel3.Location = new System.Drawing.Point(28, 50);
            this.metroLabel3.Margin = new System.Windows.Forms.Padding(3);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(89, 19);
            this.metroLabel3.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroLabel3.StyleManager = this.metroStyleManager;
            this.metroLabel3.TabIndex = 4;
            this.metroLabel3.Text = "Normal Label";
            this.metroLabel3.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroToolTip.SetToolTip(this.metroLabel3, "Label Tooltip");
            this.metroLabel3.UseStyleColors = false;
            // 
            // metroTextBox1
            // 
            this.metroTextBox1.Lines = new string[] {
        "Normal Textbox"};
            this.metroTextBox1.Location = new System.Drawing.Point(323, 50);
            this.metroTextBox1.MaxLength = 32767;
            this.metroTextBox1.Name = "metroTextBox1";
            this.metroTextBox1.PasswordChar = '\0';
            this.metroTextBox1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox1.SelectedText = "";
            this.metroTextBox1.Size = new System.Drawing.Size(318, 22);
            this.metroTextBox1.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox1.StyleManager = this.metroStyleManager;
            this.metroTextBox1.TabIndex = 3;
            this.metroTextBox1.Text = "Normal Textbox";
            this.metroTextBox1.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroToolTip.SetToolTip(this.metroTextBox1, "Textbox Tooltip");
            this.metroTextBox1.UseSelectable = true;
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.CustomBackground = false;
            this.metroLabel2.FontSize = MetroFramework.MetroLabelSize.Medium;
            this.metroLabel2.FontWeight = MetroFramework.MetroLabelWeight.Light;
            this.metroLabel2.LabelMode = MetroFramework.Controls.MetroLabelMode.Default;
            this.metroLabel2.Location = new System.Drawing.Point(28, 25);
            this.metroLabel2.Margin = new System.Windows.Forms.Padding(3);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(76, 19);
            this.metroLabel2.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroLabel2.StyleManager = this.metroStyleManager;
            this.metroLabel2.TabIndex = 2;
            this.metroLabel2.Text = "MetroLabel";
            this.metroLabel2.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroLabel2.UseStyleColors = false;
            // 
            // metroTabPage2
            // 
            this.metroTabPage2.Controls.Add(this.metroDateTime1);
            this.metroTabPage2.Controls.Add(this.metroLabel24);
            this.metroTabPage2.Controls.Add(this.metroComboBox2);
            this.metroTabPage2.Controls.Add(this.metroToggle3);
            this.metroTabPage2.Controls.Add(this.metroToggle2);
            this.metroTabPage2.Controls.Add(this.metroRadioButton3);
            this.metroTabPage2.Controls.Add(this.metroRadioButton2);
            this.metroTabPage2.Controls.Add(this.metroCheckBox3);
            this.metroTabPage2.Controls.Add(this.metroCheckBox2);
            this.metroTabPage2.Controls.Add(this.metroLabel19);
            this.metroTabPage2.Controls.Add(this.metroLabel18);
            this.metroTabPage2.Controls.Add(this.metroLabel17);
            this.metroTabPage2.Controls.Add(this.metroLabel16);
            this.metroTabPage2.Controls.Add(this.metroComboBox1);
            this.metroTabPage2.Controls.Add(this.metroRadioButton1);
            this.metroTabPage2.Controls.Add(this.metroToggle1);
            this.metroTabPage2.Controls.Add(this.metroCheckBox1);
            this.metroTabPage2.CustomBackground = false;
            this.metroTabPage2.HorizontalScrollbar = false;
            this.metroTabPage2.HorizontalScrollbarBarColor = true;
            this.metroTabPage2.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage2.HorizontalScrollbarSize = 10;
            this.metroTabPage2.Location = new System.Drawing.Point(4, 35);
            this.metroTabPage2.Name = "metroTabPage2";
            this.metroTabPage2.Padding = new System.Windows.Forms.Padding(25);
            this.metroTabPage2.Size = new System.Drawing.Size(668, 325);
            this.metroTabPage2.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTabPage2.StyleManager = this.metroStyleManager;
            this.metroTabPage2.TabIndex = 1;
            this.metroTabPage2.Tag = false;
            this.metroTabPage2.Text = "Options";
            this.metroTabPage2.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTabPage2.VerticalScrollbar = false;
            this.metroTabPage2.VerticalScrollbarBarColor = true;
            this.metroTabPage2.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage2.VerticalScrollbarSize = 10;
            // 
            // metroDateTime1
            // 
            this.metroDateTime1.FontSize = MetroFramework.MetroDateTimeSize.Medium;
            this.metroDateTime1.FontWeight = MetroFramework.MetroDateTimeWeight.Regular;
            this.metroDateTime1.Location = new System.Drawing.Point(297, 151);
            this.metroDateTime1.MinimumSize = new System.Drawing.Size(4, 29);
            this.metroDateTime1.Name = "metroDateTime1";
            this.metroDateTime1.Size = new System.Drawing.Size(235, 29);
            this.metroDateTime1.TabIndex = 40;
            // 
            // metroLabel24
            // 
            this.metroLabel24.AutoSize = true;
            this.metroLabel24.CustomBackground = false;
            this.metroLabel24.FontSize = MetroFramework.MetroLabelSize.Medium;
            this.metroLabel24.FontWeight = MetroFramework.MetroLabelWeight.Light;
            this.metroLabel24.LabelMode = MetroFramework.Controls.MetroLabelMode.Default;
            this.metroLabel24.Location = new System.Drawing.Point(297, 129);
            this.metroLabel24.Name = "metroLabel24";
            this.metroLabel24.Size = new System.Drawing.Size(105, 19);
            this.metroLabel24.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroLabel24.StyleManager = this.metroStyleManager;
            this.metroLabel24.TabIndex = 39;
            this.metroLabel24.Text = "Metro DateTime";
            this.metroLabel24.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroLabel24.UseStyleColors = false;
            // 
            // metroComboBox2
            // 
            this.metroComboBox2.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.metroComboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.metroComboBox2.Enabled = false;
            this.metroComboBox2.FontSize = MetroFramework.MetroLinkSize.Medium;
            this.metroComboBox2.FontWeight = MetroFramework.MetroLinkWeight.Regular;
            this.metroComboBox2.FormattingEnabled = true;
            this.metroComboBox2.ItemHeight = 23;
            this.metroComboBox2.Items.AddRange(new object[] {
            "Normal Combobox"});
            this.metroComboBox2.Location = new System.Drawing.Point(297, 82);
            this.metroComboBox2.Name = "metroComboBox2";
            this.metroComboBox2.Size = new System.Drawing.Size(197, 29);
            this.metroComboBox2.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroComboBox2.StyleManager = this.metroStyleManager;
            this.metroComboBox2.TabIndex = 16;
            this.metroComboBox2.Theme = MetroFramework.MetroThemeStyle.Light;
            // 
            // metroToggle3
            // 
            this.metroToggle3.AutoSize = true;
            this.metroToggle3.CustomBackground = false;
            this.metroToggle3.DisplayStatus = false;
            this.metroToggle3.Enabled = false;
            this.metroToggle3.FontSize = MetroFramework.MetroLinkSize.Small;
            this.metroToggle3.FontWeight = MetroFramework.MetroLinkWeight.Regular;
            this.metroToggle3.Location = new System.Drawing.Point(572, 95);
            this.metroToggle3.Name = "metroToggle3";
            this.metroToggle3.Size = new System.Drawing.Size(50, 17);
            this.metroToggle3.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroToggle3.StyleManager = this.metroStyleManager;
            this.metroToggle3.TabIndex = 15;
            this.metroToggle3.Text = "Off";
            this.metroToggle3.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroToggle3.UseStyleColors = false;
            this.metroToggle3.UseVisualStyleBackColor = true;
            // 
            // metroToggle2
            // 
            this.metroToggle2.AutoSize = true;
            this.metroToggle2.CustomBackground = false;
            this.metroToggle2.DisplayStatus = false;
            this.metroToggle2.FontSize = MetroFramework.MetroLinkSize.Small;
            this.metroToggle2.FontWeight = MetroFramework.MetroLinkWeight.Regular;
            this.metroToggle2.Location = new System.Drawing.Point(572, 72);
            this.metroToggle2.Name = "metroToggle2";
            this.metroToggle2.Size = new System.Drawing.Size(50, 17);
            this.metroToggle2.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroToggle2.StyleManager = this.metroStyleManager;
            this.metroToggle2.TabIndex = 14;
            this.metroToggle2.Text = "Off";
            this.metroToggle2.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroToggle2.UseStyleColors = true;
            this.metroToggle2.UseVisualStyleBackColor = true;
            // 
            // metroRadioButton3
            // 
            this.metroRadioButton3.AutoSize = true;
            this.metroRadioButton3.CustomBackground = false;
            this.metroRadioButton3.Enabled = false;
            this.metroRadioButton3.FontSize = MetroFramework.MetroLinkSize.Small;
            this.metroRadioButton3.FontWeight = MetroFramework.MetroLinkWeight.Regular;
            this.metroRadioButton3.Location = new System.Drawing.Point(28, 202);
            this.metroRadioButton3.Name = "metroRadioButton3";
            this.metroRadioButton3.Size = new System.Drawing.Size(137, 15);
            this.metroRadioButton3.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroRadioButton3.StyleManager = this.metroStyleManager;
            this.metroRadioButton3.TabIndex = 13;
            this.metroRadioButton3.TabStop = true;
            this.metroRadioButton3.Text = "Disabled Radiobutton";
            this.metroRadioButton3.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroRadioButton3.UseStyleColors = false;
            this.metroRadioButton3.UseVisualStyleBackColor = true;
            // 
            // metroRadioButton2
            // 
            this.metroRadioButton2.AutoSize = true;
            this.metroRadioButton2.CustomBackground = false;
            this.metroRadioButton2.FontSize = MetroFramework.MetroLinkSize.Small;
            this.metroRadioButton2.FontWeight = MetroFramework.MetroLinkWeight.Regular;
            this.metroRadioButton2.Location = new System.Drawing.Point(28, 181);
            this.metroRadioButton2.Name = "metroRadioButton2";
            this.metroRadioButton2.Size = new System.Drawing.Size(124, 15);
            this.metroRadioButton2.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroRadioButton2.StyleManager = this.metroStyleManager;
            this.metroRadioButton2.TabIndex = 12;
            this.metroRadioButton2.TabStop = true;
            this.metroRadioButton2.Text = "Styled Radiobutton";
            this.metroRadioButton2.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroRadioButton2.UseStyleColors = true;
            this.metroRadioButton2.UseVisualStyleBackColor = true;
            // 
            // metroCheckBox3
            // 
            this.metroCheckBox3.AutoSize = true;
            this.metroCheckBox3.CustomBackground = false;
            this.metroCheckBox3.Enabled = false;
            this.metroCheckBox3.FontSize = MetroFramework.MetroLinkSize.Small;
            this.metroCheckBox3.FontWeight = MetroFramework.MetroLinkWeight.Regular;
            this.metroCheckBox3.Location = new System.Drawing.Point(28, 95);
            this.metroCheckBox3.Name = "metroCheckBox3";
            this.metroCheckBox3.Size = new System.Drawing.Size(123, 15);
            this.metroCheckBox3.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroCheckBox3.StyleManager = this.metroStyleManager;
            this.metroCheckBox3.TabIndex = 11;
            this.metroCheckBox3.Text = "Disabled Checkbox";
            this.metroCheckBox3.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroCheckBox3.UseStyleColors = false;
            this.metroCheckBox3.UseVisualStyleBackColor = true;
            // 
            // metroCheckBox2
            // 
            this.metroCheckBox2.AutoSize = true;
            this.metroCheckBox2.CustomBackground = false;
            this.metroCheckBox2.FontSize = MetroFramework.MetroLinkSize.Small;
            this.metroCheckBox2.FontWeight = MetroFramework.MetroLinkWeight.Regular;
            this.metroCheckBox2.Location = new System.Drawing.Point(28, 74);
            this.metroCheckBox2.Name = "metroCheckBox2";
            this.metroCheckBox2.Size = new System.Drawing.Size(110, 15);
            this.metroCheckBox2.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroCheckBox2.StyleManager = this.metroStyleManager;
            this.metroCheckBox2.TabIndex = 10;
            this.metroCheckBox2.Text = "Styled Checkbox";
            this.metroCheckBox2.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroCheckBox2.UseStyleColors = true;
            this.metroCheckBox2.UseVisualStyleBackColor = true;
            // 
            // metroLabel19
            // 
            this.metroLabel19.AutoSize = true;
            this.metroLabel19.CustomBackground = false;
            this.metroLabel19.FontSize = MetroFramework.MetroLabelSize.Medium;
            this.metroLabel19.FontWeight = MetroFramework.MetroLabelWeight.Light;
            this.metroLabel19.LabelMode = MetroFramework.Controls.MetroLabelMode.Default;
            this.metroLabel19.Location = new System.Drawing.Point(536, 25);
            this.metroLabel19.Name = "metroLabel19";
            this.metroLabel19.Size = new System.Drawing.Size(86, 19);
            this.metroLabel19.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroLabel19.StyleManager = this.metroStyleManager;
            this.metroLabel19.TabIndex = 9;
            this.metroLabel19.Text = "MetroToggle";
            this.metroLabel19.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroLabel19.UseStyleColors = false;
            // 
            // metroLabel18
            // 
            this.metroLabel18.AutoSize = true;
            this.metroLabel18.CustomBackground = false;
            this.metroLabel18.FontSize = MetroFramework.MetroLabelSize.Medium;
            this.metroLabel18.FontWeight = MetroFramework.MetroLabelWeight.Light;
            this.metroLabel18.LabelMode = MetroFramework.Controls.MetroLabelMode.Default;
            this.metroLabel18.Location = new System.Drawing.Point(28, 133);
            this.metroLabel18.Name = "metroLabel18";
            this.metroLabel18.Size = new System.Drawing.Size(117, 19);
            this.metroLabel18.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroLabel18.StyleManager = this.metroStyleManager;
            this.metroLabel18.TabIndex = 8;
            this.metroLabel18.Text = "MetroRadioButton";
            this.metroLabel18.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroLabel18.UseStyleColors = false;
            // 
            // metroLabel17
            // 
            this.metroLabel17.AutoSize = true;
            this.metroLabel17.CustomBackground = false;
            this.metroLabel17.FontSize = MetroFramework.MetroLabelSize.Medium;
            this.metroLabel17.FontWeight = MetroFramework.MetroLabelWeight.Light;
            this.metroLabel17.LabelMode = MetroFramework.Controls.MetroLabelMode.Default;
            this.metroLabel17.Location = new System.Drawing.Point(297, 25);
            this.metroLabel17.Name = "metroLabel17";
            this.metroLabel17.Size = new System.Drawing.Size(112, 19);
            this.metroLabel17.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroLabel17.StyleManager = this.metroStyleManager;
            this.metroLabel17.TabIndex = 7;
            this.metroLabel17.Text = "MetroComboBox";
            this.metroLabel17.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroLabel17.UseStyleColors = false;
            // 
            // metroLabel16
            // 
            this.metroLabel16.AutoSize = true;
            this.metroLabel16.CustomBackground = false;
            this.metroLabel16.FontSize = MetroFramework.MetroLabelSize.Medium;
            this.metroLabel16.FontWeight = MetroFramework.MetroLabelWeight.Light;
            this.metroLabel16.LabelMode = MetroFramework.Controls.MetroLabelMode.Default;
            this.metroLabel16.Location = new System.Drawing.Point(28, 25);
            this.metroLabel16.Name = "metroLabel16";
            this.metroLabel16.Size = new System.Drawing.Size(102, 19);
            this.metroLabel16.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroLabel16.StyleManager = this.metroStyleManager;
            this.metroLabel16.TabIndex = 6;
            this.metroLabel16.Text = "MetroCheckBox";
            this.metroLabel16.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroLabel16.UseStyleColors = false;
            // 
            // metroComboBox1
            // 
            this.metroComboBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.metroComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.metroComboBox1.FontSize = MetroFramework.MetroLinkSize.Medium;
            this.metroComboBox1.FontWeight = MetroFramework.MetroLinkWeight.Regular;
            this.metroComboBox1.FormattingEnabled = true;
            this.metroComboBox1.ItemHeight = 23;
            this.metroComboBox1.Items.AddRange(new object[] {
            "Normal Combobox"});
            this.metroComboBox1.Location = new System.Drawing.Point(297, 47);
            this.metroComboBox1.Name = "metroComboBox1";
            this.metroComboBox1.Size = new System.Drawing.Size(197, 29);
            this.metroComboBox1.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroComboBox1.StyleManager = this.metroStyleManager;
            this.metroComboBox1.TabIndex = 5;
            this.metroComboBox1.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroToolTip.SetToolTip(this.metroComboBox1, "ComboBox Tooltip");
            // 
            // metroRadioButton1
            // 
            this.metroRadioButton1.AutoSize = true;
            this.metroRadioButton1.CustomBackground = false;
            this.metroRadioButton1.FontSize = MetroFramework.MetroLinkSize.Small;
            this.metroRadioButton1.FontWeight = MetroFramework.MetroLinkWeight.Regular;
            this.metroRadioButton1.Location = new System.Drawing.Point(28, 160);
            this.metroRadioButton1.Name = "metroRadioButton1";
            this.metroRadioButton1.Size = new System.Drawing.Size(132, 15);
            this.metroRadioButton1.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroRadioButton1.StyleManager = this.metroStyleManager;
            this.metroRadioButton1.TabIndex = 4;
            this.metroRadioButton1.TabStop = true;
            this.metroRadioButton1.Text = "Normal Radiobutton";
            this.metroRadioButton1.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroToolTip.SetToolTip(this.metroRadioButton1, "RadioButton Tooltip");
            this.metroRadioButton1.UseStyleColors = false;
            this.metroRadioButton1.UseVisualStyleBackColor = true;
            // 
            // metroToggle1
            // 
            this.metroToggle1.AutoSize = true;
            this.metroToggle1.CustomBackground = false;
            this.metroToggle1.DisplayStatus = true;
            this.metroToggle1.FontSize = MetroFramework.MetroLinkSize.Small;
            this.metroToggle1.FontWeight = MetroFramework.MetroLinkWeight.Regular;
            this.metroToggle1.Location = new System.Drawing.Point(542, 49);
            this.metroToggle1.Name = "metroToggle1";
            this.metroToggle1.Size = new System.Drawing.Size(80, 17);
            this.metroToggle1.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroToggle1.StyleManager = this.metroStyleManager;
            this.metroToggle1.TabIndex = 3;
            this.metroToggle1.Text = "Off";
            this.metroToggle1.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroToolTip.SetToolTip(this.metroToggle1, "Toggle Tooltip");
            this.metroToggle1.UseStyleColors = false;
            this.metroToggle1.UseVisualStyleBackColor = true;
            // 
            // metroCheckBox1
            // 
            this.metroCheckBox1.AutoSize = true;
            this.metroCheckBox1.CustomBackground = false;
            this.metroCheckBox1.FontSize = MetroFramework.MetroLinkSize.Small;
            this.metroCheckBox1.FontWeight = MetroFramework.MetroLinkWeight.Regular;
            this.metroCheckBox1.Location = new System.Drawing.Point(28, 53);
            this.metroCheckBox1.Name = "metroCheckBox1";
            this.metroCheckBox1.Size = new System.Drawing.Size(118, 15);
            this.metroCheckBox1.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroCheckBox1.StyleManager = this.metroStyleManager;
            this.metroCheckBox1.TabIndex = 2;
            this.metroCheckBox1.Text = "Normal Checkbox";
            this.metroCheckBox1.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroToolTip.SetToolTip(this.metroCheckBox1, "Checkbox Tooltip");
            this.metroCheckBox1.UseStyleColors = false;
            this.metroCheckBox1.UseVisualStyleBackColor = true;
            // 
            // metroTabPage3
            // 
            this.metroTabPage3.Controls.Add(this.metroLabel7);
            this.metroTabPage3.Controls.Add(this.metroProgressSpinner3);
            this.metroTabPage3.Controls.Add(this.metroProgressSpinner2);
            this.metroTabPage3.Controls.Add(this.metroLabel6);
            this.metroTabPage3.Controls.Add(this.metroLabel5);
            this.metroTabPage3.Controls.Add(this.metroProgressBar1);
            this.metroTabPage3.Controls.Add(this.metroLabel4);
            this.metroTabPage3.Controls.Add(this.metroScrollBar1);
            this.metroTabPage3.Controls.Add(this.metroTrackBar1);
            this.metroTabPage3.Controls.Add(this.metroProgressSpinner1);
            this.metroTabPage3.Controls.Add(this.metroProgressBar);
            this.metroTabPage3.CustomBackground = false;
            this.metroTabPage3.HorizontalScrollbar = false;
            this.metroTabPage3.HorizontalScrollbarBarColor = true;
            this.metroTabPage3.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage3.HorizontalScrollbarSize = 10;
            this.metroTabPage3.Location = new System.Drawing.Point(4, 35);
            this.metroTabPage3.Name = "metroTabPage3";
            this.metroTabPage3.Padding = new System.Windows.Forms.Padding(25);
            this.metroTabPage3.Size = new System.Drawing.Size(668, 325);
            this.metroTabPage3.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTabPage3.StyleManager = this.metroStyleManager;
            this.metroTabPage3.TabIndex = 2;
            this.metroTabPage3.Tag = false;
            this.metroTabPage3.Text = "Scroll && Progress";
            this.metroTabPage3.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTabPage3.VerticalScrollbar = false;
            this.metroTabPage3.VerticalScrollbarBarColor = true;
            this.metroTabPage3.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage3.VerticalScrollbarSize = 10;
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.CustomBackground = false;
            this.metroLabel7.FontSize = MetroFramework.MetroLabelSize.Medium;
            this.metroLabel7.FontWeight = MetroFramework.MetroLabelWeight.Light;
            this.metroLabel7.LabelMode = MetroFramework.Controls.MetroLabelMode.Default;
            this.metroLabel7.Location = new System.Drawing.Point(28, 187);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(97, 19);
            this.metroLabel7.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroLabel7.StyleManager = this.metroStyleManager;
            this.metroLabel7.TabIndex = 12;
            this.metroLabel7.Text = "MetroScrollBar";
            this.metroLabel7.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroLabel7.UseStyleColors = false;
            // 
            // metroProgressSpinner3
            // 
            this.metroProgressSpinner3.CustomBackground = false;
            this.metroProgressSpinner3.Location = new System.Drawing.Point(521, 146);
            this.metroProgressSpinner3.Maximum = 100;
            this.metroProgressSpinner3.Name = "metroProgressSpinner3";
            this.metroProgressSpinner3.Size = new System.Drawing.Size(23, 23);
            this.metroProgressSpinner3.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroProgressSpinner3.StyleManager = this.metroStyleManager;
            this.metroProgressSpinner3.TabIndex = 11;
            this.metroProgressSpinner3.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroProgressSpinner3.Value = 50;
            // 
            // metroProgressSpinner2
            // 
            this.metroProgressSpinner2.CustomBackground = false;
            this.metroProgressSpinner2.Location = new System.Drawing.Point(492, 146);
            this.metroProgressSpinner2.Maximum = 100;
            this.metroProgressSpinner2.Name = "metroProgressSpinner2";
            this.metroProgressSpinner2.Size = new System.Drawing.Size(23, 23);
            this.metroProgressSpinner2.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroProgressSpinner2.StyleManager = this.metroStyleManager;
            this.metroProgressSpinner2.TabIndex = 10;
            this.metroProgressSpinner2.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroProgressSpinner2.Value = 25;
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.CustomBackground = false;
            this.metroLabel6.FontSize = MetroFramework.MetroLabelSize.Medium;
            this.metroLabel6.FontWeight = MetroFramework.MetroLabelWeight.Light;
            this.metroLabel6.LabelMode = MetroFramework.Controls.MetroLabelMode.Default;
            this.metroLabel6.Location = new System.Drawing.Point(463, 124);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(140, 19);
            this.metroLabel6.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroLabel6.StyleManager = this.metroStyleManager;
            this.metroLabel6.TabIndex = 9;
            this.metroLabel6.Text = "MetroProgressSpinner";
            this.metroLabel6.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroLabel6.UseStyleColors = false;
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.CustomBackground = false;
            this.metroLabel5.FontSize = MetroFramework.MetroLabelSize.Medium;
            this.metroLabel5.FontWeight = MetroFramework.MetroLabelWeight.Light;
            this.metroLabel5.LabelMode = MetroFramework.Controls.MetroLabelMode.Default;
            this.metroLabel5.Location = new System.Drawing.Point(28, 124);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(96, 19);
            this.metroLabel5.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroLabel5.StyleManager = this.metroStyleManager;
            this.metroLabel5.TabIndex = 8;
            this.metroLabel5.Text = "MetroTrackBar";
            this.metroLabel5.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroLabel5.UseStyleColors = false;
            // 
            // metroProgressBar1
            // 
            this.metroProgressBar1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.metroProgressBar1.FontSize = MetroFramework.MetroProgressBarSize.Medium;
            this.metroProgressBar1.FontWeight = MetroFramework.MetroProgressBarWeight.Light;
            this.metroProgressBar1.HideProgressText = true;
            this.metroProgressBar1.Location = new System.Drawing.Point(28, 76);
            this.metroProgressBar1.Name = "metroProgressBar1";
            this.metroProgressBar1.ProgressBarStyle = System.Windows.Forms.ProgressBarStyle.Marquee;
            this.metroProgressBar1.Size = new System.Drawing.Size(612, 23);
            this.metroProgressBar1.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroProgressBar1.StyleManager = this.metroStyleManager;
            this.metroProgressBar1.TabIndex = 7;
            this.metroProgressBar1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.metroProgressBar1.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroProgressBar1.Value = 25;
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.CustomBackground = false;
            this.metroLabel4.FontSize = MetroFramework.MetroLabelSize.Medium;
            this.metroLabel4.FontWeight = MetroFramework.MetroLabelWeight.Light;
            this.metroLabel4.LabelMode = MetroFramework.Controls.MetroLabelMode.Default;
            this.metroLabel4.Location = new System.Drawing.Point(28, 25);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(116, 19);
            this.metroLabel4.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroLabel4.StyleManager = this.metroStyleManager;
            this.metroLabel4.TabIndex = 6;
            this.metroLabel4.Text = "MetroProgressBar";
            this.metroLabel4.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroLabel4.UseStyleColors = false;
            // 
            // metroScrollBar1
            // 
            this.metroScrollBar1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.metroScrollBar1.BorderWidth = 0;
            this.metroScrollBar1.LargeChange = 10;
            this.metroScrollBar1.Location = new System.Drawing.Point(28, 209);
            this.metroScrollBar1.Maximum = 100;
            this.metroScrollBar1.Minimum = 0;
            this.metroScrollBar1.MouseWheelBarPartitions = 10;
            this.metroScrollBar1.Name = "metroScrollBar1";
            this.metroScrollBar1.Orientation = MetroFramework.Controls.MetroScrollOrientation.Horizontal;
            this.metroScrollBar1.ScrollbarSize = 10;
            this.metroScrollBar1.Size = new System.Drawing.Size(612, 10);
            this.metroScrollBar1.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroScrollBar1.TabIndex = 5;
            this.metroScrollBar1.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroToolTip.SetToolTip(this.metroScrollBar1, "Scrollbar Tooltip");
            this.metroScrollBar1.UseBarColor = true;
            this.metroScrollBar1.UseSelectable = true;
            // 
            // metroTrackBar1
            // 
            this.metroTrackBar1.BackColor = System.Drawing.Color.Transparent;
            this.metroTrackBar1.CustomBackground = false;
            this.metroTrackBar1.LargeChange = ((uint)(5u));
            this.metroTrackBar1.Location = new System.Drawing.Point(28, 146);
            this.metroTrackBar1.Maximum = 100;
            this.metroTrackBar1.Minimum = 0;
            this.metroTrackBar1.MouseWheelBarPartitions = 10;
            this.metroTrackBar1.Name = "metroTrackBar1";
            this.metroTrackBar1.Size = new System.Drawing.Size(381, 23);
            this.metroTrackBar1.SmallChange = ((uint)(1u));
            this.metroTrackBar1.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTrackBar1.StyleManager = this.metroStyleManager;
            this.metroTrackBar1.TabIndex = 4;
            this.metroTrackBar1.Text = "metroTrackBar1";
            this.metroTrackBar1.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroToolTip.SetToolTip(this.metroTrackBar1, "TrackBar Tooltip");
            this.metroTrackBar1.Value = 50;
            // 
            // metroProgressSpinner1
            // 
            this.metroProgressSpinner1.CustomBackground = false;
            this.metroProgressSpinner1.Location = new System.Drawing.Point(463, 146);
            this.metroProgressSpinner1.Maximum = 100;
            this.metroProgressSpinner1.Name = "metroProgressSpinner1";
            this.metroProgressSpinner1.Size = new System.Drawing.Size(23, 23);
            this.metroProgressSpinner1.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroProgressSpinner1.StyleManager = this.metroStyleManager;
            this.metroProgressSpinner1.TabIndex = 3;
            this.metroProgressSpinner1.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroToolTip.SetToolTip(this.metroProgressSpinner1, "Spinner Tooltip");
            // 
            // metroProgressBar
            // 
            this.metroProgressBar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.metroProgressBar.Enabled = false;
            this.metroProgressBar.FontSize = MetroFramework.MetroProgressBarSize.Medium;
            this.metroProgressBar.FontWeight = MetroFramework.MetroProgressBarWeight.Light;
            this.metroProgressBar.HideProgressText = true;
            this.metroProgressBar.Location = new System.Drawing.Point(28, 47);
            this.metroProgressBar.Name = "metroProgressBar";
            this.metroProgressBar.ProgressBarStyle = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.metroProgressBar.Size = new System.Drawing.Size(612, 23);
            this.metroProgressBar.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroProgressBar.StyleManager = this.metroStyleManager;
            this.metroProgressBar.TabIndex = 2;
            this.metroProgressBar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.metroProgressBar.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroToolTip.SetToolTip(this.metroProgressBar, "ProgressBar Tooltip");
            this.metroProgressBar.Value = 25;
            // 
            // metroTabPage6
            // 
            this.metroTabPage6.Controls.Add(this.metroLabel26);
            this.metroTabPage6.Controls.Add(this.metroButton6);
            this.metroTabPage6.Controls.Add(this.metroLabel20);
            this.metroTabPage6.Controls.Add(this.metroPanel3);
            this.metroTabPage6.Controls.Add(this.metroLabel22);
            this.metroTabPage6.Controls.Add(this.metroButton4);
            this.metroTabPage6.Controls.Add(this.panel1);
            this.metroTabPage6.CustomBackground = false;
            this.metroTabPage6.HorizontalScrollbar = false;
            this.metroTabPage6.HorizontalScrollbarBarColor = true;
            this.metroTabPage6.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage6.HorizontalScrollbarSize = 0;
            this.metroTabPage6.Location = new System.Drawing.Point(4, 35);
            this.metroTabPage6.Name = "metroTabPage6";
            this.metroTabPage6.Size = new System.Drawing.Size(668, 325);
            this.metroTabPage6.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTabPage6.StyleManager = this.metroStyleManager;
            this.metroTabPage6.TabIndex = 5;
            this.metroTabPage6.Tag = false;
            this.metroTabPage6.Text = "Controls 1";
            this.metroTabPage6.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTabPage6.VerticalScrollbar = false;
            this.metroTabPage6.VerticalScrollbarBarColor = false;
            this.metroTabPage6.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage6.VerticalScrollbarSize = 0;
            // 
            // metroLabel26
            // 
            this.metroLabel26.AutoSize = true;
            this.metroLabel26.CustomBackground = false;
            this.metroLabel26.FontSize = MetroFramework.MetroLabelSize.Medium;
            this.metroLabel26.FontWeight = MetroFramework.MetroLabelWeight.Light;
            this.metroLabel26.LabelMode = MetroFramework.Controls.MetroLabelMode.Default;
            this.metroLabel26.Location = new System.Drawing.Point(3, 179);
            this.metroLabel26.Name = "metroLabel26";
            this.metroLabel26.Size = new System.Drawing.Size(91, 19);
            this.metroLabel26.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroLabel26.StyleManager = this.metroStyleManager;
            this.metroLabel26.TabIndex = 41;
            this.metroLabel26.Text = "Context Menu";
            this.metroLabel26.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroLabel26.UseStyleColors = false;
            // 
            // metroButton6
            // 
            this.metroButton6.FontSize = MetroFramework.MetroButtonSize.Medium;
            this.metroButton6.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.metroButton6.Highlight = false;
            this.metroButton6.Location = new System.Drawing.Point(0, 201);
            this.metroButton6.Name = "metroButton6";
            this.metroButton6.Size = new System.Drawing.Size(205, 29);
            this.metroButton6.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroButton6.StyleManager = this.metroStyleManager;
            this.metroButton6.TabIndex = 40;
            this.metroButton6.Text = "STANDARD CONTEXT MENU";
            this.metroButton6.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroButton6.Click += new System.EventHandler(this.metroButton6_Click);
            // 
            // metroLabel20
            // 
            this.metroLabel20.AutoSize = true;
            this.metroLabel20.CustomBackground = false;
            this.metroLabel20.FontSize = MetroFramework.MetroLabelSize.Medium;
            this.metroLabel20.FontWeight = MetroFramework.MetroLabelWeight.Light;
            this.metroLabel20.LabelMode = MetroFramework.Controls.MetroLabelMode.Default;
            this.metroLabel20.Location = new System.Drawing.Point(3, 16);
            this.metroLabel20.Name = "metroLabel20";
            this.metroLabel20.Size = new System.Drawing.Size(175, 19);
            this.metroLabel20.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroLabel20.StyleManager = this.metroStyleManager;
            this.metroLabel20.TabIndex = 39;
            this.metroLabel20.Text = "Color&BlendAnimation Demo";
            this.metroLabel20.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroLabel20.UseStyleColors = false;
            // 
            // metroPanel3
            // 
            this.metroPanel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.metroPanel3.Controls.Add(this.statusStrip1);
            this.metroPanel3.Controls.Add(this.toolStrip1);
            this.metroPanel3.Controls.Add(this.menuStrip3);
            this.metroPanel3.CustomBackground = false;
            this.metroPanel3.HorizontalScrollbar = false;
            this.metroPanel3.HorizontalScrollbarBarColor = true;
            this.metroPanel3.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel3.HorizontalScrollbarSize = 10;
            this.metroPanel3.Location = new System.Drawing.Point(225, 40);
            this.metroPanel3.Name = "metroPanel3";
            this.metroPanel3.Size = new System.Drawing.Size(402, 266);
            this.metroPanel3.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroPanel3.StyleManager = this.metroStyleManager;
            this.metroPanel3.TabIndex = 37;
            this.metroPanel3.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroPanel3.VerticalScrollbar = false;
            this.metroPanel3.VerticalScrollbarBarColor = true;
            this.metroPanel3.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel3.VerticalScrollbarSize = 10;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripProgressBar1,
            this.toolStripDropDownButton1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 242);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.ManagerRenderMode;
            this.statusStrip1.Size = new System.Drawing.Size(400, 22);
            this.statusStrip1.TabIndex = 39;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(110, 17);
            this.toolStripStatusLabel1.Text = "Application Loaded";
            // 
            // toolStripProgressBar1
            // 
            this.toolStripProgressBar1.Name = "toolStripProgressBar1";
            this.toolStripProgressBar1.Size = new System.Drawing.Size(100, 16);
            // 
            // toolStripDropDownButton1
            // 
            this.toolStripDropDownButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripDropDownButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton1.Image")));
            this.toolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton1.Name = "toolStripDropDownButton1";
            this.toolStripDropDownButton1.Size = new System.Drawing.Size(29, 20);
            this.toolStripDropDownButton1.Text = "toolStripDropDownButton1";
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1,
            this.toolStripLabel1,
            this.toolStripSeparator2,
            this.toolStripButton5,
            this.toolStripSeparator3,
            this.toolStripDropDownButton2,
            this.toolStripButton2});
            this.toolStrip1.Location = new System.Drawing.Point(0, 24);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(400, 25);
            this.toolStrip1.TabIndex = 37;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = global::MetroFramework.Demo.Properties.Resources.Close;
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton1.Text = "toolStripButton1";
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(71, 22);
            this.toolStripLabel1.Text = "Sample Text";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton5.Image = global::MetroFramework.Demo.Properties.Resources.help;
            this.toolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton5.Text = "toolStripButton5";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripDropDownButton2
            // 
            this.toolStripDropDownButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripDropDownButton2.Image = global::MetroFramework.Demo.Properties.Resources.printer3;
            this.toolStripDropDownButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton2.Name = "toolStripDropDownButton2";
            this.toolStripDropDownButton2.Size = new System.Drawing.Size(29, 22);
            this.toolStripDropDownButton2.Text = "toolStripDropDownButton2";
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.Checked = true;
            this.toolStripButton2.CheckState = System.Windows.Forms.CheckState.Checked;
            this.toolStripButton2.Image = global::MetroFramework.Demo.Properties.Resources.preview;
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(68, 22);
            this.toolStripButton2.Text = "Preview";
            // 
            // menuStrip3
            // 
            this.menuStrip3.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem1,
            this.helpToolStripMenuItem2});
            this.menuStrip3.Location = new System.Drawing.Point(0, 0);
            this.menuStrip3.Name = "menuStrip3";
            this.menuStrip3.Size = new System.Drawing.Size(400, 24);
            this.menuStrip3.TabIndex = 38;
            this.menuStrip3.Text = "menuStrip3";
            // 
            // fileToolStripMenuItem1
            // 
            this.fileToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem1});
            this.fileToolStripMenuItem1.Name = "fileToolStripMenuItem1";
            this.fileToolStripMenuItem1.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem1.Text = "File";
            // 
            // exitToolStripMenuItem1
            // 
            this.exitToolStripMenuItem1.Image = global::MetroFramework.Demo.Properties.Resources.Close;
            this.exitToolStripMenuItem1.Name = "exitToolStripMenuItem1";
            this.exitToolStripMenuItem1.Size = new System.Drawing.Size(92, 22);
            this.exitToolStripMenuItem1.Text = "Exit";
            // 
            // helpToolStripMenuItem2
            // 
            this.helpToolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem2});
            this.helpToolStripMenuItem2.Name = "helpToolStripMenuItem2";
            this.helpToolStripMenuItem2.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem2.Text = "Help";
            // 
            // aboutToolStripMenuItem2
            // 
            this.aboutToolStripMenuItem2.Image = global::MetroFramework.Demo.Properties.Resources.help;
            this.aboutToolStripMenuItem2.Name = "aboutToolStripMenuItem2";
            this.aboutToolStripMenuItem2.Size = new System.Drawing.Size(107, 22);
            this.aboutToolStripMenuItem2.Text = "About";
            // 
            // metroLabel22
            // 
            this.metroLabel22.AutoSize = true;
            this.metroLabel22.CustomBackground = false;
            this.metroLabel22.FontSize = MetroFramework.MetroLabelSize.Medium;
            this.metroLabel22.FontWeight = MetroFramework.MetroLabelWeight.Light;
            this.metroLabel22.LabelMode = MetroFramework.Controls.MetroLabelMode.Default;
            this.metroLabel22.Location = new System.Drawing.Point(225, 16);
            this.metroLabel22.Name = "metroLabel22";
            this.metroLabel22.Size = new System.Drawing.Size(207, 19);
            this.metroLabel22.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroLabel22.StyleManager = this.metroStyleManager;
            this.metroLabel22.TabIndex = 16;
            this.metroLabel22.Text = "Standard Menu && Toolbars Styled";
            this.metroLabel22.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroLabel22.UseStyleColors = false;
            // 
            // metroButton4
            // 
            this.metroButton4.FontSize = MetroFramework.MetroButtonSize.Medium;
            this.metroButton4.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.metroButton4.Highlight = false;
            this.metroButton4.Location = new System.Drawing.Point(3, 140);
            this.metroButton4.Name = "metroButton4";
            this.metroButton4.Size = new System.Drawing.Size(202, 27);
            this.metroButton4.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroButton4.StyleManager = this.metroStyleManager;
            this.metroButton4.TabIndex = 14;
            this.metroButton4.Text = "BLEND COLOR";
            this.metroButton4.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroButton4.Click += new System.EventHandler(this.metroButton4_Click);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Location = new System.Drawing.Point(3, 40);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(202, 94);
            this.panel1.TabIndex = 13;
            // 
            // metroTabPage5
            // 
            this.metroTabPage5.Controls.Add(this.splitContainer1);
            this.metroTabPage5.CustomBackground = false;
            this.metroTabPage5.HorizontalScrollbar = false;
            this.metroTabPage5.HorizontalScrollbarBarColor = false;
            this.metroTabPage5.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage5.HorizontalScrollbarSize = 0;
            this.metroTabPage5.Location = new System.Drawing.Point(4, 35);
            this.metroTabPage5.Name = "metroTabPage5";
            this.metroTabPage5.Size = new System.Drawing.Size(668, 325);
            this.metroTabPage5.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTabPage5.StyleManager = this.metroStyleManager;
            this.metroTabPage5.TabIndex = 4;
            this.metroTabPage5.Tag = false;
            this.metroTabPage5.Text = "Controls 2";
            this.metroTabPage5.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTabPage5.VerticalScrollbar = false;
            this.metroTabPage5.VerticalScrollbarBarColor = false;
            this.metroTabPage5.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage5.VerticalScrollbarSize = 0;
            // 
            // splitContainer1
            // 
            this.splitContainer1.CustomBackground = false;
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.metroPanel1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.metroPanel2);
            this.splitContainer1.Size = new System.Drawing.Size(668, 325);
            this.splitContainer1.SplitterDistance = 47;
            this.splitContainer1.Style = MetroFramework.MetroColorStyle.Blue;
            this.splitContainer1.StyleManager = this.metroStyleManager;
            this.splitContainer1.TabIndex = 2;
            this.splitContainer1.Theme = MetroFramework.MetroThemeStyle.Light;
            // 
            // metroPanel1
            // 
            this.metroPanel1.Controls.Add(this.metroLabel25);
            this.metroPanel1.CustomBackground = false;
            this.metroPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroPanel1.HorizontalScrollbar = false;
            this.metroPanel1.HorizontalScrollbarBarColor = false;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 0;
            this.metroPanel1.Location = new System.Drawing.Point(0, 0);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(668, 47);
            this.metroPanel1.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroPanel1.StyleManager = this.metroStyleManager;
            this.metroPanel1.TabIndex = 0;
            this.metroPanel1.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroPanel1.VerticalScrollbar = false;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 0;
            // 
            // metroLabel25
            // 
            this.metroLabel25.AutoSize = true;
            this.metroLabel25.CustomBackground = false;
            this.metroLabel25.FontSize = MetroFramework.MetroLabelSize.Medium;
            this.metroLabel25.FontWeight = MetroFramework.MetroLabelWeight.Light;
            this.metroLabel25.LabelMode = MetroFramework.Controls.MetroLabelMode.Default;
            this.metroLabel25.Location = new System.Drawing.Point(3, 13);
            this.metroLabel25.Name = "metroLabel25";
            this.metroLabel25.Size = new System.Drawing.Size(101, 19);
            this.metroLabel25.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroLabel25.StyleManager = this.metroStyleManager;
            this.metroLabel25.TabIndex = 2;
            this.metroLabel25.Text = "Metro DataGrid";
            this.metroLabel25.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroLabel25.UseStyleColors = false;
            // 
            // metroPanel2
            // 
            this.metroPanel2.Controls.Add(this.metroGrid1);
            this.metroPanel2.CustomBackground = false;
            this.metroPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroPanel2.HorizontalScrollbar = false;
            this.metroPanel2.HorizontalScrollbarBarColor = false;
            this.metroPanel2.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel2.HorizontalScrollbarSize = 0;
            this.metroPanel2.Location = new System.Drawing.Point(0, 0);
            this.metroPanel2.Name = "metroPanel2";
            this.metroPanel2.Size = new System.Drawing.Size(668, 274);
            this.metroPanel2.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroPanel2.StyleManager = this.metroStyleManager;
            this.metroPanel2.TabIndex = 1;
            this.metroPanel2.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroPanel2.VerticalScrollbar = false;
            this.metroPanel2.VerticalScrollbarBarColor = true;
            this.metroPanel2.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel2.VerticalScrollbarSize = 0;
            // 
            // metroGrid1
            // 
            this.metroGrid1.AllowUserToResizeRows = false;
            this.metroGrid1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.metroGrid1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.metroGrid1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.metroGrid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.metroGrid1.DefaultCellStyle = dataGridViewCellStyle8;
            this.metroGrid1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroGrid1.EnableHeadersVisualStyles = false;
            this.metroGrid1.FontSize = MetroFramework.MetroDataGridSize.Medium;
            this.metroGrid1.FontWeight = MetroFramework.MetroDataGridWeight.Regular;
            this.metroGrid1.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.metroGrid1.Location = new System.Drawing.Point(0, 0);
            this.metroGrid1.Name = "metroGrid1";
            this.metroGrid1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid1.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.metroGrid1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.metroGrid1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.metroGrid1.Size = new System.Drawing.Size(668, 274);
            this.metroGrid1.TabIndex = 0;
            // 
            // metroTabPage7
            // 
            this.metroTabPage7.Controls.Add(this.metroSplitContainer1);
            this.metroTabPage7.CustomBackground = false;
            this.metroTabPage7.HorizontalScrollbar = false;
            this.metroTabPage7.HorizontalScrollbarBarColor = false;
            this.metroTabPage7.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage7.HorizontalScrollbarSize = 0;
            this.metroTabPage7.Location = new System.Drawing.Point(4, 35);
            this.metroTabPage7.Name = "metroTabPage7";
            this.metroTabPage7.Size = new System.Drawing.Size(668, 325);
            this.metroTabPage7.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTabPage7.StyleManager = this.metroStyleManager;
            this.metroTabPage7.TabIndex = 6;
            this.metroTabPage7.Tag = false;
            this.metroTabPage7.Text = "Controls 3";
            this.metroTabPage7.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTabPage7.VerticalScrollbar = false;
            this.metroTabPage7.VerticalScrollbarBarColor = false;
            this.metroTabPage7.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage7.VerticalScrollbarSize = 0;
            // 
            // metroSplitContainer1
            // 
            this.metroSplitContainer1.CustomBackground = false;
            this.metroSplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroSplitContainer1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroSplitContainer1.Location = new System.Drawing.Point(0, 0);
            this.metroSplitContainer1.Name = "metroSplitContainer1";
            // 
            // metroSplitContainer1.Panel1
            // 
            this.metroSplitContainer1.Panel1.Controls.Add(this.metroPropertyGrid1);
            // 
            // metroSplitContainer1.Panel2
            // 
            this.metroSplitContainer1.Panel2.Controls.Add(this.metroSplitContainer2);
            this.metroSplitContainer1.Size = new System.Drawing.Size(668, 325);
            this.metroSplitContainer1.SplitterDistance = 221;
            this.metroSplitContainer1.SplitterWidth = 10;
            this.metroSplitContainer1.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroSplitContainer1.StyleManager = this.metroStyleManager;
            this.metroSplitContainer1.TabIndex = 7;
            this.metroSplitContainer1.Theme = MetroFramework.MetroThemeStyle.Light;
            // 
            // metroPropertyGrid1
            // 
            this.metroPropertyGrid1.CategoryForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.metroPropertyGrid1.CustomBackground = false;
            this.metroPropertyGrid1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroPropertyGrid1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroPropertyGrid1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.metroPropertyGrid1.HelpBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.metroPropertyGrid1.HelpForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.metroPropertyGrid1.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.metroPropertyGrid1.Location = new System.Drawing.Point(0, 0);
            this.metroPropertyGrid1.Name = "metroPropertyGrid1";
            this.metroPropertyGrid1.SelectedObject = this.metroGroupBox1;
            this.metroPropertyGrid1.Size = new System.Drawing.Size(221, 325);
            this.metroPropertyGrid1.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroPropertyGrid1.StyleManager = this.metroStyleManager;
            this.metroPropertyGrid1.TabIndex = 2;
            this.metroPropertyGrid1.Theme = MetroFramework.MetroThemeStyle.Light;
            // 
            // metroGroupBox1
            // 
            this.metroGroupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGroupBox1.BorderStyle = MetroFramework.Controls.MetroGroupBox.BorderMode.Header;
            this.metroGroupBox1.Controls.Add(this.metroDomainUpDown1);
            this.metroGroupBox1.Controls.Add(this.metroLabel27);
            this.metroGroupBox1.Controls.Add(this.metroNumericUpDown1);
            this.metroGroupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroGroupBox1.DrawBottomLine = false;
            this.metroGroupBox1.DrawShadows = false;
            this.metroGroupBox1.Font = new System.Drawing.Font("Segoe UI Light", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroGroupBox1.FontSize = MetroFramework.MetroLabelSize.Medium;
            this.metroGroupBox1.FontWeight = MetroFramework.MetroLabelWeight.Light;
            this.metroGroupBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.metroGroupBox1.Location = new System.Drawing.Point(0, 0);
            this.metroGroupBox1.Name = "metroGroupBox1";
            this.metroGroupBox1.PaintDefault = false;
            this.metroGroupBox1.Size = new System.Drawing.Size(213, 148);
            this.metroGroupBox1.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroGroupBox1.StyleManager = this.metroStyleManager;
            this.metroGroupBox1.TabIndex = 3;
            this.metroGroupBox1.TabStop = false;
            this.metroGroupBox1.Text = "Metro GroupBox";
            this.metroGroupBox1.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroGroupBox1.UseStyleColors = false;
            // 
            // metroDomainUpDown1
            // 
            this.metroDomainUpDown1.CustomDrawButtons = false;
            this.metroDomainUpDown1.Font = new System.Drawing.Font("Segoe UI Light", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroDomainUpDown1.FontSize = MetroFramework.MetroLabelSize.Medium;
            this.metroDomainUpDown1.FontWeight = MetroFramework.MetroLabelWeight.Light;
            this.metroDomainUpDown1.Location = new System.Drawing.Point(20, 85);
            this.metroDomainUpDown1.Name = "metroDomainUpDown1";
            this.metroDomainUpDown1.Size = new System.Drawing.Size(166, 26);
            this.metroDomainUpDown1.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroDomainUpDown1.StyleManager = this.metroStyleManager;
            this.metroDomainUpDown1.TabIndex = 15;
            this.metroDomainUpDown1.Text = "MetroDomainUpDown";
            this.metroDomainUpDown1.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroDomainUpDown1.UseAlternateColors = false;
            this.metroDomainUpDown1.UseStyleColors = false;
            // 
            // metroLabel27
            // 
            this.metroLabel27.AutoSize = true;
            this.metroLabel27.CustomBackground = false;
            this.metroLabel27.FontSize = MetroFramework.MetroLabelSize.Medium;
            this.metroLabel27.FontWeight = MetroFramework.MetroLabelWeight.Light;
            this.metroLabel27.LabelMode = MetroFramework.Controls.MetroLabelMode.Default;
            this.metroLabel27.Location = new System.Drawing.Point(20, 31);
            this.metroLabel27.Name = "metroLabel27";
            this.metroLabel27.Size = new System.Drawing.Size(145, 19);
            this.metroLabel27.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroLabel27.StyleManager = this.metroStyleManager;
            this.metroLabel27.TabIndex = 12;
            this.metroLabel27.Text = "MetroNumericUpDown";
            this.metroLabel27.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroLabel27.UseStyleColors = false;
            // 
            // metroNumericUpDown1
            // 
            this.metroNumericUpDown1.CustomDrawButtons = false;
            this.metroNumericUpDown1.Font = new System.Drawing.Font("Segoe UI Light", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroNumericUpDown1.FontSize = MetroFramework.MetroLabelSize.Medium;
            this.metroNumericUpDown1.FontWeight = MetroFramework.MetroLabelWeight.Light;
            this.metroNumericUpDown1.Location = new System.Drawing.Point(20, 53);
            this.metroNumericUpDown1.Name = "metroNumericUpDown1";
            this.metroNumericUpDown1.Size = new System.Drawing.Size(70, 26);
            this.metroNumericUpDown1.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroNumericUpDown1.StyleManager = this.metroStyleManager;
            this.metroNumericUpDown1.TabIndex = 2;
            this.metroNumericUpDown1.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroNumericUpDown1.UseAlternateColors = false;
            this.metroNumericUpDown1.UseStyleColors = false;
            // 
            // metroSplitContainer2
            // 
            this.metroSplitContainer2.BackColor = System.Drawing.SystemColors.Control;
            this.metroSplitContainer2.CustomBackground = false;
            this.metroSplitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroSplitContainer2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroSplitContainer2.Location = new System.Drawing.Point(0, 0);
            this.metroSplitContainer2.Name = "metroSplitContainer2";
            // 
            // metroSplitContainer2.Panel1
            // 
            this.metroSplitContainer2.Panel1.Controls.Add(this.metroSplitContainer3);
            // 
            // metroSplitContainer2.Panel2
            // 
            this.metroSplitContainer2.Panel2.Controls.Add(this.metroSplitContainer4);
            this.metroSplitContainer2.Size = new System.Drawing.Size(437, 325);
            this.metroSplitContainer2.SplitterDistance = 213;
            this.metroSplitContainer2.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroSplitContainer2.StyleManager = this.metroStyleManager;
            this.metroSplitContainer2.TabIndex = 0;
            this.metroSplitContainer2.Theme = MetroFramework.MetroThemeStyle.Light;
            // 
            // metroSplitContainer3
            // 
            this.metroSplitContainer3.BackColor = System.Drawing.SystemColors.Control;
            this.metroSplitContainer3.CustomBackground = false;
            this.metroSplitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroSplitContainer3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroSplitContainer3.Location = new System.Drawing.Point(0, 0);
            this.metroSplitContainer3.Name = "metroSplitContainer3";
            this.metroSplitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // metroSplitContainer3.Panel1
            // 
            this.metroSplitContainer3.Panel1.Controls.Add(this.metroGroupBox1);
            // 
            // metroSplitContainer3.Panel2
            // 
            this.metroSplitContainer3.Panel2.Controls.Add(this.metroPanel4);
            this.metroSplitContainer3.Size = new System.Drawing.Size(213, 325);
            this.metroSplitContainer3.SplitterDistance = 148;
            this.metroSplitContainer3.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroSplitContainer3.StyleManager = this.metroStyleManager;
            this.metroSplitContainer3.TabIndex = 0;
            this.metroSplitContainer3.Theme = MetroFramework.MetroThemeStyle.Light;
            // 
            // metroPanel4
            // 
            this.metroPanel4.Controls.Add(this.metroLabel30);
            this.metroPanel4.Controls.Add(this.lblKnobValue);
            this.metroPanel4.Controls.Add(this.metroLabel28);
            this.metroPanel4.Controls.Add(this.metroKnobControl1);
            this.metroPanel4.CustomBackground = false;
            this.metroPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroPanel4.HorizontalScrollbar = false;
            this.metroPanel4.HorizontalScrollbarBarColor = true;
            this.metroPanel4.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel4.HorizontalScrollbarSize = 10;
            this.metroPanel4.Location = new System.Drawing.Point(0, 0);
            this.metroPanel4.Name = "metroPanel4";
            this.metroPanel4.Size = new System.Drawing.Size(213, 173);
            this.metroPanel4.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroPanel4.StyleManager = this.metroStyleManager;
            this.metroPanel4.TabIndex = 0;
            this.metroPanel4.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroPanel4.VerticalScrollbar = false;
            this.metroPanel4.VerticalScrollbarBarColor = true;
            this.metroPanel4.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel4.VerticalScrollbarSize = 10;
            // 
            // metroLabel30
            // 
            this.metroLabel30.AutoSize = true;
            this.metroLabel30.CustomBackground = false;
            this.metroLabel30.FontSize = MetroFramework.MetroLabelSize.Medium;
            this.metroLabel30.FontWeight = MetroFramework.MetroLabelWeight.Light;
            this.metroLabel30.LabelMode = MetroFramework.Controls.MetroLabelMode.Default;
            this.metroLabel30.Location = new System.Drawing.Point(20, 6);
            this.metroLabel30.Name = "metroLabel30";
            this.metroLabel30.Size = new System.Drawing.Size(119, 19);
            this.metroLabel30.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroLabel30.StyleManager = this.metroStyleManager;
            this.metroLabel30.TabIndex = 22;
            this.metroLabel30.Text = "MetroKnobControl";
            this.metroLabel30.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroLabel30.UseStyleColors = false;
            // 
            // lblKnobValue
            // 
            this.lblKnobValue.AutoSize = true;
            this.lblKnobValue.CustomBackground = false;
            this.lblKnobValue.FontSize = MetroFramework.MetroLabelSize.Medium;
            this.lblKnobValue.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.lblKnobValue.LabelMode = MetroFramework.Controls.MetroLabelMode.Default;
            this.lblKnobValue.Location = new System.Drawing.Point(109, 139);
            this.lblKnobValue.Name = "lblKnobValue";
            this.lblKnobValue.Size = new System.Drawing.Size(17, 19);
            this.lblKnobValue.Style = MetroFramework.MetroColorStyle.Blue;
            this.lblKnobValue.StyleManager = this.metroStyleManager;
            this.lblKnobValue.TabIndex = 21;
            this.lblKnobValue.Text = "0";
            this.lblKnobValue.Theme = MetroFramework.MetroThemeStyle.Light;
            this.lblKnobValue.UseStyleColors = false;
            // 
            // metroLabel28
            // 
            this.metroLabel28.AutoSize = true;
            this.metroLabel28.CustomBackground = false;
            this.metroLabel28.FontSize = MetroFramework.MetroLabelSize.Medium;
            this.metroLabel28.FontWeight = MetroFramework.MetroLabelWeight.Light;
            this.metroLabel28.LabelMode = MetroFramework.Controls.MetroLabelMode.Default;
            this.metroLabel28.Location = new System.Drawing.Point(61, 139);
            this.metroLabel28.Name = "metroLabel28";
            this.metroLabel28.Size = new System.Drawing.Size(44, 19);
            this.metroLabel28.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroLabel28.StyleManager = this.metroStyleManager;
            this.metroLabel28.TabIndex = 20;
            this.metroLabel28.Text = "Value:";
            this.metroLabel28.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroLabel28.UseStyleColors = false;
            // 
            // metroKnobControl1
            // 
            this.metroKnobControl1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.metroKnobControl1.ImeMode = System.Windows.Forms.ImeMode.On;
            this.metroKnobControl1.LargeChange = 20;
            this.metroKnobControl1.Location = new System.Drawing.Point(42, 28);
            this.metroKnobControl1.Maximum = 100;
            this.metroKnobControl1.Minimum = 0;
            this.metroKnobControl1.Name = "metroKnobControl1";
            this.metroKnobControl1.ShowLargeScale = true;
            this.metroKnobControl1.ShowSmallScale = false;
            this.metroKnobControl1.Size = new System.Drawing.Size(114, 108);
            this.metroKnobControl1.SizeLargeScaleMarker = 6;
            this.metroKnobControl1.SizeSmallScaleMarker = 3;
            this.metroKnobControl1.SmallChange = 5;
            this.metroKnobControl1.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroKnobControl1.StyleManager = this.metroStyleManager;
            this.metroKnobControl1.TabIndex = 2;
            this.metroKnobControl1.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroKnobControl1.UseStyleColors = false;
            this.metroKnobControl1.Value = 0;
            this.metroKnobControl1.ValueChanged += new MetroFramework.Controls.ValueChangedEventHandler(this.metroKnobControl1_ValueChanged);
            // 
            // metroSplitContainer4
            // 
            this.metroSplitContainer4.BackColor = System.Drawing.SystemColors.Control;
            this.metroSplitContainer4.CustomBackground = false;
            this.metroSplitContainer4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroSplitContainer4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroSplitContainer4.Location = new System.Drawing.Point(0, 0);
            this.metroSplitContainer4.Name = "metroSplitContainer4";
            this.metroSplitContainer4.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // metroSplitContainer4.Panel1
            // 
            this.metroSplitContainer4.Panel1.Controls.Add(this.metroGroupBox3);
            // 
            // metroSplitContainer4.Panel2
            // 
            this.metroSplitContainer4.Panel2.Controls.Add(this.metroPanel5);
            this.metroSplitContainer4.Size = new System.Drawing.Size(220, 325);
            this.metroSplitContainer4.SplitterDistance = 148;
            this.metroSplitContainer4.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroSplitContainer4.StyleManager = this.metroStyleManager;
            this.metroSplitContainer4.TabIndex = 1;
            this.metroSplitContainer4.Theme = MetroFramework.MetroThemeStyle.Light;
            // 
            // metroGroupBox3
            // 
            this.metroGroupBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGroupBox3.BorderStyle = MetroFramework.Controls.MetroGroupBox.BorderMode.FullCustom;
            this.metroGroupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroGroupBox3.DrawBottomLine = false;
            this.metroGroupBox3.DrawShadows = false;
            this.metroGroupBox3.Font = new System.Drawing.Font("Segoe UI Light", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroGroupBox3.FontSize = MetroFramework.MetroLabelSize.Medium;
            this.metroGroupBox3.FontWeight = MetroFramework.MetroLabelWeight.Light;
            this.metroGroupBox3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.metroGroupBox3.Location = new System.Drawing.Point(0, 0);
            this.metroGroupBox3.Name = "metroGroupBox3";
            this.metroGroupBox3.PaintDefault = false;
            this.metroGroupBox3.Size = new System.Drawing.Size(220, 148);
            this.metroGroupBox3.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroGroupBox3.StyleManager = this.metroStyleManager;
            this.metroGroupBox3.TabIndex = 5;
            this.metroGroupBox3.TabStop = false;
            this.metroGroupBox3.Text = "Metro GroupBox";
            this.metroGroupBox3.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroGroupBox3.UseStyleColors = false;
            // 
            // metroPanel5
            // 
            this.metroPanel5.CustomBackground = false;
            this.metroPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroPanel5.HorizontalScrollbar = false;
            this.metroPanel5.HorizontalScrollbarBarColor = true;
            this.metroPanel5.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel5.HorizontalScrollbarSize = 10;
            this.metroPanel5.Location = new System.Drawing.Point(0, 0);
            this.metroPanel5.Name = "metroPanel5";
            this.metroPanel5.Size = new System.Drawing.Size(220, 173);
            this.metroPanel5.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroPanel5.StyleManager = this.metroStyleManager;
            this.metroPanel5.TabIndex = 0;
            this.metroPanel5.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroPanel5.VerticalScrollbar = false;
            this.metroPanel5.VerticalScrollbarBarColor = true;
            this.metroPanel5.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel5.VerticalScrollbarSize = 10;
            // 
            // metroToolTip
            // 
            this.metroToolTip.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroToolTip.StyleManager = null;
            this.metroToolTip.Theme = MetroFramework.MetroThemeStyle.Light;
            // 
            // entry1ToolStripMenuItem
            // 
            this.entry1ToolStripMenuItem.Name = "entry1ToolStripMenuItem";
            this.entry1ToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.entry1ToolStripMenuItem.Text = "Entry 1";
            // 
            // entry2ToolStripMenuItem
            // 
            this.entry2ToolStripMenuItem.Name = "entry2ToolStripMenuItem";
            this.entry2ToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.entry2ToolStripMenuItem.Text = "Entry 2";
            // 
            // entry3ToolStripMenuItem
            // 
            this.entry3ToolStripMenuItem.Name = "entry3ToolStripMenuItem";
            this.entry3ToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.entry3ToolStripMenuItem.Text = "Entry 3";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(157, 6);
            // 
            // toolStripTextBox1
            // 
            this.toolStripTextBox1.Name = "toolStripTextBox1";
            this.toolStripTextBox1.Size = new System.Drawing.Size(100, 23);
            // 
            // rendererManager1
            // 
            this.rendererManager1.Renderers = MetroFramework.Components.Renderer.MetroRenderer;
            this.rendererManager1.Style = MetroFramework.MetroColorStyle.Blue;
            this.rendererManager1.Theme = MetroFramework.MetroThemeStyle.Light;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackImagePadding = new System.Windows.Forms.Padding(305, 10, 0, 0);
            this.ClientSize = new System.Drawing.Size(716, 444);
            this.Controls.Add(this.metroTabControl1);
            this.Name = "MainForm";
            this.StyleManager = this.metroStyleManager;
            this.Text = "metro framework extended";
            this.metroTabControl1.ResumeLayout(false);
            this.metroTabPage1.ResumeLayout(false);
            this.metroTabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.metroStyleManager)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.metroTabPage4.ResumeLayout(false);
            this.metroTabPage4.PerformLayout();
            this.metroTabPage2.ResumeLayout(false);
            this.metroTabPage2.PerformLayout();
            this.metroTabPage3.ResumeLayout(false);
            this.metroTabPage3.PerformLayout();
            this.metroTabPage6.ResumeLayout(false);
            this.metroTabPage6.PerformLayout();
            this.metroPanel3.ResumeLayout(false);
            this.metroPanel3.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.menuStrip3.ResumeLayout(false);
            this.menuStrip3.PerformLayout();
            this.metroTabPage5.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.ResumeLayout(false);
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            this.metroPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid1)).EndInit();
            this.metroTabPage7.ResumeLayout(false);
            this.metroSplitContainer1.Panel1.ResumeLayout(false);
            this.metroSplitContainer1.Panel2.ResumeLayout(false);
            this.metroSplitContainer1.ResumeLayout(false);
            this.metroGroupBox1.ResumeLayout(false);
            this.metroGroupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.metroNumericUpDown1)).EndInit();
            this.metroSplitContainer2.Panel1.ResumeLayout(false);
            this.metroSplitContainer2.Panel2.ResumeLayout(false);
            this.metroSplitContainer2.ResumeLayout(false);
            this.metroSplitContainer3.Panel1.ResumeLayout(false);
            this.metroSplitContainer3.Panel2.ResumeLayout(false);
            this.metroSplitContainer3.ResumeLayout(false);
            this.metroPanel4.ResumeLayout(false);
            this.metroPanel4.PerformLayout();
            this.metroSplitContainer4.Panel1.ResumeLayout(false);
            this.metroSplitContainer4.Panel2.ResumeLayout(false);
            this.metroSplitContainer4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Controls.MetroTabControl metroTabControl1;
        private Components.MetroStyleManager metroStyleManager;
        private Controls.MetroTabPage metroTabPage1;
        private Controls.MetroTile metroTileSwitch;
        private Controls.MetroTile metroTile2;
        private Controls.MetroTile metroTile1;
        private Components.MetroToolTip metroToolTip;
        private Controls.MetroButton metroButton3;
        private Controls.MetroButton metroButton2;
        private Controls.MetroButton metroButton1;
        private Controls.MetroLabel metroLabel1;
        private Controls.MetroTabPage metroTabPage2;
        private Controls.MetroRadioButton metroRadioButton1;
        private Controls.MetroToggle metroToggle1;
        private Controls.MetroCheckBox metroCheckBox1;
        private Controls.MetroTabPage metroTabPage3;
        private Controls.MetroLabel metroLabel7;
        private Controls.MetroProgressSpinner metroProgressSpinner3;
        private Controls.MetroProgressSpinner metroProgressSpinner2;
        private Controls.MetroLabel metroLabel6;
        private Controls.MetroLabel metroLabel5;
        private Controls.MetroProgressBar metroProgressBar1;
        private Controls.MetroLabel metroLabel4;
        private Controls.MetroScrollBar metroScrollBar1;
        private Controls.MetroTrackBar metroTrackBar1;
        private Controls.MetroProgressSpinner metroProgressSpinner1;
        private Controls.MetroProgressBar metroProgressBar;
        private Controls.MetroTabPage metroTabPage4;
        private Controls.MetroLabel metroLabel8;
        private Controls.MetroLabel metroLabel11;
        private Controls.MetroLabel metroLabel10;
        private Controls.MetroLabel metroLabel3;
        private Controls.MetroTextBox metroTextBox1;
        private Controls.MetroLabel metroLabel2;
        private Controls.MetroComboBox metroComboBox1;
        private Controls.MetroTextBox metroTextBox4;
        private Controls.MetroTextBox metroTextBox3;
        private Controls.MetroTextBox metroTextBox2;
        private Controls.MetroLabel metroLabel15;
        private Controls.MetroLabel metroLabel12;
        private Controls.MetroLabel metroLabel13;
        private Controls.MetroLabel metroLabel14;
        private Controls.MetroLabel metroLabel19;
        private Controls.MetroLabel metroLabel18;
        private Controls.MetroLabel metroLabel17;
        private Controls.MetroLabel metroLabel16;
        private Controls.MetroToggle metroToggle3;
        private Controls.MetroToggle metroToggle2;
        private Controls.MetroRadioButton metroRadioButton3;
        private Controls.MetroRadioButton metroRadioButton2;
        private Controls.MetroCheckBox metroCheckBox3;
        private Controls.MetroCheckBox metroCheckBox2;
        private Controls.MetroComboBox metroComboBox2;
        private Controls.MetroTabPage metroTabPage5;
        private MetroFramework.Controls.MetroSplitContainer splitContainer1;
        private Controls.MetroGrid metroGrid1;
        private Controls.MetroPanel metroPanel1;
        private Controls.MetroPanel metroPanel2;
        private System.Windows.Forms.ToolStripMenuItem entry1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem entry2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem entry3ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox1;
        private Components.MetroRendererManager rendererManager1;
        private Controls.MetroTabPage metroTabPage6;
        private Controls.MetroButton metroButton4;
        private System.Windows.Forms.Panel panel1;
        private Controls.MetroLabel mlSelectedColor;
        private Controls.MetroLabel metroLabel21;
        private Controls.MetroLabel mlSelectedTheme;
        private Controls.MetroLabel metroLabel23;
        private Controls.MetroPanel metroPanel3;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.MenuStrip menuStrip3;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem2;
        private Controls.MetroLabel metroLabel22;
        private Controls.MetroLabel metroLabel20;
        private Controls.MetroLabel metroLabel25;
        private Controls.MetroButton metroButton6;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem entry1ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem entry2ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem entry3ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripProgressBar toolStripProgressBar1;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton2;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private Controls.MetroLabel metroLabel26;
        private Controls.MetroTabPage metroTabPage7;
        private Controls.MetroLabel metroLabel29;
        private Controls.MetroToggle metroToggle4;
        private Controls.MetroGroupBox metroGroupBox1;
        private Controls.MetroPropertyGrid metroPropertyGrid1;
        private Controls.MetroGroupBox metroGroupBox3;
        private Controls.MetroSplitContainer metroSplitContainer1;
        private Controls.MetroSplitContainer metroSplitContainer2;
        private Controls.MetroSplitContainer metroSplitContainer3;
        private Controls.MetroSplitContainer metroSplitContainer4;
        private Controls.MetroPanel metroPanel4;
        private Controls.MetroPanel metroPanel5;
        private Controls.MetroLabel lblKnobValue;
        private Controls.MetroLabel metroLabel28;
        private Controls.MetroKnobControl metroKnobControl1;
        private Controls.MetroNumericUpDown metroNumericUpDown1;
        private Controls.MetroSplitButton metroSplitButton1;
        private Controls.MetroDateTime metroDateTime1;
        private Controls.MetroLabel metroLabel24;
        private Controls.MetroDomainUpDown metroDomainUpDown1;
        private Controls.MetroLabel metroLabel27;
        private Controls.MetroLabel metroLabel30;
        private Controls.MetroButtonStyled metroButtonStyled1;
        private Controls.MetroLink metroLink4;
        private Controls.MetroLink metroLink3;
        private Controls.MetroLabel metroLabel9;
        private Controls.MetroLink metroLink1;
    }
}

