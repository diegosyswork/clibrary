﻿namespace MetroSet_UI.Design
{
    public enum Style
    {
        Light,
        Dark,
        Custom
    }
}