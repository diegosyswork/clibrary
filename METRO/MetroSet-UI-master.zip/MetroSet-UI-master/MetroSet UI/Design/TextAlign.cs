﻿namespace MetroSet_UI.Design
{
    public enum TextAlign
    {
        Left,
        Center,
        Right
    }
}