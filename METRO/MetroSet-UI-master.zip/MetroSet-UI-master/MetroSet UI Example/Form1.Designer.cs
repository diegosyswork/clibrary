﻿namespace MetroSet_UI_Example
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.metroSetTabControl1 = new MetroSet_UI.Controls.MetroSetTabControl();
            this.metroSetTabPage2 = new MetroSet_UI.Child.MetroSetTabPage();
            this.metroSetButton2 = new MetroSet_UI.Controls.MetroSetButton();
            this.styleManager1 = new MetroSet_UI.StyleManager();
            this.metroSetButton1 = new MetroSet_UI.Controls.MetroSetButton();
            this.metroSetEllipse3 = new MetroSet_UI.Controls.MetroSetEllipse();
            this.metroSetEllipse2 = new MetroSet_UI.Controls.MetroSetEllipse();
            this.metroSetEllipse1 = new MetroSet_UI.Controls.MetroSetEllipse();
            this.metroSetBadge2 = new MetroSet_UI.Controls.MetroSetBadge();
            this.metroSetBadge1 = new MetroSet_UI.Controls.MetroSetBadge();
            this.metroSetLabel2 = new MetroSet_UI.Controls.MetroSetLabel();
            this.metroSetLabel3 = new MetroSet_UI.Controls.MetroSetLabel();
            this.metroSetLabel19 = new MetroSet_UI.Controls.MetroSetLabel();
            this.metroSetLabel1 = new MetroSet_UI.Controls.MetroSetLabel();
            this.metroSetDefaultButton2 = new MetroSet_UI.Controls.MetroDefaultSetButton();
            this.metroSetDefaultButton1 = new MetroSet_UI.Controls.MetroDefaultSetButton();
            this.metroSetTabPage1 = new MetroSet_UI.Child.MetroSetTabPage();
            this.metroSetTile8 = new MetroSet_UI.Controls.MetroSetTile();
            this.metroSetTile4 = new MetroSet_UI.Controls.MetroSetTile();
            this.metroSetTile7 = new MetroSet_UI.Controls.MetroSetTile();
            this.metroSetTile6 = new MetroSet_UI.Controls.MetroSetTile();
            this.metroSetTile2 = new MetroSet_UI.Controls.MetroSetTile();
            this.metroSetTile5 = new MetroSet_UI.Controls.MetroSetTile();
            this.metroSetTile3 = new MetroSet_UI.Controls.MetroSetTile();
            this.metroSetTile1 = new MetroSet_UI.Controls.MetroSetTile();
            this.metroSetLabel4 = new MetroSet_UI.Controls.MetroSetLabel();
            this.metroSetTabPage3 = new MetroSet_UI.Child.MetroSetTabPage();
            this.metroSetListBox2 = new MetroSet_UI.Controls.MetroSetListBox();
            this.metroSetComboBox2 = new MetroSet_UI.Controls.MetroSetComboBox();
            this.metroSetComboBox1 = new MetroSet_UI.Controls.MetroSetComboBox();
            this.metroSetNumeric3 = new MetroSet_UI.Controls.MetroSetNumeric();
            this.metroSetNumeric2 = new MetroSet_UI.Controls.MetroSetNumeric();
            this.metroSetRichTextBox1 = new MetroSet_UI.Controls.MetroSetRichTextBox();
            this.metroSetTextBox3 = new MetroSet_UI.Controls.MetroSetTextBox();
            this.metroSetTextBox2 = new MetroSet_UI.Controls.MetroSetTextBox();
            this.metroSetTextBox4 = new MetroSet_UI.Controls.MetroSetTextBox();
            this.metroSetTextBox1 = new MetroSet_UI.Controls.MetroSetTextBox();
            this.metroSetContextMenuStrip1 = new MetroSet_UI.Controls.MetroSetContextMenuStrip();
            this.textBoxToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.metroSetLabel8 = new MetroSet_UI.Controls.MetroSetLabel();
            this.metroSetLabel9 = new MetroSet_UI.Controls.MetroSetLabel();
            this.metroSetLabel6 = new MetroSet_UI.Controls.MetroSetLabel();
            this.metroSetLabel7 = new MetroSet_UI.Controls.MetroSetLabel();
            this.metroSetLabel5 = new MetroSet_UI.Controls.MetroSetLabel();
            this.metroSetTabPage4 = new MetroSet_UI.Child.MetroSetTabPage();
            this.metroSetSwitch4 = new MetroSet_UI.Controls.MetroSetSwitch();
            this.metroSetSwitch3 = new MetroSet_UI.Controls.MetroSetSwitch();
            this.metroSetSwitch2 = new MetroSet_UI.Controls.MetroSetSwitch();
            this.metroSetSwitch1 = new MetroSet_UI.Controls.MetroSetSwitch();
            this.metroSetLabel12 = new MetroSet_UI.Controls.MetroSetLabel();
            this.metroSetRadioButton4 = new MetroSet_UI.Controls.MetroSetRadioButton();
            this.metroSetRadioButton3 = new MetroSet_UI.Controls.MetroSetRadioButton();
            this.metroSetRadioButton2 = new MetroSet_UI.Controls.MetroSetRadioButton();
            this.metroSetRadioButton1 = new MetroSet_UI.Controls.MetroSetRadioButton();
            this.metroSetCheckBox5 = new MetroSet_UI.Controls.MetroSetCheckBox();
            this.metroSetCheckBox4 = new MetroSet_UI.Controls.MetroSetCheckBox();
            this.metroSetCheckBox3 = new MetroSet_UI.Controls.MetroSetCheckBox();
            this.metroSetCheckBox2 = new MetroSet_UI.Controls.MetroSetCheckBox();
            this.metroSetCheckBox6 = new MetroSet_UI.Controls.MetroSetCheckBox();
            this.metroSetCheckBox1 = new MetroSet_UI.Controls.MetroSetCheckBox();
            this.metroSetLabel11 = new MetroSet_UI.Controls.MetroSetLabel();
            this.metroSetLabel10 = new MetroSet_UI.Controls.MetroSetLabel();
            this.metroSetTabPage5 = new MetroSet_UI.Child.MetroSetTabPage();
            this.metroSetTrackBar2 = new MetroSet_UI.Controls.MetroSetTrackBar();
            this.metroSetTrackBar1 = new MetroSet_UI.Controls.MetroSetTrackBar();
            this.metroSetProgressBar4 = new MetroSet_UI.Controls.MetroSetProgressBar();
            this.metroSetProgressBar3 = new MetroSet_UI.Controls.MetroSetProgressBar();
            this.metroSetLabel14 = new MetroSet_UI.Controls.MetroSetLabel();
            this.metroSetLabel15 = new MetroSet_UI.Controls.MetroSetLabel();
            this.metroSetLabel13 = new MetroSet_UI.Controls.MetroSetLabel();
            this.metroSetProgressBar2 = new MetroSet_UI.Controls.MetroSetProgressBar();
            this.metroSetProgressBar1 = new MetroSet_UI.Controls.MetroSetProgressBar();
            this.metroSetTabPage6 = new MetroSet_UI.Child.MetroSetTabPage();
            this.metroSetLink2 = new MetroSet_UI.Controls.MetroSetLink();
            this.metroSetLink1 = new MetroSet_UI.Controls.MetroSetLink();
            this.metroSetLabel17 = new MetroSet_UI.Controls.MetroSetLabel();
            this.metroSetLabel16 = new MetroSet_UI.Controls.MetroSetLabel();
            this.metroSetTabPage7 = new MetroSet_UI.Child.MetroSetTabPage();
            this.metroSetButton7 = new MetroSet_UI.Controls.MetroDefaultSetButton();
            this.metroSetButton6 = new MetroSet_UI.Controls.MetroDefaultSetButton();
            this.metroSetButton5 = new MetroSet_UI.Controls.MetroDefaultSetButton();
            this.metroSetButton4 = new MetroSet_UI.Controls.MetroDefaultSetButton();
            this.metroSetButton3 = new MetroSet_UI.Controls.MetroDefaultSetButton();
            this.metroSetLabel18 = new MetroSet_UI.Controls.MetroSetLabel();
            this.metroSetControlBox1 = new MetroSet_UI.Controls.MetroSetControlBox();
            this.metroSetToolTip1 = new MetroSet_UI.Components.MetroSetToolTip();
            this.metroSetTabControl1.SuspendLayout();
            this.metroSetTabPage2.SuspendLayout();
            this.metroSetTabPage1.SuspendLayout();
            this.metroSetTabPage3.SuspendLayout();
            this.metroSetContextMenuStrip1.SuspendLayout();
            this.metroSetTabPage4.SuspendLayout();
            this.metroSetTabPage5.SuspendLayout();
            this.metroSetTabPage6.SuspendLayout();
            this.metroSetTabPage7.SuspendLayout();
            this.SuspendLayout();
            // 
            // metroSetTabControl1
            // 
            this.metroSetTabControl1.Controls.Add(this.metroSetTabPage2);
            this.metroSetTabControl1.Controls.Add(this.metroSetTabPage1);
            this.metroSetTabControl1.Controls.Add(this.metroSetTabPage3);
            this.metroSetTabControl1.Controls.Add(this.metroSetTabPage4);
            this.metroSetTabControl1.Controls.Add(this.metroSetTabPage5);
            this.metroSetTabControl1.Controls.Add(this.metroSetTabPage6);
            this.metroSetTabControl1.Controls.Add(this.metroSetTabPage7);
            this.metroSetTabControl1.Cursor = System.Windows.Forms.Cursors.Default;
            this.metroSetTabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroSetTabControl1.ItemSize = new System.Drawing.Size(100, 38);
            this.metroSetTabControl1.Location = new System.Drawing.Point(12, 70);
            this.metroSetTabControl1.Name = "metroSetTabControl1";
            this.metroSetTabControl1.SelectedIndex = 0;
            this.metroSetTabControl1.Size = new System.Drawing.Size(1114, 616);
            this.metroSetTabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.metroSetTabControl1.Speed = 100;
            this.metroSetTabControl1.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetTabControl1.StyleManager = this.styleManager1;
            this.metroSetTabControl1.TabIndex = 0;
            this.metroSetTabControl1.TabStyle = MetroSet_UI.Enums.TabStyle.Style1;
            this.metroSetTabControl1.ThemeAuthor = "Narwin";
            this.metroSetTabControl1.ThemeName = "MetroLite";
            this.metroSetTabControl1.UseAnimation = true;
            // 
            // metroSetTabPage2
            // 
            this.metroSetTabPage2.BaseColor = System.Drawing.Color.White;
            this.metroSetTabPage2.Controls.Add(this.metroSetButton2);
            this.metroSetTabPage2.Controls.Add(this.metroSetButton1);
            this.metroSetTabPage2.Controls.Add(this.metroSetEllipse3);
            this.metroSetTabPage2.Controls.Add(this.metroSetEllipse2);
            this.metroSetTabPage2.Controls.Add(this.metroSetEllipse1);
            this.metroSetTabPage2.Controls.Add(this.metroSetBadge2);
            this.metroSetTabPage2.Controls.Add(this.metroSetBadge1);
            this.metroSetTabPage2.Controls.Add(this.metroSetLabel2);
            this.metroSetTabPage2.Controls.Add(this.metroSetLabel3);
            this.metroSetTabPage2.Controls.Add(this.metroSetLabel19);
            this.metroSetTabPage2.Controls.Add(this.metroSetLabel1);
            this.metroSetTabPage2.Controls.Add(this.metroSetDefaultButton2);
            this.metroSetTabPage2.Controls.Add(this.metroSetDefaultButton1);
            this.metroSetTabPage2.ImageIndex = 0;
            this.metroSetTabPage2.ImageKey = null;
            this.metroSetTabPage2.Location = new System.Drawing.Point(4, 42);
            this.metroSetTabPage2.Name = "metroSetTabPage2";
            this.metroSetTabPage2.Size = new System.Drawing.Size(1106, 570);
            this.metroSetTabPage2.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetTabPage2.StyleManager = this.styleManager1;
            this.metroSetTabPage2.TabIndex = 1;
            this.metroSetTabPage2.Text = "ButtonBase";
            this.metroSetTabPage2.ThemeAuthor = "Narwin";
            this.metroSetTabPage2.ThemeName = "MetroLite";
            this.metroSetTabPage2.ToolTipText = null;
            // 
            // metroSetButton2
            // 
            this.metroSetButton2.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetButton2.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetButton2.DisabledForeColor = System.Drawing.Color.Gray;
            this.metroSetButton2.Enabled = false;
            this.metroSetButton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetButton2.HoverBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(95)))), ((int)(((byte)(207)))), ((int)(((byte)(255)))));
            this.metroSetButton2.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(95)))), ((int)(((byte)(207)))), ((int)(((byte)(255)))));
            this.metroSetButton2.HoverTextColor = System.Drawing.Color.White;
            this.metroSetButton2.Location = new System.Drawing.Point(376, 171);
            this.metroSetButton2.Name = "metroSetButton2";
            this.metroSetButton2.NormalBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetButton2.NormalColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetButton2.NormalTextColor = System.Drawing.Color.White;
            this.metroSetButton2.PressBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(147)))), ((int)(((byte)(195)))));
            this.metroSetButton2.PressColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(147)))), ((int)(((byte)(195)))));
            this.metroSetButton2.PressTextColor = System.Drawing.Color.White;
            this.metroSetButton2.Size = new System.Drawing.Size(180, 40);
            this.metroSetButton2.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetButton2.StyleManager = this.styleManager1;
            this.metroSetButton2.TabIndex = 9;
            this.metroSetButton2.Text = "Disabled button";
            this.metroSetButton2.ThemeAuthor = "Narwin";
            this.metroSetButton2.ThemeName = "MetroLite";
            // 
            // styleManager1
            // 
            this.styleManager1.CustomTheme = "C:\\Users\\Halloween\\Desktop\\MetroSet Theme.xml";
            this.styleManager1.MetroForm = this;
            this.styleManager1.Style = MetroSet_UI.Design.Style.Light;
            this.styleManager1.ThemeAuthor = "Narwin";
            this.styleManager1.ThemeName = "MetroLite";
            // 
            // metroSetButton1
            // 
            this.metroSetButton1.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetButton1.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetButton1.DisabledForeColor = System.Drawing.Color.Gray;
            this.metroSetButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetButton1.HoverBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(95)))), ((int)(((byte)(207)))), ((int)(((byte)(255)))));
            this.metroSetButton1.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(95)))), ((int)(((byte)(207)))), ((int)(((byte)(255)))));
            this.metroSetButton1.HoverTextColor = System.Drawing.Color.White;
            this.metroSetButton1.Location = new System.Drawing.Point(376, 104);
            this.metroSetButton1.Name = "metroSetButton1";
            this.metroSetButton1.NormalBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetButton1.NormalColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetButton1.NormalTextColor = System.Drawing.Color.White;
            this.metroSetButton1.PressBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(147)))), ((int)(((byte)(195)))));
            this.metroSetButton1.PressColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(147)))), ((int)(((byte)(195)))));
            this.metroSetButton1.PressTextColor = System.Drawing.Color.White;
            this.metroSetButton1.Size = new System.Drawing.Size(180, 40);
            this.metroSetButton1.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetButton1.StyleManager = this.styleManager1;
            this.metroSetButton1.TabIndex = 9;
            this.metroSetButton1.Text = "Normal button";
            this.metroSetButton1.ThemeAuthor = "Narwin";
            this.metroSetButton1.ThemeName = "MetroLite";
            // 
            // metroSetEllipse3
            // 
            this.metroSetEllipse3.BackColor = System.Drawing.Color.Transparent;
            this.metroSetEllipse3.BorderThickness = 5;
            this.metroSetEllipse3.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.metroSetEllipse3.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.metroSetEllipse3.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.metroSetEllipse3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetEllipse3.HoverBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.metroSetEllipse3.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.metroSetEllipse3.HoverTextColor = System.Drawing.Color.White;
            this.metroSetEllipse3.Image = ((System.Drawing.Image)(resources.GetObject("metroSetEllipse3.Image")));
            this.metroSetEllipse3.ImageSize = new System.Drawing.Size(64, 64);
            this.metroSetEllipse3.Location = new System.Drawing.Point(793, 234);
            this.metroSetEllipse3.Name = "metroSetEllipse3";
            this.metroSetEllipse3.NormalBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.metroSetEllipse3.NormalColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.metroSetEllipse3.NormalTextColor = System.Drawing.Color.Black;
            this.metroSetEllipse3.PressBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.metroSetEllipse3.PressColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.metroSetEllipse3.PressTextColor = System.Drawing.Color.White;
            this.metroSetEllipse3.Size = new System.Drawing.Size(139, 122);
            this.metroSetEllipse3.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetEllipse3.StyleManager = this.styleManager1;
            this.metroSetEllipse3.TabIndex = 5;
            this.metroSetEllipse3.ThemeAuthor = "Narwin";
            this.metroSetEllipse3.ThemeName = "MetroLite";
            // 
            // metroSetEllipse2
            // 
            this.metroSetEllipse2.BackColor = System.Drawing.Color.Transparent;
            this.metroSetEllipse2.BorderThickness = 7;
            this.metroSetEllipse2.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.metroSetEllipse2.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.metroSetEllipse2.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.metroSetEllipse2.Enabled = false;
            this.metroSetEllipse2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetEllipse2.HoverBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.metroSetEllipse2.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.metroSetEllipse2.HoverTextColor = System.Drawing.Color.White;
            this.metroSetEllipse2.Image = null;
            this.metroSetEllipse2.ImageSize = new System.Drawing.Size(64, 64);
            this.metroSetEllipse2.Location = new System.Drawing.Point(870, 104);
            this.metroSetEllipse2.Name = "metroSetEllipse2";
            this.metroSetEllipse2.NormalBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.metroSetEllipse2.NormalColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.metroSetEllipse2.NormalTextColor = System.Drawing.Color.Black;
            this.metroSetEllipse2.PressBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.metroSetEllipse2.PressColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.metroSetEllipse2.PressTextColor = System.Drawing.Color.White;
            this.metroSetEllipse2.Size = new System.Drawing.Size(139, 122);
            this.metroSetEllipse2.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetEllipse2.StyleManager = this.styleManager1;
            this.metroSetEllipse2.TabIndex = 5;
            this.metroSetEllipse2.Text = "Disabled Ellipse";
            this.metroSetEllipse2.ThemeAuthor = "Narwin";
            this.metroSetEllipse2.ThemeName = "MetroLite";
            // 
            // metroSetEllipse1
            // 
            this.metroSetEllipse1.BackColor = System.Drawing.Color.Transparent;
            this.metroSetEllipse1.BorderThickness = 7;
            this.metroSetEllipse1.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.metroSetEllipse1.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.metroSetEllipse1.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.metroSetEllipse1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetEllipse1.HoverBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.metroSetEllipse1.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.metroSetEllipse1.HoverTextColor = System.Drawing.Color.White;
            this.metroSetEllipse1.Image = null;
            this.metroSetEllipse1.ImageSize = new System.Drawing.Size(64, 64);
            this.metroSetEllipse1.Location = new System.Drawing.Point(714, 104);
            this.metroSetEllipse1.Name = "metroSetEllipse1";
            this.metroSetEllipse1.NormalBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.metroSetEllipse1.NormalColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.metroSetEllipse1.NormalTextColor = System.Drawing.Color.Black;
            this.metroSetEllipse1.PressBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.metroSetEllipse1.PressColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.metroSetEllipse1.PressTextColor = System.Drawing.Color.White;
            this.metroSetEllipse1.Size = new System.Drawing.Size(139, 122);
            this.metroSetEllipse1.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetEllipse1.StyleManager = this.styleManager1;
            this.metroSetEllipse1.TabIndex = 5;
            this.metroSetEllipse1.Text = "Ellipse Button";
            this.metroSetEllipse1.ThemeAuthor = "Narwin";
            this.metroSetEllipse1.ThemeName = "MetroLite";
            // 
            // metroSetBadge2
            // 
            this.metroSetBadge2.BackColor = System.Drawing.Color.Transparent;
            this.metroSetBadge2.BadgeAlignment = MetroSet_UI.Enums.BadgeAlign.TopRight;
            this.metroSetBadge2.BadgeText = "A";
            this.metroSetBadge2.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.metroSetBadge2.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.metroSetBadge2.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.metroSetBadge2.Enabled = false;
            this.metroSetBadge2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetBadge2.HoverBadgeColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(187)))), ((int)(((byte)(245)))));
            this.metroSetBadge2.HoverBadgeTextColor = System.Drawing.Color.White;
            this.metroSetBadge2.HoverBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.metroSetBadge2.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.metroSetBadge2.HoverTextColor = System.Drawing.Color.White;
            this.metroSetBadge2.Location = new System.Drawing.Point(376, 289);
            this.metroSetBadge2.Name = "metroSetBadge2";
            this.metroSetBadge2.NormalBadgeColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetBadge2.NormalBadgeTextColor = System.Drawing.Color.White;
            this.metroSetBadge2.NormalBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.metroSetBadge2.NormalColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.metroSetBadge2.NormalTextColor = System.Drawing.Color.Black;
            this.metroSetBadge2.PressBadgeColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(147)))), ((int)(((byte)(205)))));
            this.metroSetBadge2.PressBadgeTextColor = System.Drawing.Color.White;
            this.metroSetBadge2.PressBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.metroSetBadge2.PressColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.metroSetBadge2.PressTextColor = System.Drawing.Color.White;
            this.metroSetBadge2.Size = new System.Drawing.Size(198, 67);
            this.metroSetBadge2.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetBadge2.StyleManager = this.styleManager1;
            this.metroSetBadge2.TabIndex = 4;
            this.metroSetBadge2.Text = "Disabled Badge Button";
            this.metroSetBadge2.ThemeAuthor = "Narwin";
            this.metroSetBadge2.ThemeName = "MetroLite";
            // 
            // metroSetBadge1
            // 
            this.metroSetBadge1.BackColor = System.Drawing.Color.Transparent;
            this.metroSetBadge1.BadgeAlignment = MetroSet_UI.Enums.BadgeAlign.TopRight;
            this.metroSetBadge1.BadgeText = "A";
            this.metroSetBadge1.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.metroSetBadge1.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.metroSetBadge1.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.metroSetBadge1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetBadge1.HoverBadgeColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(187)))), ((int)(((byte)(245)))));
            this.metroSetBadge1.HoverBadgeTextColor = System.Drawing.Color.White;
            this.metroSetBadge1.HoverBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.metroSetBadge1.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.metroSetBadge1.HoverTextColor = System.Drawing.Color.White;
            this.metroSetBadge1.Location = new System.Drawing.Point(15, 289);
            this.metroSetBadge1.Name = "metroSetBadge1";
            this.metroSetBadge1.NormalBadgeColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetBadge1.NormalBadgeTextColor = System.Drawing.Color.White;
            this.metroSetBadge1.NormalBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.metroSetBadge1.NormalColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.metroSetBadge1.NormalTextColor = System.Drawing.Color.Black;
            this.metroSetBadge1.PressBadgeColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(147)))), ((int)(((byte)(205)))));
            this.metroSetBadge1.PressBadgeTextColor = System.Drawing.Color.White;
            this.metroSetBadge1.PressBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.metroSetBadge1.PressColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.metroSetBadge1.PressTextColor = System.Drawing.Color.White;
            this.metroSetBadge1.Size = new System.Drawing.Size(195, 67);
            this.metroSetBadge1.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetBadge1.StyleManager = this.styleManager1;
            this.metroSetBadge1.TabIndex = 3;
            this.metroSetBadge1.Text = "Normal Badge Button";
            this.metroSetBadge1.ThemeAuthor = "Narwin";
            this.metroSetBadge1.ThemeName = "MetroLite";
            // 
            // metroSetLabel2
            // 
            this.metroSetLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetLabel2.Location = new System.Drawing.Point(15, 259);
            this.metroSetLabel2.Name = "metroSetLabel2";
            this.metroSetLabel2.Size = new System.Drawing.Size(100, 23);
            this.metroSetLabel2.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetLabel2.StyleManager = this.styleManager1;
            this.metroSetLabel2.TabIndex = 2;
            this.metroSetLabel2.Text = "Badge Button";
            this.metroSetLabel2.ThemeAuthor = "Narwin";
            this.metroSetLabel2.ThemeName = "MetroLite";
            // 
            // metroSetLabel3
            // 
            this.metroSetLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetLabel3.Location = new System.Drawing.Point(810, 59);
            this.metroSetLabel3.Name = "metroSetLabel3";
            this.metroSetLabel3.Size = new System.Drawing.Size(100, 23);
            this.metroSetLabel3.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetLabel3.StyleManager = this.styleManager1;
            this.metroSetLabel3.TabIndex = 1;
            this.metroSetLabel3.Text = "Ellipse Button";
            this.metroSetLabel3.ThemeAuthor = "Narwin";
            this.metroSetLabel3.ThemeName = "MetroLite";
            // 
            // metroSetLabel19
            // 
            this.metroSetLabel19.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetLabel19.Location = new System.Drawing.Point(376, 59);
            this.metroSetLabel19.Name = "metroSetLabel19";
            this.metroSetLabel19.Size = new System.Drawing.Size(100, 23);
            this.metroSetLabel19.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetLabel19.StyleManager = this.styleManager1;
            this.metroSetLabel19.TabIndex = 1;
            this.metroSetLabel19.Text = "Normal Button";
            this.metroSetLabel19.ThemeAuthor = "Narwin";
            this.metroSetLabel19.ThemeName = "MetroLite";
            // 
            // metroSetLabel1
            // 
            this.metroSetLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetLabel1.Location = new System.Drawing.Point(15, 59);
            this.metroSetLabel1.Name = "metroSetLabel1";
            this.metroSetLabel1.Size = new System.Drawing.Size(100, 23);
            this.metroSetLabel1.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetLabel1.StyleManager = this.styleManager1;
            this.metroSetLabel1.TabIndex = 1;
            this.metroSetLabel1.Text = "Default Button";
            this.metroSetLabel1.ThemeAuthor = "Narwin";
            this.metroSetLabel1.ThemeName = "MetroLite";
            // 
            // metroSetDefaultButton2
            // 
            this.metroSetDefaultButton2.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.metroSetDefaultButton2.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.metroSetDefaultButton2.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.metroSetDefaultButton2.Enabled = false;
            this.metroSetDefaultButton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetDefaultButton2.HoverBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.metroSetDefaultButton2.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.metroSetDefaultButton2.HoverTextColor = System.Drawing.Color.White;
            this.metroSetDefaultButton2.Location = new System.Drawing.Point(15, 171);
            this.metroSetDefaultButton2.Name = "metroSetDefaultButton2";
            this.metroSetDefaultButton2.NormalBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.metroSetDefaultButton2.NormalColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.metroSetDefaultButton2.NormalTextColor = System.Drawing.Color.Black;
            this.metroSetDefaultButton2.PressBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.metroSetDefaultButton2.PressColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.metroSetDefaultButton2.PressTextColor = System.Drawing.Color.White;
            this.metroSetDefaultButton2.Size = new System.Drawing.Size(180, 40);
            this.metroSetDefaultButton2.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetDefaultButton2.StyleManager = this.styleManager1;
            this.metroSetDefaultButton2.TabIndex = 0;
            this.metroSetDefaultButton2.Text = "Disabled button";
            this.metroSetDefaultButton2.ThemeAuthor = "Narwin";
            this.metroSetDefaultButton2.ThemeName = "MetroLite";
            // 
            // metroSetDefaultButton1
            // 
            this.metroSetDefaultButton1.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.metroSetDefaultButton1.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.metroSetDefaultButton1.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.metroSetDefaultButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetDefaultButton1.HoverBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.metroSetDefaultButton1.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.metroSetDefaultButton1.HoverTextColor = System.Drawing.Color.White;
            this.metroSetDefaultButton1.Location = new System.Drawing.Point(15, 104);
            this.metroSetDefaultButton1.Name = "metroSetDefaultButton1";
            this.metroSetDefaultButton1.NormalBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.metroSetDefaultButton1.NormalColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.metroSetDefaultButton1.NormalTextColor = System.Drawing.Color.Black;
            this.metroSetDefaultButton1.PressBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.metroSetDefaultButton1.PressColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.metroSetDefaultButton1.PressTextColor = System.Drawing.Color.White;
            this.metroSetDefaultButton1.Size = new System.Drawing.Size(180, 40);
            this.metroSetDefaultButton1.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetDefaultButton1.StyleManager = this.styleManager1;
            this.metroSetDefaultButton1.TabIndex = 0;
            this.metroSetDefaultButton1.Text = "Default button";
            this.metroSetDefaultButton1.ThemeAuthor = "Narwin";
            this.metroSetDefaultButton1.ThemeName = "MetroLite";
            this.metroSetDefaultButton1.Click += new System.EventHandler(this.MetroSetDefaultButton1_Click);
            // 
            // metroSetTabPage1
            // 
            this.metroSetTabPage1.BaseColor = System.Drawing.Color.White;
            this.metroSetTabPage1.Controls.Add(this.metroSetTile8);
            this.metroSetTabPage1.Controls.Add(this.metroSetTile4);
            this.metroSetTabPage1.Controls.Add(this.metroSetTile7);
            this.metroSetTabPage1.Controls.Add(this.metroSetTile6);
            this.metroSetTabPage1.Controls.Add(this.metroSetTile2);
            this.metroSetTabPage1.Controls.Add(this.metroSetTile5);
            this.metroSetTabPage1.Controls.Add(this.metroSetTile3);
            this.metroSetTabPage1.Controls.Add(this.metroSetTile1);
            this.metroSetTabPage1.Controls.Add(this.metroSetLabel4);
            this.metroSetTabPage1.ImageIndex = 0;
            this.metroSetTabPage1.ImageKey = null;
            this.metroSetTabPage1.Location = new System.Drawing.Point(4, 42);
            this.metroSetTabPage1.Name = "metroSetTabPage1";
            this.metroSetTabPage1.Size = new System.Drawing.Size(1106, 570);
            this.metroSetTabPage1.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetTabPage1.StyleManager = this.styleManager1;
            this.metroSetTabPage1.TabIndex = 7;
            this.metroSetTabPage1.Text = "Tile";
            this.metroSetTabPage1.ThemeAuthor = "Narwin";
            this.metroSetTabPage1.ThemeName = "MetroLite";
            this.metroSetTabPage1.ToolTipText = null;
            // 
            // metroSetTile8
            // 
            this.metroSetTile8.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.metroSetTile8.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.metroSetTile8.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.metroSetTile8.Enabled = false;
            this.metroSetTile8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetTile8.HoverBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(230)))));
            this.metroSetTile8.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetTile8.HoverTextColor = System.Drawing.Color.White;
            this.metroSetTile8.Location = new System.Drawing.Point(732, 259);
            this.metroSetTile8.Name = "metroSetTile8";
            this.metroSetTile8.NormalBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetTile8.NormalColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetTile8.NormalTextColor = System.Drawing.Color.White;
            this.metroSetTile8.PressBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetTile8.PressColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetTile8.PressTextColor = System.Drawing.Color.White;
            this.metroSetTile8.Size = new System.Drawing.Size(190, 122);
            this.metroSetTile8.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetTile8.StyleManager = this.styleManager1;
            this.metroSetTile8.TabIndex = 13;
            this.metroSetTile8.Text = "Disabled Tile";
            this.metroSetTile8.ThemeAuthor = "Narwin";
            this.metroSetTile8.ThemeName = "MetroLite";
            this.metroSetTile8.TileAlign = MetroSet_UI.Enums.TileAlign.BottomCenter;
            // 
            // metroSetTile4
            // 
            this.metroSetTile4.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.metroSetTile4.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.metroSetTile4.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.metroSetTile4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetTile4.HoverBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(230)))));
            this.metroSetTile4.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetTile4.HoverTextColor = System.Drawing.Color.White;
            this.metroSetTile4.Location = new System.Drawing.Point(732, 104);
            this.metroSetTile4.Name = "metroSetTile4";
            this.metroSetTile4.NormalBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetTile4.NormalColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetTile4.NormalTextColor = System.Drawing.Color.White;
            this.metroSetTile4.PressBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetTile4.PressColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetTile4.PressTextColor = System.Drawing.Color.White;
            this.metroSetTile4.Size = new System.Drawing.Size(190, 122);
            this.metroSetTile4.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetTile4.StyleManager = this.styleManager1;
            this.metroSetTile4.TabIndex = 13;
            this.metroSetTile4.Text = "Normal Tile";
            this.metroSetTile4.ThemeAuthor = "Narwin";
            this.metroSetTile4.ThemeName = "MetroLite";
            this.metroSetTile4.TileAlign = MetroSet_UI.Enums.TileAlign.TopCenter;
            // 
            // metroSetTile7
            // 
            this.metroSetTile7.BackgroundImage = global::MetroSet_UI_Example.Properties.Resources._111201;
            this.metroSetTile7.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.metroSetTile7.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.metroSetTile7.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.metroSetTile7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetTile7.HoverBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(230)))));
            this.metroSetTile7.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetTile7.HoverTextColor = System.Drawing.Color.White;
            this.metroSetTile7.Location = new System.Drawing.Point(254, 259);
            this.metroSetTile7.Name = "metroSetTile7";
            this.metroSetTile7.NormalBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetTile7.NormalColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetTile7.NormalTextColor = System.Drawing.Color.White;
            this.metroSetTile7.PressBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetTile7.PressColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetTile7.PressTextColor = System.Drawing.Color.White;
            this.metroSetTile7.Size = new System.Drawing.Size(190, 122);
            this.metroSetTile7.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetTile7.StyleManager = this.styleManager1;
            this.metroSetTile7.TabIndex = 10;
            this.metroSetTile7.Text = "TopCenter";
            this.metroSetTile7.ThemeAuthor = "Narwin";
            this.metroSetTile7.ThemeName = "MetroLite";
            this.metroSetTile7.TileAlign = MetroSet_UI.Enums.TileAlign.BottomCenter;
            // 
            // metroSetTile6
            // 
            this.metroSetTile6.BackgroundImage = global::MetroSet_UI_Example.Properties.Resources._475841;
            this.metroSetTile6.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.metroSetTile6.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.metroSetTile6.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.metroSetTile6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetTile6.HoverBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(230)))));
            this.metroSetTile6.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetTile6.HoverTextColor = System.Drawing.Color.White;
            this.metroSetTile6.Location = new System.Drawing.Point(493, 259);
            this.metroSetTile6.Name = "metroSetTile6";
            this.metroSetTile6.NormalBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetTile6.NormalColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetTile6.NormalTextColor = System.Drawing.Color.White;
            this.metroSetTile6.PressBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetTile6.PressColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetTile6.PressTextColor = System.Drawing.Color.White;
            this.metroSetTile6.Size = new System.Drawing.Size(190, 122);
            this.metroSetTile6.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetTile6.StyleManager = this.styleManager1;
            this.metroSetTile6.TabIndex = 11;
            this.metroSetTile6.Text = "BottomRight";
            this.metroSetTile6.ThemeAuthor = "Narwin";
            this.metroSetTile6.ThemeName = "MetroLite";
            this.metroSetTile6.TileAlign = MetroSet_UI.Enums.TileAlign.BottomRight;
            // 
            // metroSetTile2
            // 
            this.metroSetTile2.BackgroundImage = global::MetroSet_UI_Example.Properties.Resources._579841;
            this.metroSetTile2.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.metroSetTile2.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.metroSetTile2.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.metroSetTile2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetTile2.HoverBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(230)))));
            this.metroSetTile2.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetTile2.HoverTextColor = System.Drawing.Color.White;
            this.metroSetTile2.Location = new System.Drawing.Point(254, 104);
            this.metroSetTile2.Name = "metroSetTile2";
            this.metroSetTile2.NormalBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetTile2.NormalColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetTile2.NormalTextColor = System.Drawing.Color.White;
            this.metroSetTile2.PressBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetTile2.PressColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetTile2.PressTextColor = System.Drawing.Color.White;
            this.metroSetTile2.Size = new System.Drawing.Size(190, 122);
            this.metroSetTile2.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetTile2.StyleManager = this.styleManager1;
            this.metroSetTile2.TabIndex = 10;
            this.metroSetTile2.Text = "TopCenter";
            this.metroSetTile2.ThemeAuthor = "Narwin";
            this.metroSetTile2.ThemeName = "MetroLite";
            this.metroSetTile2.TileAlign = MetroSet_UI.Enums.TileAlign.TopCenter;
            // 
            // metroSetTile5
            // 
            this.metroSetTile5.BackgroundImage = global::MetroSet_UI_Example.Properties.Resources._579840;
            this.metroSetTile5.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.metroSetTile5.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.metroSetTile5.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.metroSetTile5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetTile5.HoverBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(230)))));
            this.metroSetTile5.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetTile5.HoverTextColor = System.Drawing.Color.White;
            this.metroSetTile5.Location = new System.Drawing.Point(493, 104);
            this.metroSetTile5.Name = "metroSetTile5";
            this.metroSetTile5.NormalBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetTile5.NormalColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetTile5.NormalTextColor = System.Drawing.Color.White;
            this.metroSetTile5.PressBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetTile5.PressColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetTile5.PressTextColor = System.Drawing.Color.White;
            this.metroSetTile5.Size = new System.Drawing.Size(190, 122);
            this.metroSetTile5.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetTile5.StyleManager = this.styleManager1;
            this.metroSetTile5.TabIndex = 12;
            this.metroSetTile5.ThemeAuthor = "Narwin";
            this.metroSetTile5.ThemeName = "MetroLite";
            this.metroSetTile5.TileAlign = MetroSet_UI.Enums.TileAlign.BottmLeft;
            // 
            // metroSetTile3
            // 
            this.metroSetTile3.BackgroundImage = global::MetroSet_UI_Example.Properties.Resources._475841;
            this.metroSetTile3.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.metroSetTile3.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.metroSetTile3.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.metroSetTile3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetTile3.HoverBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(230)))));
            this.metroSetTile3.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetTile3.HoverTextColor = System.Drawing.Color.White;
            this.metroSetTile3.Location = new System.Drawing.Point(15, 259);
            this.metroSetTile3.Name = "metroSetTile3";
            this.metroSetTile3.NormalBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetTile3.NormalColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetTile3.NormalTextColor = System.Drawing.Color.White;
            this.metroSetTile3.PressBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetTile3.PressColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetTile3.PressTextColor = System.Drawing.Color.White;
            this.metroSetTile3.Size = new System.Drawing.Size(190, 122);
            this.metroSetTile3.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetTile3.StyleManager = this.styleManager1;
            this.metroSetTile3.TabIndex = 11;
            this.metroSetTile3.Text = "BottomRight";
            this.metroSetTile3.ThemeAuthor = "Narwin";
            this.metroSetTile3.ThemeName = "MetroLite";
            this.metroSetTile3.TileAlign = MetroSet_UI.Enums.TileAlign.BottomRight;
            // 
            // metroSetTile1
            // 
            this.metroSetTile1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("metroSetTile1.BackgroundImage")));
            this.metroSetTile1.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.metroSetTile1.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.metroSetTile1.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.metroSetTile1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetTile1.HoverBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(230)))));
            this.metroSetTile1.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetTile1.HoverTextColor = System.Drawing.Color.White;
            this.metroSetTile1.Location = new System.Drawing.Point(15, 104);
            this.metroSetTile1.Name = "metroSetTile1";
            this.metroSetTile1.NormalBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetTile1.NormalColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetTile1.NormalTextColor = System.Drawing.Color.White;
            this.metroSetTile1.PressBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetTile1.PressColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetTile1.PressTextColor = System.Drawing.Color.White;
            this.metroSetTile1.Size = new System.Drawing.Size(190, 122);
            this.metroSetTile1.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetTile1.StyleManager = this.styleManager1;
            this.metroSetTile1.TabIndex = 12;
            this.metroSetTile1.Text = "BottmLeft";
            this.metroSetTile1.ThemeAuthor = "Narwin";
            this.metroSetTile1.ThemeName = "MetroLite";
            this.metroSetTile1.TileAlign = MetroSet_UI.Enums.TileAlign.BottmLeft;
            // 
            // metroSetLabel4
            // 
            this.metroSetLabel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetLabel4.Location = new System.Drawing.Point(15, 59);
            this.metroSetLabel4.Name = "metroSetLabel4";
            this.metroSetLabel4.Size = new System.Drawing.Size(100, 23);
            this.metroSetLabel4.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetLabel4.StyleManager = this.styleManager1;
            this.metroSetLabel4.TabIndex = 9;
            this.metroSetLabel4.Text = "Tile";
            this.metroSetLabel4.ThemeAuthor = "Narwin";
            this.metroSetLabel4.ThemeName = "MetroLite";
            // 
            // metroSetTabPage3
            // 
            this.metroSetTabPage3.BaseColor = System.Drawing.Color.White;
            this.metroSetTabPage3.Controls.Add(this.metroSetListBox2);
            this.metroSetTabPage3.Controls.Add(this.metroSetComboBox2);
            this.metroSetTabPage3.Controls.Add(this.metroSetComboBox1);
            this.metroSetTabPage3.Controls.Add(this.metroSetNumeric3);
            this.metroSetTabPage3.Controls.Add(this.metroSetNumeric2);
            this.metroSetTabPage3.Controls.Add(this.metroSetRichTextBox1);
            this.metroSetTabPage3.Controls.Add(this.metroSetTextBox3);
            this.metroSetTabPage3.Controls.Add(this.metroSetTextBox2);
            this.metroSetTabPage3.Controls.Add(this.metroSetTextBox4);
            this.metroSetTabPage3.Controls.Add(this.metroSetTextBox1);
            this.metroSetTabPage3.Controls.Add(this.metroSetLabel8);
            this.metroSetTabPage3.Controls.Add(this.metroSetLabel9);
            this.metroSetTabPage3.Controls.Add(this.metroSetLabel6);
            this.metroSetTabPage3.Controls.Add(this.metroSetLabel7);
            this.metroSetTabPage3.Controls.Add(this.metroSetLabel5);
            this.metroSetTabPage3.ImageIndex = 0;
            this.metroSetTabPage3.ImageKey = null;
            this.metroSetTabPage3.Location = new System.Drawing.Point(4, 42);
            this.metroSetTabPage3.Name = "metroSetTabPage3";
            this.metroSetTabPage3.Size = new System.Drawing.Size(1106, 570);
            this.metroSetTabPage3.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetTabPage3.StyleManager = this.styleManager1;
            this.metroSetTabPage3.TabIndex = 2;
            this.metroSetTabPage3.Text = "InputBase";
            this.metroSetTabPage3.ThemeAuthor = "Narwin";
            this.metroSetTabPage3.ThemeName = "MetroLite";
            this.metroSetTabPage3.ToolTipText = null;
            // 
            // metroSetListBox2
            // 
            this.metroSetListBox2.BorderColor = System.Drawing.Color.LightGray;
            this.metroSetListBox2.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.metroSetListBox2.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.metroSetListBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetListBox2.HoveredItemBackColor = System.Drawing.Color.LightGray;
            this.metroSetListBox2.HoveredItemColor = System.Drawing.Color.DimGray;
            this.metroSetListBox2.ItemHeight = 30;
            this.metroSetListBox2.Items.Add("ListItem 1");
            this.metroSetListBox2.Items.Add("ListItem 2");
            this.metroSetListBox2.Items.Add("ListItem 3");
            this.metroSetListBox2.Items.Add("ListItem 4");
            this.metroSetListBox2.Items.Add("ListItem 5");
            this.metroSetListBox2.Items.Add("ListItem 6");
            this.metroSetListBox2.Items.Add("ListItem 7");
            this.metroSetListBox2.Items.Add("ListItem 8");
            this.metroSetListBox2.Items.Add("ListItem 9");
            this.metroSetListBox2.Items.Add("ListItem 10");
            this.metroSetListBox2.Items.Add("ListItem 11");
            this.metroSetListBox2.Items.Add("ListItem 12");
            this.metroSetListBox2.Items.Add("ListItem 13");
            this.metroSetListBox2.Items.Add("ListItem 14");
            this.metroSetListBox2.Items.Add("ListItem 15");
            this.metroSetListBox2.Items.Add("ListItem 16");
            this.metroSetListBox2.Items.Add("ListItem 17");
            this.metroSetListBox2.Items.Add("ListItem 18");
            this.metroSetListBox2.Items.Add("ListItem 19");
            this.metroSetListBox2.Items.Add("ListItem 20");
            this.metroSetListBox2.Items.Add("ListItem 21");
            this.metroSetListBox2.Items.Add("ListItem 22");
            this.metroSetListBox2.Items.Add("ListItem 23");
            this.metroSetListBox2.Items.Add("ListItem 24");
            this.metroSetListBox2.Items.Add("ListItem 25");
            this.metroSetListBox2.Items.Add("ListItem 26");
            this.metroSetListBox2.Items.Add("ListItem 27");
            this.metroSetListBox2.Items.Add("ListItem 28");
            this.metroSetListBox2.Items.Add("ListItem 29");
            this.metroSetListBox2.Items.Add("ListItem 30");
            this.metroSetListBox2.Items.Add("ListItem 31");
            this.metroSetListBox2.Items.Add("ListItem 32");
            this.metroSetListBox2.Items.Add("ListItem 33");
            this.metroSetListBox2.Items.Add("ListItem 34");
            this.metroSetListBox2.Items.Add("ListItem 35");
            this.metroSetListBox2.Items.Add("ListItem 36");
            this.metroSetListBox2.Items.Add("ListItem 37");
            this.metroSetListBox2.Items.Add("ListItem 38");
            this.metroSetListBox2.Items.Add("ListItem 39");
            this.metroSetListBox2.Items.Add("ListItem 40");
            this.metroSetListBox2.Items.Add("ListItem 41");
            this.metroSetListBox2.Items.Add("ListItem 42");
            this.metroSetListBox2.Items.Add("ListItem 43");
            this.metroSetListBox2.Items.Add("ListItem 44");
            this.metroSetListBox2.Items.Add("ListItem 45");
            this.metroSetListBox2.Items.Add("ListItem 46");
            this.metroSetListBox2.Items.Add("ListItem 47");
            this.metroSetListBox2.Items.Add("ListItem 48");
            this.metroSetListBox2.Items.Add("ListItem 49");
            this.metroSetListBox2.Items.Add("ListItem 50");
            this.metroSetListBox2.Items.Add("ListItem 51");
            this.metroSetListBox2.Items.Add("ListItem 52");
            this.metroSetListBox2.Items.Add("ListItem 53");
            this.metroSetListBox2.Items.Add("ListItem 54");
            this.metroSetListBox2.Items.Add("ListItem 55");
            this.metroSetListBox2.Items.Add("ListItem 56");
            this.metroSetListBox2.Items.Add("ListItem 57");
            this.metroSetListBox2.Items.Add("ListItem 58");
            this.metroSetListBox2.Items.Add("ListItem 59");
            this.metroSetListBox2.Items.Add("ListItem 60");
            this.metroSetListBox2.Items.Add("ListItem 61");
            this.metroSetListBox2.Items.Add("ListItem 62");
            this.metroSetListBox2.Items.Add("ListItem 63");
            this.metroSetListBox2.Items.Add("ListItem 64");
            this.metroSetListBox2.Items.Add("ListItem 65");
            this.metroSetListBox2.Items.Add("ListItem 66");
            this.metroSetListBox2.Items.Add("ListItem 67");
            this.metroSetListBox2.Items.Add("ListItem 68");
            this.metroSetListBox2.Items.Add("ListItem 69");
            this.metroSetListBox2.Items.Add("ListItem 70");
            this.metroSetListBox2.Items.Add("ListItem 71");
            this.metroSetListBox2.Items.Add("ListItem 72");
            this.metroSetListBox2.Items.Add("ListItem 73");
            this.metroSetListBox2.Items.Add("ListItem 74");
            this.metroSetListBox2.Items.Add("ListItem 75");
            this.metroSetListBox2.Items.Add("ListItem 76");
            this.metroSetListBox2.Items.Add("ListItem 77");
            this.metroSetListBox2.Items.Add("ListItem 78");
            this.metroSetListBox2.Items.Add("ListItem 79");
            this.metroSetListBox2.Items.Add("ListItem 80");
            this.metroSetListBox2.Items.Add("ListItem 81");
            this.metroSetListBox2.Items.Add("ListItem 82");
            this.metroSetListBox2.Items.Add("ListItem 83");
            this.metroSetListBox2.Items.Add("ListItem 84");
            this.metroSetListBox2.Items.Add("ListItem 85");
            this.metroSetListBox2.Items.Add("ListItem 86");
            this.metroSetListBox2.Items.Add("ListItem 87");
            this.metroSetListBox2.Items.Add("ListItem 88");
            this.metroSetListBox2.Items.Add("ListItem 89");
            this.metroSetListBox2.Items.Add("ListItem 90");
            this.metroSetListBox2.Items.Add("ListItem 91");
            this.metroSetListBox2.Items.Add("ListItem 92");
            this.metroSetListBox2.Items.Add("ListItem 93");
            this.metroSetListBox2.Items.Add("ListItem 94");
            this.metroSetListBox2.Items.Add("ListItem 95");
            this.metroSetListBox2.Items.Add("ListItem 96");
            this.metroSetListBox2.Items.Add("ListItem 97");
            this.metroSetListBox2.Items.Add("ListItem 98");
            this.metroSetListBox2.Items.Add("ListItem 99");
            this.metroSetListBox2.Items.Add("ListItem 100");
            this.metroSetListBox2.Location = new System.Drawing.Point(635, 82);
            this.metroSetListBox2.MultiSelect = false;
            this.metroSetListBox2.Name = "metroSetListBox2";
            this.metroSetListBox2.SelectedIndex = -1;
            this.metroSetListBox2.SelectedItem = null;
            this.metroSetListBox2.SelectedItemBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetListBox2.SelectedItemColor = System.Drawing.Color.White;
            this.metroSetListBox2.SelectedValue = null;
            this.metroSetListBox2.ShowBorder = false;
            this.metroSetListBox2.ShowScrollBar = true;
            this.metroSetListBox2.Size = new System.Drawing.Size(374, 286);
            this.metroSetListBox2.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetListBox2.StyleManager = this.styleManager1;
            this.metroSetListBox2.TabIndex = 9;
            this.metroSetListBox2.ThemeAuthor = "Narwin";
            this.metroSetListBox2.ThemeName = "MetroLite";
            // 
            // metroSetComboBox2
            // 
            this.metroSetComboBox2.AllowDrop = true;
            this.metroSetComboBox2.ArrowColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            this.metroSetComboBox2.BackColor = System.Drawing.Color.Transparent;
            this.metroSetComboBox2.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.metroSetComboBox2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            this.metroSetComboBox2.CausesValidation = false;
            this.metroSetComboBox2.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.metroSetComboBox2.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.metroSetComboBox2.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.metroSetComboBox2.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.metroSetComboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.metroSetComboBox2.Enabled = false;
            this.metroSetComboBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.metroSetComboBox2.FormattingEnabled = true;
            this.metroSetComboBox2.ItemHeight = 20;
            this.metroSetComboBox2.Location = new System.Drawing.Point(305, 342);
            this.metroSetComboBox2.Name = "metroSetComboBox2";
            this.metroSetComboBox2.SelectedItemBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetComboBox2.SelectedItemForeColor = System.Drawing.Color.White;
            this.metroSetComboBox2.Size = new System.Drawing.Size(215, 26);
            this.metroSetComboBox2.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetComboBox2.StyleManager = this.styleManager1;
            this.metroSetComboBox2.TabIndex = 7;
            this.metroSetComboBox2.ThemeAuthor = "Narwin";
            this.metroSetComboBox2.ThemeName = "MetroLite";
            // 
            // metroSetComboBox1
            // 
            this.metroSetComboBox1.AllowDrop = true;
            this.metroSetComboBox1.ArrowColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            this.metroSetComboBox1.BackColor = System.Drawing.Color.Transparent;
            this.metroSetComboBox1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.metroSetComboBox1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            this.metroSetComboBox1.CausesValidation = false;
            this.metroSetComboBox1.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.metroSetComboBox1.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.metroSetComboBox1.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.metroSetComboBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.metroSetComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.metroSetComboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.metroSetComboBox1.FormattingEnabled = true;
            this.metroSetComboBox1.ItemHeight = 20;
            this.metroSetComboBox1.Items.AddRange(new object[] {
            "ListItem 1",
            "ListItem 2",
            "ListItem 3",
            "ListItem 4",
            "ListItem 5",
            "ListItem 6",
            "ListItem 7",
            "ListItem 8",
            "ListItem 9",
            "ListItem 10",
            "ListItem 11",
            "ListItem 12",
            "ListItem 13",
            "ListItem 14",
            "ListItem 15",
            "ListItem 16",
            "ListItem 17",
            "ListItem 18",
            "ListItem 19",
            "ListItem 20",
            "ListItem 21",
            "ListItem 22",
            "ListItem 23",
            "ListItem 24",
            "ListItem 25",
            "ListItem 26",
            "ListItem 27",
            "ListItem 28",
            "ListItem 29",
            "ListItem 30",
            "ListItem 31",
            "ListItem 32",
            "ListItem 33",
            "ListItem 34",
            "ListItem 35",
            "ListItem 36",
            "ListItem 37",
            "ListItem 38",
            "ListItem 39",
            "ListItem 40",
            "ListItem 41",
            "ListItem 42",
            "ListItem 43",
            "ListItem 44",
            "ListItem 45",
            "ListItem 46",
            "ListItem 47",
            "ListItem 48",
            "ListItem 49",
            "ListItem 50",
            "ListItem 51",
            "ListItem 52",
            "ListItem 53",
            "ListItem 54",
            "ListItem 55",
            "ListItem 56",
            "ListItem 57",
            "ListItem 58",
            "ListItem 59",
            "ListItem 60",
            "ListItem 61",
            "ListItem 62",
            "ListItem 63",
            "ListItem 64",
            "ListItem 65",
            "ListItem 66",
            "ListItem 67",
            "ListItem 68",
            "ListItem 69",
            "ListItem 70",
            "ListItem 71",
            "ListItem 72",
            "ListItem 73",
            "ListItem 74",
            "ListItem 75",
            "ListItem 76",
            "ListItem 77",
            "ListItem 78",
            "ListItem 79",
            "ListItem 80",
            "ListItem 81",
            "ListItem 82",
            "ListItem 83",
            "ListItem 84",
            "ListItem 85",
            "ListItem 86",
            "ListItem 87",
            "ListItem 88",
            "ListItem 89",
            "ListItem 90",
            "ListItem 91",
            "ListItem 92",
            "ListItem 93",
            "ListItem 94",
            "ListItem 95",
            "ListItem 96",
            "ListItem 97",
            "ListItem 98",
            "ListItem 99",
            "ListItem 100"});
            this.metroSetComboBox1.Location = new System.Drawing.Point(305, 292);
            this.metroSetComboBox1.Name = "metroSetComboBox1";
            this.metroSetComboBox1.SelectedItemBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetComboBox1.SelectedItemForeColor = System.Drawing.Color.White;
            this.metroSetComboBox1.Size = new System.Drawing.Size(215, 26);
            this.metroSetComboBox1.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetComboBox1.StyleManager = this.styleManager1;
            this.metroSetComboBox1.TabIndex = 7;
            this.metroSetComboBox1.ThemeAuthor = "Narwin";
            this.metroSetComboBox1.ThemeName = "MetroLite";
            this.metroSetToolTip1.SetToolTip(this.metroSetComboBox1, "MetroSetComboBox");
            // 
            // metroSetNumeric3
            // 
            this.metroSetNumeric3.BackColor = System.Drawing.Color.Transparent;
            this.metroSetNumeric3.BackgroundColor = System.Drawing.Color.Empty;
            this.metroSetNumeric3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            this.metroSetNumeric3.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.metroSetNumeric3.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.metroSetNumeric3.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.metroSetNumeric3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetNumeric3.Location = new System.Drawing.Point(15, 426);
            this.metroSetNumeric3.Maximum = 100;
            this.metroSetNumeric3.Minimum = 0;
            this.metroSetNumeric3.Name = "metroSetNumeric3";
            this.metroSetNumeric3.Size = new System.Drawing.Size(215, 26);
            this.metroSetNumeric3.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetNumeric3.StyleManager = this.styleManager1;
            this.metroSetNumeric3.SymbolsColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.metroSetNumeric3.TabIndex = 6;
            this.metroSetNumeric3.Text = "metroSetNumeric3";
            this.metroSetNumeric3.ThemeAuthor = "Narwin";
            this.metroSetNumeric3.ThemeName = "MetroLite";
            this.metroSetNumeric3.Value = 5;
            // 
            // metroSetNumeric2
            // 
            this.metroSetNumeric2.BackColor = System.Drawing.Color.Transparent;
            this.metroSetNumeric2.BackgroundColor = System.Drawing.Color.Empty;
            this.metroSetNumeric2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            this.metroSetNumeric2.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.metroSetNumeric2.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.metroSetNumeric2.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.metroSetNumeric2.Enabled = false;
            this.metroSetNumeric2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetNumeric2.Location = new System.Drawing.Point(15, 476);
            this.metroSetNumeric2.Maximum = 100;
            this.metroSetNumeric2.Minimum = 0;
            this.metroSetNumeric2.Name = "metroSetNumeric2";
            this.metroSetNumeric2.Size = new System.Drawing.Size(215, 26);
            this.metroSetNumeric2.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetNumeric2.StyleManager = this.styleManager1;
            this.metroSetNumeric2.SymbolsColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.metroSetNumeric2.TabIndex = 5;
            this.metroSetNumeric2.Text = "metroSetNumeric1";
            this.metroSetNumeric2.ThemeAuthor = "Narwin";
            this.metroSetNumeric2.ThemeName = "MetroLite";
            this.metroSetNumeric2.Value = 0;
            // 
            // metroSetRichTextBox1
            // 
            this.metroSetRichTextBox1.AutoWordSelection = false;
            this.metroSetRichTextBox1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.metroSetRichTextBox1.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.metroSetRichTextBox1.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.metroSetRichTextBox1.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.metroSetRichTextBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetRichTextBox1.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.metroSetRichTextBox1.Lines = null;
            this.metroSetRichTextBox1.Location = new System.Drawing.Point(305, 93);
            this.metroSetRichTextBox1.MaxLength = 32767;
            this.metroSetRichTextBox1.Name = "metroSetRichTextBox1";
            this.metroSetRichTextBox1.ReadOnly = false;
            this.metroSetRichTextBox1.Size = new System.Drawing.Size(245, 138);
            this.metroSetRichTextBox1.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetRichTextBox1.StyleManager = this.styleManager1;
            this.metroSetRichTextBox1.TabIndex = 4;
            this.metroSetRichTextBox1.Text = resources.GetString("metroSetRichTextBox1.Text");
            this.metroSetRichTextBox1.ThemeAuthor = "Narwin";
            this.metroSetRichTextBox1.ThemeName = "MetroLite";
            this.metroSetRichTextBox1.WordWrap = true;
            // 
            // metroSetTextBox3
            // 
            this.metroSetTextBox3.AutoCompleteCustomSource = null;
            this.metroSetTextBox3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.metroSetTextBox3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.metroSetTextBox3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.metroSetTextBox3.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.metroSetTextBox3.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.metroSetTextBox3.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.metroSetTextBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetTextBox3.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.metroSetTextBox3.Image = null;
            this.metroSetTextBox3.Lines = null;
            this.metroSetTextBox3.Location = new System.Drawing.Point(15, 230);
            this.metroSetTextBox3.MaxLength = 32767;
            this.metroSetTextBox3.Multiline = true;
            this.metroSetTextBox3.Name = "metroSetTextBox3";
            this.metroSetTextBox3.ReadOnly = false;
            this.metroSetTextBox3.Size = new System.Drawing.Size(215, 138);
            this.metroSetTextBox3.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetTextBox3.StyleManager = this.styleManager1;
            this.metroSetTextBox3.TabIndex = 3;
            this.metroSetTextBox3.Text = resources.GetString("metroSetTextBox3.Text");
            this.metroSetTextBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.metroSetTextBox3.ThemeAuthor = "Narwin";
            this.metroSetTextBox3.ThemeName = "MetroLite";
            this.metroSetTextBox3.UseSystemPasswordChar = false;
            this.metroSetTextBox3.WatermarkText = "";
            // 
            // metroSetTextBox2
            // 
            this.metroSetTextBox2.AutoCompleteCustomSource = null;
            this.metroSetTextBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.metroSetTextBox2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.metroSetTextBox2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.metroSetTextBox2.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.metroSetTextBox2.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.metroSetTextBox2.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.metroSetTextBox2.Enabled = false;
            this.metroSetTextBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetTextBox2.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.metroSetTextBox2.Image = null;
            this.metroSetTextBox2.Lines = null;
            this.metroSetTextBox2.Location = new System.Drawing.Point(15, 185);
            this.metroSetTextBox2.MaxLength = 32767;
            this.metroSetTextBox2.Multiline = false;
            this.metroSetTextBox2.Name = "metroSetTextBox2";
            this.metroSetTextBox2.ReadOnly = false;
            this.metroSetTextBox2.Size = new System.Drawing.Size(215, 26);
            this.metroSetTextBox2.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetTextBox2.StyleManager = this.styleManager1;
            this.metroSetTextBox2.TabIndex = 3;
            this.metroSetTextBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.metroSetTextBox2.ThemeAuthor = "Narwin";
            this.metroSetTextBox2.ThemeName = "MetroLite";
            this.metroSetTextBox2.UseSystemPasswordChar = false;
            this.metroSetTextBox2.WatermarkText = "Disabled TextBox";
            // 
            // metroSetTextBox4
            // 
            this.metroSetTextBox4.AutoCompleteCustomSource = null;
            this.metroSetTextBox4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.metroSetTextBox4.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.metroSetTextBox4.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.metroSetTextBox4.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.metroSetTextBox4.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.metroSetTextBox4.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.metroSetTextBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetTextBox4.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.metroSetTextBox4.Image = global::MetroSet_UI_Example.Properties.Resources.filter;
            this.metroSetTextBox4.Lines = null;
            this.metroSetTextBox4.Location = new System.Drawing.Point(15, 139);
            this.metroSetTextBox4.MaxLength = 32767;
            this.metroSetTextBox4.Multiline = false;
            this.metroSetTextBox4.Name = "metroSetTextBox4";
            this.metroSetTextBox4.ReadOnly = false;
            this.metroSetTextBox4.Size = new System.Drawing.Size(215, 26);
            this.metroSetTextBox4.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetTextBox4.StyleManager = this.styleManager1;
            this.metroSetTextBox4.TabIndex = 3;
            this.metroSetTextBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.metroSetTextBox4.ThemeAuthor = "Narwin";
            this.metroSetTextBox4.ThemeName = "MetroLite";
            this.metroSetTextBox4.UseSystemPasswordChar = false;
            this.metroSetTextBox4.WatermarkText = "Image TextBox";
            // 
            // metroSetTextBox1
            // 
            this.metroSetTextBox1.AutoCompleteCustomSource = null;
            this.metroSetTextBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.metroSetTextBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.metroSetTextBox1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.metroSetTextBox1.ContextMenuStrip = this.metroSetContextMenuStrip1;
            this.metroSetTextBox1.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.metroSetTextBox1.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.metroSetTextBox1.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.metroSetTextBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetTextBox1.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.metroSetTextBox1.Image = null;
            this.metroSetTextBox1.Lines = null;
            this.metroSetTextBox1.Location = new System.Drawing.Point(15, 93);
            this.metroSetTextBox1.MaxLength = 32767;
            this.metroSetTextBox1.Multiline = false;
            this.metroSetTextBox1.Name = "metroSetTextBox1";
            this.metroSetTextBox1.ReadOnly = false;
            this.metroSetTextBox1.Size = new System.Drawing.Size(215, 26);
            this.metroSetTextBox1.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetTextBox1.StyleManager = this.styleManager1;
            this.metroSetTextBox1.TabIndex = 3;
            this.metroSetTextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.metroSetTextBox1.ThemeAuthor = "Narwin";
            this.metroSetTextBox1.ThemeName = "MetroLite";
            this.metroSetTextBox1.UseSystemPasswordChar = false;
            this.metroSetTextBox1.WatermarkText = "Normal TextBox";
            // 
            // metroSetContextMenuStrip1
            // 
            this.metroSetContextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.textBoxToolStripMenuItem});
            this.metroSetContextMenuStrip1.Name = "metroSetContextMenuStrip1";
            this.metroSetContextMenuStrip1.Size = new System.Drawing.Size(116, 26);
            this.metroSetContextMenuStrip1.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetContextMenuStrip1.StyleManager = null;
            this.metroSetContextMenuStrip1.ThemeAuthor = "Narwin";
            this.metroSetContextMenuStrip1.ThemeName = "MetroLite";
            // 
            // textBoxToolStripMenuItem
            // 
            this.textBoxToolStripMenuItem.Name = "textBoxToolStripMenuItem";
            this.textBoxToolStripMenuItem.Size = new System.Drawing.Size(115, 22);
            this.textBoxToolStripMenuItem.Text = "TextBox";
            // 
            // metroSetLabel8
            // 
            this.metroSetLabel8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetLabel8.Location = new System.Drawing.Point(305, 254);
            this.metroSetLabel8.Name = "metroSetLabel8";
            this.metroSetLabel8.Size = new System.Drawing.Size(138, 23);
            this.metroSetLabel8.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetLabel8.StyleManager = this.styleManager1;
            this.metroSetLabel8.TabIndex = 2;
            this.metroSetLabel8.Text = "Normal ComboBox";
            this.metroSetLabel8.ThemeAuthor = "Narwin";
            this.metroSetLabel8.ThemeName = "MetroLite";
            // 
            // metroSetLabel9
            // 
            this.metroSetLabel9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetLabel9.Location = new System.Drawing.Point(635, 55);
            this.metroSetLabel9.Name = "metroSetLabel9";
            this.metroSetLabel9.Size = new System.Drawing.Size(138, 23);
            this.metroSetLabel9.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetLabel9.StyleManager = this.styleManager1;
            this.metroSetLabel9.TabIndex = 2;
            this.metroSetLabel9.Text = "Normal ListBox";
            this.metroSetLabel9.ThemeAuthor = "Narwin";
            this.metroSetLabel9.ThemeName = "MetroLite";
            // 
            // metroSetLabel6
            // 
            this.metroSetLabel6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetLabel6.Location = new System.Drawing.Point(305, 55);
            this.metroSetLabel6.Name = "metroSetLabel6";
            this.metroSetLabel6.Size = new System.Drawing.Size(138, 23);
            this.metroSetLabel6.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetLabel6.StyleManager = this.styleManager1;
            this.metroSetLabel6.TabIndex = 2;
            this.metroSetLabel6.Text = "Normal RichTextBox";
            this.metroSetLabel6.ThemeAuthor = "Narwin";
            this.metroSetLabel6.ThemeName = "MetroLite";
            // 
            // metroSetLabel7
            // 
            this.metroSetLabel7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetLabel7.Location = new System.Drawing.Point(15, 388);
            this.metroSetLabel7.Name = "metroSetLabel7";
            this.metroSetLabel7.Size = new System.Drawing.Size(114, 23);
            this.metroSetLabel7.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetLabel7.StyleManager = this.styleManager1;
            this.metroSetLabel7.TabIndex = 2;
            this.metroSetLabel7.Text = "Normal Numeric";
            this.metroSetLabel7.ThemeAuthor = "Narwin";
            this.metroSetLabel7.ThemeName = "MetroLite";
            // 
            // metroSetLabel5
            // 
            this.metroSetLabel5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetLabel5.Location = new System.Drawing.Point(15, 55);
            this.metroSetLabel5.Name = "metroSetLabel5";
            this.metroSetLabel5.Size = new System.Drawing.Size(114, 23);
            this.metroSetLabel5.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetLabel5.StyleManager = this.styleManager1;
            this.metroSetLabel5.TabIndex = 2;
            this.metroSetLabel5.Text = "Normal TextBox";
            this.metroSetLabel5.ThemeAuthor = "Narwin";
            this.metroSetLabel5.ThemeName = "MetroLite";
            // 
            // metroSetTabPage4
            // 
            this.metroSetTabPage4.BaseColor = System.Drawing.Color.White;
            this.metroSetTabPage4.Controls.Add(this.metroSetSwitch4);
            this.metroSetTabPage4.Controls.Add(this.metroSetSwitch3);
            this.metroSetTabPage4.Controls.Add(this.metroSetSwitch2);
            this.metroSetTabPage4.Controls.Add(this.metroSetSwitch1);
            this.metroSetTabPage4.Controls.Add(this.metroSetLabel12);
            this.metroSetTabPage4.Controls.Add(this.metroSetRadioButton4);
            this.metroSetTabPage4.Controls.Add(this.metroSetRadioButton3);
            this.metroSetTabPage4.Controls.Add(this.metroSetRadioButton2);
            this.metroSetTabPage4.Controls.Add(this.metroSetRadioButton1);
            this.metroSetTabPage4.Controls.Add(this.metroSetCheckBox5);
            this.metroSetTabPage4.Controls.Add(this.metroSetCheckBox4);
            this.metroSetTabPage4.Controls.Add(this.metroSetCheckBox3);
            this.metroSetTabPage4.Controls.Add(this.metroSetCheckBox2);
            this.metroSetTabPage4.Controls.Add(this.metroSetCheckBox6);
            this.metroSetTabPage4.Controls.Add(this.metroSetCheckBox1);
            this.metroSetTabPage4.Controls.Add(this.metroSetLabel11);
            this.metroSetTabPage4.Controls.Add(this.metroSetLabel10);
            this.metroSetTabPage4.ImageIndex = 0;
            this.metroSetTabPage4.ImageKey = null;
            this.metroSetTabPage4.Location = new System.Drawing.Point(4, 42);
            this.metroSetTabPage4.Name = "metroSetTabPage4";
            this.metroSetTabPage4.Size = new System.Drawing.Size(1106, 570);
            this.metroSetTabPage4.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetTabPage4.StyleManager = this.styleManager1;
            this.metroSetTabPage4.TabIndex = 3;
            this.metroSetTabPage4.Text = "Switchery";
            this.metroSetTabPage4.ThemeAuthor = "Narwin";
            this.metroSetTabPage4.ThemeName = "MetroLite";
            this.metroSetTabPage4.ToolTipText = null;
            // 
            // metroSetSwitch4
            // 
            this.metroSetSwitch4.BackColor = System.Drawing.Color.Transparent;
            this.metroSetSwitch4.BackgroundColor = System.Drawing.Color.Empty;
            this.metroSetSwitch4.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(165)))), ((int)(((byte)(159)))), ((int)(((byte)(147)))));
            this.metroSetSwitch4.CheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetSwitch4.CheckState = MetroSet_UI.Enums.CheckState.Checked;
            this.metroSetSwitch4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.metroSetSwitch4.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.metroSetSwitch4.DisabledCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetSwitch4.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.metroSetSwitch4.Enabled = false;
            this.metroSetSwitch4.Location = new System.Drawing.Point(635, 220);
            this.metroSetSwitch4.Name = "metroSetSwitch4";
            this.metroSetSwitch4.Size = new System.Drawing.Size(58, 22);
            this.metroSetSwitch4.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetSwitch4.StyleManager = this.styleManager1;
            this.metroSetSwitch4.Switched = true;
            this.metroSetSwitch4.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.metroSetSwitch4.TabIndex = 8;
            this.metroSetSwitch4.Text = "metroSetSwitch1";
            this.metroSetSwitch4.ThemeAuthor = "Narwin";
            this.metroSetSwitch4.ThemeName = "MetroLite";
            this.metroSetSwitch4.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            // 
            // metroSetSwitch3
            // 
            this.metroSetSwitch3.BackColor = System.Drawing.Color.Transparent;
            this.metroSetSwitch3.BackgroundColor = System.Drawing.Color.Empty;
            this.metroSetSwitch3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(165)))), ((int)(((byte)(159)))), ((int)(((byte)(147)))));
            this.metroSetSwitch3.CheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetSwitch3.CheckState = MetroSet_UI.Enums.CheckState.Unchecked;
            this.metroSetSwitch3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.metroSetSwitch3.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.metroSetSwitch3.DisabledCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetSwitch3.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.metroSetSwitch3.Enabled = false;
            this.metroSetSwitch3.Location = new System.Drawing.Point(635, 179);
            this.metroSetSwitch3.Name = "metroSetSwitch3";
            this.metroSetSwitch3.Size = new System.Drawing.Size(58, 22);
            this.metroSetSwitch3.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetSwitch3.StyleManager = this.styleManager1;
            this.metroSetSwitch3.Switched = false;
            this.metroSetSwitch3.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.metroSetSwitch3.TabIndex = 7;
            this.metroSetSwitch3.Text = "metroSetSwitch1";
            this.metroSetSwitch3.ThemeAuthor = "Narwin";
            this.metroSetSwitch3.ThemeName = "MetroLite";
            this.metroSetSwitch3.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            // 
            // metroSetSwitch2
            // 
            this.metroSetSwitch2.BackColor = System.Drawing.Color.Transparent;
            this.metroSetSwitch2.BackgroundColor = System.Drawing.Color.Empty;
            this.metroSetSwitch2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(165)))), ((int)(((byte)(159)))), ((int)(((byte)(147)))));
            this.metroSetSwitch2.CheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetSwitch2.CheckState = MetroSet_UI.Enums.CheckState.Checked;
            this.metroSetSwitch2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.metroSetSwitch2.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.metroSetSwitch2.DisabledCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetSwitch2.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.metroSetSwitch2.Location = new System.Drawing.Point(635, 134);
            this.metroSetSwitch2.Name = "metroSetSwitch2";
            this.metroSetSwitch2.Size = new System.Drawing.Size(58, 22);
            this.metroSetSwitch2.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetSwitch2.StyleManager = this.styleManager1;
            this.metroSetSwitch2.Switched = true;
            this.metroSetSwitch2.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.metroSetSwitch2.TabIndex = 7;
            this.metroSetSwitch2.Text = "metroSetSwitch1";
            this.metroSetSwitch2.ThemeAuthor = "Narwin";
            this.metroSetSwitch2.ThemeName = "MetroLite";
            this.metroSetSwitch2.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.metroSetSwitch2.SwitchedChanged += new MetroSet_UI.Controls.MetroSetSwitch.SwitchedChangedEventHandler(this.MetroSetSwitch2_SwitchedChanged);
            // 
            // metroSetSwitch1
            // 
            this.metroSetSwitch1.BackColor = System.Drawing.Color.Transparent;
            this.metroSetSwitch1.BackgroundColor = System.Drawing.Color.Empty;
            this.metroSetSwitch1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(165)))), ((int)(((byte)(159)))), ((int)(((byte)(147)))));
            this.metroSetSwitch1.CheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetSwitch1.CheckState = MetroSet_UI.Enums.CheckState.Unchecked;
            this.metroSetSwitch1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.metroSetSwitch1.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.metroSetSwitch1.DisabledCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetSwitch1.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.metroSetSwitch1.Location = new System.Drawing.Point(635, 99);
            this.metroSetSwitch1.Name = "metroSetSwitch1";
            this.metroSetSwitch1.Size = new System.Drawing.Size(58, 22);
            this.metroSetSwitch1.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetSwitch1.StyleManager = this.styleManager1;
            this.metroSetSwitch1.Switched = false;
            this.metroSetSwitch1.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.metroSetSwitch1.TabIndex = 7;
            this.metroSetSwitch1.Text = "metroSetSwitch1";
            this.metroSetSwitch1.ThemeAuthor = "Narwin";
            this.metroSetSwitch1.ThemeName = "MetroLite";
            this.metroSetSwitch1.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            // 
            // metroSetLabel12
            // 
            this.metroSetLabel12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetLabel12.Location = new System.Drawing.Point(635, 55);
            this.metroSetLabel12.Name = "metroSetLabel12";
            this.metroSetLabel12.Size = new System.Drawing.Size(130, 23);
            this.metroSetLabel12.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetLabel12.StyleManager = this.styleManager1;
            this.metroSetLabel12.TabIndex = 6;
            this.metroSetLabel12.Text = "Switches";
            this.metroSetLabel12.ThemeAuthor = "Narwin";
            this.metroSetLabel12.ThemeName = "MetroLite";
            // 
            // metroSetRadioButton4
            // 
            this.metroSetRadioButton4.BackgroundColor = System.Drawing.Color.White;
            this.metroSetRadioButton4.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.metroSetRadioButton4.Checked = true;
            this.metroSetRadioButton4.CheckSignColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetRadioButton4.CheckState = MetroSet_UI.Enums.CheckState.Checked;
            this.metroSetRadioButton4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.metroSetRadioButton4.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.metroSetRadioButton4.Enabled = false;
            this.metroSetRadioButton4.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.metroSetRadioButton4.Group = 1;
            this.metroSetRadioButton4.Location = new System.Drawing.Point(305, 219);
            this.metroSetRadioButton4.Name = "metroSetRadioButton4";
            this.metroSetRadioButton4.Size = new System.Drawing.Size(145, 17);
            this.metroSetRadioButton4.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetRadioButton4.StyleManager = this.styleManager1;
            this.metroSetRadioButton4.TabIndex = 5;
            this.metroSetRadioButton4.Text = "Disabled Checked";
            this.metroSetRadioButton4.ThemeAuthor = "Narwin";
            this.metroSetRadioButton4.ThemeName = "MetroLite";
            // 
            // metroSetRadioButton3
            // 
            this.metroSetRadioButton3.BackgroundColor = System.Drawing.Color.White;
            this.metroSetRadioButton3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.metroSetRadioButton3.Checked = true;
            this.metroSetRadioButton3.CheckSignColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetRadioButton3.CheckState = MetroSet_UI.Enums.CheckState.Checked;
            this.metroSetRadioButton3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.metroSetRadioButton3.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.metroSetRadioButton3.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.metroSetRadioButton3.Group = 1;
            this.metroSetRadioButton3.Location = new System.Drawing.Point(305, 139);
            this.metroSetRadioButton3.Name = "metroSetRadioButton3";
            this.metroSetRadioButton3.Size = new System.Drawing.Size(145, 17);
            this.metroSetRadioButton3.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetRadioButton3.StyleManager = this.styleManager1;
            this.metroSetRadioButton3.TabIndex = 5;
            this.metroSetRadioButton3.Text = "Normal Checked";
            this.metroSetRadioButton3.ThemeAuthor = "Narwin";
            this.metroSetRadioButton3.ThemeName = "MetroLite";
            // 
            // metroSetRadioButton2
            // 
            this.metroSetRadioButton2.BackgroundColor = System.Drawing.Color.White;
            this.metroSetRadioButton2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.metroSetRadioButton2.Checked = false;
            this.metroSetRadioButton2.CheckSignColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetRadioButton2.CheckState = MetroSet_UI.Enums.CheckState.Unchecked;
            this.metroSetRadioButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.metroSetRadioButton2.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.metroSetRadioButton2.Enabled = false;
            this.metroSetRadioButton2.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.metroSetRadioButton2.Group = 1;
            this.metroSetRadioButton2.Location = new System.Drawing.Point(305, 179);
            this.metroSetRadioButton2.Name = "metroSetRadioButton2";
            this.metroSetRadioButton2.Size = new System.Drawing.Size(145, 17);
            this.metroSetRadioButton2.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetRadioButton2.StyleManager = this.styleManager1;
            this.metroSetRadioButton2.TabIndex = 5;
            this.metroSetRadioButton2.Text = "Disabled Unchecked";
            this.metroSetRadioButton2.ThemeAuthor = "Narwin";
            this.metroSetRadioButton2.ThemeName = "MetroLite";
            // 
            // metroSetRadioButton1
            // 
            this.metroSetRadioButton1.BackgroundColor = System.Drawing.Color.White;
            this.metroSetRadioButton1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.metroSetRadioButton1.Checked = false;
            this.metroSetRadioButton1.CheckSignColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetRadioButton1.CheckState = MetroSet_UI.Enums.CheckState.Unchecked;
            this.metroSetRadioButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.metroSetRadioButton1.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.metroSetRadioButton1.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.metroSetRadioButton1.Group = 1;
            this.metroSetRadioButton1.Location = new System.Drawing.Point(305, 99);
            this.metroSetRadioButton1.Name = "metroSetRadioButton1";
            this.metroSetRadioButton1.Size = new System.Drawing.Size(145, 17);
            this.metroSetRadioButton1.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetRadioButton1.StyleManager = this.styleManager1;
            this.metroSetRadioButton1.TabIndex = 5;
            this.metroSetRadioButton1.Text = "Normal Unchecked";
            this.metroSetRadioButton1.ThemeAuthor = "Narwin";
            this.metroSetRadioButton1.ThemeName = "MetroLite";
            // 
            // metroSetCheckBox5
            // 
            this.metroSetCheckBox5.BackColor = System.Drawing.Color.Transparent;
            this.metroSetCheckBox5.BackgroundColor = System.Drawing.Color.White;
            this.metroSetCheckBox5.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.metroSetCheckBox5.Checked = true;
            this.metroSetCheckBox5.CheckSignColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetCheckBox5.CheckState = MetroSet_UI.Enums.CheckState.Checked;
            this.metroSetCheckBox5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.metroSetCheckBox5.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.metroSetCheckBox5.Enabled = false;
            this.metroSetCheckBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetCheckBox5.Location = new System.Drawing.Point(15, 300);
            this.metroSetCheckBox5.Name = "metroSetCheckBox5";
            this.metroSetCheckBox5.SignStyle = MetroSet_UI.Enums.SignStyle.Shape;
            this.metroSetCheckBox5.Size = new System.Drawing.Size(197, 16);
            this.metroSetCheckBox5.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetCheckBox5.StyleManager = this.styleManager1;
            this.metroSetCheckBox5.TabIndex = 4;
            this.metroSetCheckBox5.Text = "Disabled Checked With Shape";
            this.metroSetCheckBox5.ThemeAuthor = "Narwin";
            this.metroSetCheckBox5.ThemeName = "MetroLite";
            // 
            // metroSetCheckBox4
            // 
            this.metroSetCheckBox4.BackColor = System.Drawing.Color.Transparent;
            this.metroSetCheckBox4.BackgroundColor = System.Drawing.Color.White;
            this.metroSetCheckBox4.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.metroSetCheckBox4.Checked = true;
            this.metroSetCheckBox4.CheckSignColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetCheckBox4.CheckState = MetroSet_UI.Enums.CheckState.Checked;
            this.metroSetCheckBox4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.metroSetCheckBox4.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.metroSetCheckBox4.Enabled = false;
            this.metroSetCheckBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetCheckBox4.Location = new System.Drawing.Point(15, 260);
            this.metroSetCheckBox4.Name = "metroSetCheckBox4";
            this.metroSetCheckBox4.SignStyle = MetroSet_UI.Enums.SignStyle.Sign;
            this.metroSetCheckBox4.Size = new System.Drawing.Size(187, 16);
            this.metroSetCheckBox4.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetCheckBox4.StyleManager = this.styleManager1;
            this.metroSetCheckBox4.TabIndex = 4;
            this.metroSetCheckBox4.Text = "Disabled Checked With Tick";
            this.metroSetCheckBox4.ThemeAuthor = "Narwin";
            this.metroSetCheckBox4.ThemeName = "MetroLite";
            // 
            // metroSetCheckBox3
            // 
            this.metroSetCheckBox3.BackColor = System.Drawing.Color.Transparent;
            this.metroSetCheckBox3.BackgroundColor = System.Drawing.Color.White;
            this.metroSetCheckBox3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.metroSetCheckBox3.Checked = true;
            this.metroSetCheckBox3.CheckSignColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetCheckBox3.CheckState = MetroSet_UI.Enums.CheckState.Checked;
            this.metroSetCheckBox3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.metroSetCheckBox3.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.metroSetCheckBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetCheckBox3.Location = new System.Drawing.Point(15, 180);
            this.metroSetCheckBox3.Name = "metroSetCheckBox3";
            this.metroSetCheckBox3.SignStyle = MetroSet_UI.Enums.SignStyle.Shape;
            this.metroSetCheckBox3.Size = new System.Drawing.Size(197, 16);
            this.metroSetCheckBox3.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetCheckBox3.StyleManager = this.styleManager1;
            this.metroSetCheckBox3.TabIndex = 4;
            this.metroSetCheckBox3.Text = "Normal  Checked With Shape";
            this.metroSetCheckBox3.ThemeAuthor = "Narwin";
            this.metroSetCheckBox3.ThemeName = "MetroLite";
            // 
            // metroSetCheckBox2
            // 
            this.metroSetCheckBox2.BackColor = System.Drawing.Color.Transparent;
            this.metroSetCheckBox2.BackgroundColor = System.Drawing.Color.White;
            this.metroSetCheckBox2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.metroSetCheckBox2.Checked = true;
            this.metroSetCheckBox2.CheckSignColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetCheckBox2.CheckState = MetroSet_UI.Enums.CheckState.Checked;
            this.metroSetCheckBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.metroSetCheckBox2.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.metroSetCheckBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetCheckBox2.Location = new System.Drawing.Point(15, 140);
            this.metroSetCheckBox2.Name = "metroSetCheckBox2";
            this.metroSetCheckBox2.SignStyle = MetroSet_UI.Enums.SignStyle.Sign;
            this.metroSetCheckBox2.Size = new System.Drawing.Size(187, 16);
            this.metroSetCheckBox2.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetCheckBox2.StyleManager = this.styleManager1;
            this.metroSetCheckBox2.TabIndex = 4;
            this.metroSetCheckBox2.Text = "Normal  Checked With Tick";
            this.metroSetCheckBox2.ThemeAuthor = "Narwin";
            this.metroSetCheckBox2.ThemeName = "MetroLite";
            // 
            // metroSetCheckBox6
            // 
            this.metroSetCheckBox6.BackColor = System.Drawing.Color.Transparent;
            this.metroSetCheckBox6.BackgroundColor = System.Drawing.Color.White;
            this.metroSetCheckBox6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.metroSetCheckBox6.Checked = false;
            this.metroSetCheckBox6.CheckSignColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetCheckBox6.CheckState = MetroSet_UI.Enums.CheckState.Unchecked;
            this.metroSetCheckBox6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.metroSetCheckBox6.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.metroSetCheckBox6.Enabled = false;
            this.metroSetCheckBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetCheckBox6.Location = new System.Drawing.Point(15, 220);
            this.metroSetCheckBox6.Name = "metroSetCheckBox6";
            this.metroSetCheckBox6.SignStyle = MetroSet_UI.Enums.SignStyle.Sign;
            this.metroSetCheckBox6.Size = new System.Drawing.Size(148, 16);
            this.metroSetCheckBox6.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetCheckBox6.StyleManager = this.styleManager1;
            this.metroSetCheckBox6.TabIndex = 4;
            this.metroSetCheckBox6.Text = "Disabled Unchecked";
            this.metroSetCheckBox6.ThemeAuthor = "Narwin";
            this.metroSetCheckBox6.ThemeName = "MetroLite";
            // 
            // metroSetCheckBox1
            // 
            this.metroSetCheckBox1.BackColor = System.Drawing.Color.Transparent;
            this.metroSetCheckBox1.BackgroundColor = System.Drawing.Color.White;
            this.metroSetCheckBox1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.metroSetCheckBox1.Checked = false;
            this.metroSetCheckBox1.CheckSignColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetCheckBox1.CheckState = MetroSet_UI.Enums.CheckState.Unchecked;
            this.metroSetCheckBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.metroSetCheckBox1.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.metroSetCheckBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetCheckBox1.Location = new System.Drawing.Point(15, 100);
            this.metroSetCheckBox1.Name = "metroSetCheckBox1";
            this.metroSetCheckBox1.SignStyle = MetroSet_UI.Enums.SignStyle.Sign;
            this.metroSetCheckBox1.Size = new System.Drawing.Size(148, 16);
            this.metroSetCheckBox1.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetCheckBox1.StyleManager = this.styleManager1;
            this.metroSetCheckBox1.TabIndex = 4;
            this.metroSetCheckBox1.Text = "Normal Unchecked";
            this.metroSetCheckBox1.ThemeAuthor = "Narwin";
            this.metroSetCheckBox1.ThemeName = "MetroLite";
            // 
            // metroSetLabel11
            // 
            this.metroSetLabel11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetLabel11.Location = new System.Drawing.Point(305, 55);
            this.metroSetLabel11.Name = "metroSetLabel11";
            this.metroSetLabel11.Size = new System.Drawing.Size(145, 23);
            this.metroSetLabel11.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetLabel11.StyleManager = this.styleManager1;
            this.metroSetLabel11.TabIndex = 3;
            this.metroSetLabel11.Text = "Normal RadioButton";
            this.metroSetLabel11.ThemeAuthor = "Narwin";
            this.metroSetLabel11.ThemeName = "MetroLite";
            // 
            // metroSetLabel10
            // 
            this.metroSetLabel10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetLabel10.Location = new System.Drawing.Point(15, 55);
            this.metroSetLabel10.Name = "metroSetLabel10";
            this.metroSetLabel10.Size = new System.Drawing.Size(130, 23);
            this.metroSetLabel10.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetLabel10.StyleManager = this.styleManager1;
            this.metroSetLabel10.TabIndex = 3;
            this.metroSetLabel10.Text = "Normal CheckBox";
            this.metroSetLabel10.ThemeAuthor = "Narwin";
            this.metroSetLabel10.ThemeName = "MetroLite";
            // 
            // metroSetTabPage5
            // 
            this.metroSetTabPage5.BaseColor = System.Drawing.Color.White;
            this.metroSetTabPage5.Controls.Add(this.metroSetTrackBar2);
            this.metroSetTabPage5.Controls.Add(this.metroSetTrackBar1);
            this.metroSetTabPage5.Controls.Add(this.metroSetProgressBar4);
            this.metroSetTabPage5.Controls.Add(this.metroSetProgressBar3);
            this.metroSetTabPage5.Controls.Add(this.metroSetLabel14);
            this.metroSetTabPage5.Controls.Add(this.metroSetLabel15);
            this.metroSetTabPage5.Controls.Add(this.metroSetLabel13);
            this.metroSetTabPage5.Controls.Add(this.metroSetProgressBar2);
            this.metroSetTabPage5.Controls.Add(this.metroSetProgressBar1);
            this.metroSetTabPage5.ImageIndex = 0;
            this.metroSetTabPage5.ImageKey = null;
            this.metroSetTabPage5.Location = new System.Drawing.Point(4, 42);
            this.metroSetTabPage5.Name = "metroSetTabPage5";
            this.metroSetTabPage5.Size = new System.Drawing.Size(1106, 570);
            this.metroSetTabPage5.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetTabPage5.StyleManager = this.styleManager1;
            this.metroSetTabPage5.TabIndex = 4;
            this.metroSetTabPage5.Text = "Progress";
            this.metroSetTabPage5.ThemeAuthor = "Narwin";
            this.metroSetTabPage5.ThemeName = "MetroLite";
            this.metroSetTabPage5.ToolTipText = null;
            // 
            // metroSetTrackBar2
            // 
            this.metroSetTrackBar2.BackColor = System.Drawing.Color.Transparent;
            this.metroSetTrackBar2.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.metroSetTrackBar2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.metroSetTrackBar2.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(235)))), ((int)(((byte)(235)))));
            this.metroSetTrackBar2.DisabledBorderColor = System.Drawing.Color.Empty;
            this.metroSetTrackBar2.DisabledHandlerColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(196)))), ((int)(((byte)(196)))));
            this.metroSetTrackBar2.DisabledValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.metroSetTrackBar2.Enabled = false;
            this.metroSetTrackBar2.HandlerColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            this.metroSetTrackBar2.Location = new System.Drawing.Point(494, 147);
            this.metroSetTrackBar2.Maximum = 100;
            this.metroSetTrackBar2.Minimum = 0;
            this.metroSetTrackBar2.Name = "metroSetTrackBar2";
            this.metroSetTrackBar2.Size = new System.Drawing.Size(241, 16);
            this.metroSetTrackBar2.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetTrackBar2.StyleManager = this.styleManager1;
            this.metroSetTrackBar2.TabIndex = 4;
            this.metroSetTrackBar2.Text = "metroSetTrackBar1";
            this.metroSetTrackBar2.ThemeAuthor = "Narwin";
            this.metroSetTrackBar2.ThemeName = "MetroLite";
            this.metroSetTrackBar2.Value = 45;
            this.metroSetTrackBar2.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            // 
            // metroSetTrackBar1
            // 
            this.metroSetTrackBar1.BackColor = System.Drawing.Color.Transparent;
            this.metroSetTrackBar1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.metroSetTrackBar1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.metroSetTrackBar1.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(235)))), ((int)(((byte)(235)))));
            this.metroSetTrackBar1.DisabledBorderColor = System.Drawing.Color.Empty;
            this.metroSetTrackBar1.DisabledHandlerColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(196)))), ((int)(((byte)(196)))));
            this.metroSetTrackBar1.DisabledValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.metroSetTrackBar1.HandlerColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            this.metroSetTrackBar1.Location = new System.Drawing.Point(494, 102);
            this.metroSetTrackBar1.Maximum = 100;
            this.metroSetTrackBar1.Minimum = 0;
            this.metroSetTrackBar1.Name = "metroSetTrackBar1";
            this.metroSetTrackBar1.Size = new System.Drawing.Size(241, 16);
            this.metroSetTrackBar1.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetTrackBar1.StyleManager = this.styleManager1;
            this.metroSetTrackBar1.TabIndex = 4;
            this.metroSetTrackBar1.Text = "metroSetTrackBar1";
            this.metroSetTrackBar1.ThemeAuthor = "Narwin";
            this.metroSetTrackBar1.ThemeName = "MetroLite";
            this.metroSetTrackBar1.Value = 75;
            this.metroSetTrackBar1.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            // 
            // metroSetProgressBar4
            // 
            this.metroSetProgressBar4.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.metroSetProgressBar4.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.metroSetProgressBar4.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.metroSetProgressBar4.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.metroSetProgressBar4.DisabledProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetProgressBar4.Enabled = false;
            this.metroSetProgressBar4.Location = new System.Drawing.Point(144, 289);
            this.metroSetProgressBar4.Maximum = 100;
            this.metroSetProgressBar4.Minimum = 0;
            this.metroSetProgressBar4.Name = "metroSetProgressBar4";
            this.metroSetProgressBar4.Orientation = MetroSet_UI.Enums.ProgressOrientation.Vertical;
            this.metroSetProgressBar4.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetProgressBar4.Size = new System.Drawing.Size(30, 211);
            this.metroSetProgressBar4.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetProgressBar4.StyleManager = this.styleManager1;
            this.metroSetProgressBar4.TabIndex = 3;
            this.metroSetProgressBar4.Text = "metroSetProgressBar3";
            this.metroSetProgressBar4.ThemeAuthor = "Narwin";
            this.metroSetProgressBar4.ThemeName = "MetroLite";
            this.metroSetProgressBar4.Value = 30;
            // 
            // metroSetProgressBar3
            // 
            this.metroSetProgressBar3.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.metroSetProgressBar3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.metroSetProgressBar3.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.metroSetProgressBar3.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.metroSetProgressBar3.DisabledProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetProgressBar3.Location = new System.Drawing.Point(15, 289);
            this.metroSetProgressBar3.Maximum = 100;
            this.metroSetProgressBar3.Minimum = 0;
            this.metroSetProgressBar3.Name = "metroSetProgressBar3";
            this.metroSetProgressBar3.Orientation = MetroSet_UI.Enums.ProgressOrientation.Vertical;
            this.metroSetProgressBar3.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetProgressBar3.Size = new System.Drawing.Size(30, 211);
            this.metroSetProgressBar3.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetProgressBar3.StyleManager = this.styleManager1;
            this.metroSetProgressBar3.TabIndex = 3;
            this.metroSetProgressBar3.Text = "metroSetProgressBar3";
            this.metroSetProgressBar3.ThemeAuthor = "Narwin";
            this.metroSetProgressBar3.ThemeName = "MetroLite";
            this.metroSetProgressBar3.Value = 70;
            // 
            // metroSetLabel14
            // 
            this.metroSetLabel14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetLabel14.Location = new System.Drawing.Point(15, 209);
            this.metroSetLabel14.Name = "metroSetLabel14";
            this.metroSetLabel14.Size = new System.Drawing.Size(159, 23);
            this.metroSetLabel14.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetLabel14.StyleManager = this.styleManager1;
            this.metroSetLabel14.TabIndex = 2;
            this.metroSetLabel14.Text = "Vertical ProgressBar";
            this.metroSetLabel14.ThemeAuthor = "Narwin";
            this.metroSetLabel14.ThemeName = "MetroLite";
            // 
            // metroSetLabel15
            // 
            this.metroSetLabel15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetLabel15.Location = new System.Drawing.Point(494, 59);
            this.metroSetLabel15.Name = "metroSetLabel15";
            this.metroSetLabel15.Size = new System.Drawing.Size(159, 23);
            this.metroSetLabel15.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetLabel15.StyleManager = this.styleManager1;
            this.metroSetLabel15.TabIndex = 2;
            this.metroSetLabel15.Text = "Horizontal ProgressBar";
            this.metroSetLabel15.ThemeAuthor = "Narwin";
            this.metroSetLabel15.ThemeName = "MetroLite";
            // 
            // metroSetLabel13
            // 
            this.metroSetLabel13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetLabel13.Location = new System.Drawing.Point(15, 59);
            this.metroSetLabel13.Name = "metroSetLabel13";
            this.metroSetLabel13.Size = new System.Drawing.Size(159, 23);
            this.metroSetLabel13.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetLabel13.StyleManager = this.styleManager1;
            this.metroSetLabel13.TabIndex = 2;
            this.metroSetLabel13.Text = "Horizontal ProgressBar";
            this.metroSetLabel13.ThemeAuthor = "Narwin";
            this.metroSetLabel13.ThemeName = "MetroLite";
            // 
            // metroSetProgressBar2
            // 
            this.metroSetProgressBar2.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.metroSetProgressBar2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.metroSetProgressBar2.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.metroSetProgressBar2.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.metroSetProgressBar2.DisabledProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetProgressBar2.Enabled = false;
            this.metroSetProgressBar2.Location = new System.Drawing.Point(15, 147);
            this.metroSetProgressBar2.Maximum = 100;
            this.metroSetProgressBar2.Minimum = 0;
            this.metroSetProgressBar2.Name = "metroSetProgressBar2";
            this.metroSetProgressBar2.Orientation = MetroSet_UI.Enums.ProgressOrientation.Horizontal;
            this.metroSetProgressBar2.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetProgressBar2.Size = new System.Drawing.Size(323, 23);
            this.metroSetProgressBar2.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetProgressBar2.StyleManager = this.styleManager1;
            this.metroSetProgressBar2.TabIndex = 0;
            this.metroSetProgressBar2.Text = "metroSetProgressBar1";
            this.metroSetProgressBar2.ThemeAuthor = "Narwin";
            this.metroSetProgressBar2.ThemeName = "MetroLite";
            this.metroSetProgressBar2.Value = 40;
            // 
            // metroSetProgressBar1
            // 
            this.metroSetProgressBar1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.metroSetProgressBar1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.metroSetProgressBar1.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.metroSetProgressBar1.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.metroSetProgressBar1.DisabledProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetProgressBar1.Location = new System.Drawing.Point(15, 102);
            this.metroSetProgressBar1.Maximum = 100;
            this.metroSetProgressBar1.Minimum = 0;
            this.metroSetProgressBar1.Name = "metroSetProgressBar1";
            this.metroSetProgressBar1.Orientation = MetroSet_UI.Enums.ProgressOrientation.Horizontal;
            this.metroSetProgressBar1.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(177)))), ((int)(((byte)(225)))));
            this.metroSetProgressBar1.Size = new System.Drawing.Size(323, 23);
            this.metroSetProgressBar1.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetProgressBar1.StyleManager = this.styleManager1;
            this.metroSetProgressBar1.TabIndex = 0;
            this.metroSetProgressBar1.Text = "metroSetProgressBar1";
            this.metroSetProgressBar1.ThemeAuthor = "Narwin";
            this.metroSetProgressBar1.ThemeName = "MetroLite";
            this.metroSetProgressBar1.Value = 60;
            // 
            // metroSetTabPage6
            // 
            this.metroSetTabPage6.BaseColor = System.Drawing.Color.White;
            this.metroSetTabPage6.Controls.Add(this.metroSetLink2);
            this.metroSetTabPage6.Controls.Add(this.metroSetLink1);
            this.metroSetTabPage6.Controls.Add(this.metroSetLabel17);
            this.metroSetTabPage6.Controls.Add(this.metroSetLabel16);
            this.metroSetTabPage6.ImageIndex = 0;
            this.metroSetTabPage6.ImageKey = null;
            this.metroSetTabPage6.Location = new System.Drawing.Point(4, 42);
            this.metroSetTabPage6.Name = "metroSetTabPage6";
            this.metroSetTabPage6.Size = new System.Drawing.Size(1106, 570);
            this.metroSetTabPage6.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetTabPage6.StyleManager = this.styleManager1;
            this.metroSetTabPage6.TabIndex = 5;
            this.metroSetTabPage6.Text = "Labels";
            this.metroSetTabPage6.ThemeAuthor = "Narwin";
            this.metroSetTabPage6.ThemeName = "MetroLite";
            this.metroSetTabPage6.ToolTipText = null;
            // 
            // metroSetLink2
            // 
            this.metroSetLink2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.metroSetLink2.Enabled = false;
            this.metroSetLink2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetLink2.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.metroSetLink2.Location = new System.Drawing.Point(309, 110);
            this.metroSetLink2.Name = "metroSetLink2";
            this.metroSetLink2.Size = new System.Drawing.Size(100, 23);
            this.metroSetLink2.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetLink2.StyleManager = this.styleManager1;
            this.metroSetLink2.TabIndex = 5;
            this.metroSetLink2.TabStop = true;
            this.metroSetLink2.Text = "Disabled Link";
            this.metroSetLink2.ThemeAuthor = "Narwin";
            this.metroSetLink2.ThemeName = "MetroLite";
            this.metroSetLink2.VisitedLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(157)))), ((int)(((byte)(205)))));
            // 
            // metroSetLink1
            // 
            this.metroSetLink1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.metroSetLink1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetLink1.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.metroSetLink1.Location = new System.Drawing.Point(309, 59);
            this.metroSetLink1.Name = "metroSetLink1";
            this.metroSetLink1.Size = new System.Drawing.Size(100, 23);
            this.metroSetLink1.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetLink1.StyleManager = this.styleManager1;
            this.metroSetLink1.TabIndex = 5;
            this.metroSetLink1.TabStop = true;
            this.metroSetLink1.Text = "Normal Link";
            this.metroSetLink1.ThemeAuthor = "Narwin";
            this.metroSetLink1.ThemeName = "MetroLite";
            this.metroSetLink1.VisitedLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(157)))), ((int)(((byte)(205)))));
            // 
            // metroSetLabel17
            // 
            this.metroSetLabel17.Enabled = false;
            this.metroSetLabel17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetLabel17.Location = new System.Drawing.Point(15, 110);
            this.metroSetLabel17.Name = "metroSetLabel17";
            this.metroSetLabel17.Size = new System.Drawing.Size(108, 23);
            this.metroSetLabel17.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetLabel17.StyleManager = this.styleManager1;
            this.metroSetLabel17.TabIndex = 3;
            this.metroSetLabel17.Text = "Disabled Label";
            this.metroSetLabel17.ThemeAuthor = "Narwin";
            this.metroSetLabel17.ThemeName = "MetroLite";
            // 
            // metroSetLabel16
            // 
            this.metroSetLabel16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetLabel16.Location = new System.Drawing.Point(15, 59);
            this.metroSetLabel16.Name = "metroSetLabel16";
            this.metroSetLabel16.Size = new System.Drawing.Size(100, 23);
            this.metroSetLabel16.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetLabel16.StyleManager = this.styleManager1;
            this.metroSetLabel16.TabIndex = 4;
            this.metroSetLabel16.Text = "Normal Label";
            this.metroSetLabel16.ThemeAuthor = "Narwin";
            this.metroSetLabel16.ThemeName = "MetroLite";
            // 
            // metroSetTabPage7
            // 
            this.metroSetTabPage7.BaseColor = System.Drawing.Color.White;
            this.metroSetTabPage7.Controls.Add(this.metroSetButton7);
            this.metroSetTabPage7.Controls.Add(this.metroSetButton6);
            this.metroSetTabPage7.Controls.Add(this.metroSetButton5);
            this.metroSetTabPage7.Controls.Add(this.metroSetButton4);
            this.metroSetTabPage7.Controls.Add(this.metroSetButton3);
            this.metroSetTabPage7.Controls.Add(this.metroSetLabel18);
            this.metroSetTabPage7.ImageIndex = 0;
            this.metroSetTabPage7.ImageKey = null;
            this.metroSetTabPage7.Location = new System.Drawing.Point(4, 42);
            this.metroSetTabPage7.Name = "metroSetTabPage7";
            this.metroSetTabPage7.Size = new System.Drawing.Size(1106, 570);
            this.metroSetTabPage7.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetTabPage7.StyleManager = this.styleManager1;
            this.metroSetTabPage7.TabIndex = 6;
            this.metroSetTabPage7.Text = "Message";
            this.metroSetTabPage7.ThemeAuthor = "Narwin";
            this.metroSetTabPage7.ThemeName = "MetroLite";
            this.metroSetTabPage7.ToolTipText = null;
            // 
            // metroSetButton7
            // 
            this.metroSetButton7.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.metroSetButton7.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.metroSetButton7.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.metroSetButton7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetButton7.HoverBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.metroSetButton7.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.metroSetButton7.HoverTextColor = System.Drawing.Color.White;
            this.metroSetButton7.Location = new System.Drawing.Point(506, 111);
            this.metroSetButton7.Name = "metroSetButton7";
            this.metroSetButton7.NormalBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.metroSetButton7.NormalColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.metroSetButton7.NormalTextColor = System.Drawing.Color.Black;
            this.metroSetButton7.PressBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.metroSetButton7.PressColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.metroSetButton7.PressTextColor = System.Drawing.Color.White;
            this.metroSetButton7.Size = new System.Drawing.Size(167, 40);
            this.metroSetButton7.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetButton7.StyleManager = this.styleManager1;
            this.metroSetButton7.TabIndex = 2;
            this.metroSetButton7.Text = "Question Message";
            this.metroSetButton7.ThemeAuthor = "Narwin";
            this.metroSetButton7.ThemeName = "MetroLite";
            this.metroSetButton7.Click += new System.EventHandler(this.MetroSetButton7_Click_1);
            // 
            // metroSetButton6
            // 
            this.metroSetButton6.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.metroSetButton6.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.metroSetButton6.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.metroSetButton6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetButton6.HoverBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.metroSetButton6.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.metroSetButton6.HoverTextColor = System.Drawing.Color.White;
            this.metroSetButton6.Location = new System.Drawing.Point(258, 183);
            this.metroSetButton6.Name = "metroSetButton6";
            this.metroSetButton6.NormalBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.metroSetButton6.NormalColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.metroSetButton6.NormalTextColor = System.Drawing.Color.Black;
            this.metroSetButton6.PressBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.metroSetButton6.PressColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.metroSetButton6.PressTextColor = System.Drawing.Color.White;
            this.metroSetButton6.Size = new System.Drawing.Size(167, 40);
            this.metroSetButton6.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetButton6.StyleManager = this.styleManager1;
            this.metroSetButton6.TabIndex = 1;
            this.metroSetButton6.Text = "Warning Message";
            this.metroSetButton6.ThemeAuthor = "Narwin";
            this.metroSetButton6.ThemeName = "MetroLite";
            this.metroSetButton6.Click += new System.EventHandler(this.MetroSetButton6_Click);
            // 
            // metroSetButton5
            // 
            this.metroSetButton5.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.metroSetButton5.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.metroSetButton5.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.metroSetButton5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetButton5.HoverBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.metroSetButton5.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.metroSetButton5.HoverTextColor = System.Drawing.Color.White;
            this.metroSetButton5.Location = new System.Drawing.Point(258, 111);
            this.metroSetButton5.Name = "metroSetButton5";
            this.metroSetButton5.NormalBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.metroSetButton5.NormalColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.metroSetButton5.NormalTextColor = System.Drawing.Color.Black;
            this.metroSetButton5.PressBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.metroSetButton5.PressColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.metroSetButton5.PressTextColor = System.Drawing.Color.White;
            this.metroSetButton5.Size = new System.Drawing.Size(167, 40);
            this.metroSetButton5.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetButton5.StyleManager = this.styleManager1;
            this.metroSetButton5.TabIndex = 1;
            this.metroSetButton5.Text = "Info Message";
            this.metroSetButton5.ThemeAuthor = "Narwin";
            this.metroSetButton5.ThemeName = "MetroLite";
            this.metroSetButton5.Click += new System.EventHandler(this.MetroSetButton5_Click);
            // 
            // metroSetButton4
            // 
            this.metroSetButton4.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.metroSetButton4.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.metroSetButton4.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.metroSetButton4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetButton4.HoverBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.metroSetButton4.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.metroSetButton4.HoverTextColor = System.Drawing.Color.White;
            this.metroSetButton4.Location = new System.Drawing.Point(15, 183);
            this.metroSetButton4.Name = "metroSetButton4";
            this.metroSetButton4.NormalBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.metroSetButton4.NormalColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.metroSetButton4.NormalTextColor = System.Drawing.Color.Black;
            this.metroSetButton4.PressBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.metroSetButton4.PressColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.metroSetButton4.PressTextColor = System.Drawing.Color.White;
            this.metroSetButton4.Size = new System.Drawing.Size(167, 40);
            this.metroSetButton4.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetButton4.StyleManager = this.styleManager1;
            this.metroSetButton4.TabIndex = 1;
            this.metroSetButton4.Text = "Stop Message";
            this.metroSetButton4.ThemeAuthor = "Narwin";
            this.metroSetButton4.ThemeName = "MetroLite";
            this.metroSetButton4.Click += new System.EventHandler(this.MetroSetButton4_Click);
            // 
            // metroSetButton3
            // 
            this.metroSetButton3.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.metroSetButton3.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.metroSetButton3.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.metroSetButton3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetButton3.HoverBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.metroSetButton3.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.metroSetButton3.HoverTextColor = System.Drawing.Color.White;
            this.metroSetButton3.Location = new System.Drawing.Point(15, 111);
            this.metroSetButton3.Name = "metroSetButton3";
            this.metroSetButton3.NormalBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.metroSetButton3.NormalColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.metroSetButton3.NormalTextColor = System.Drawing.Color.Black;
            this.metroSetButton3.PressBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.metroSetButton3.PressColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.metroSetButton3.PressTextColor = System.Drawing.Color.White;
            this.metroSetButton3.Size = new System.Drawing.Size(167, 40);
            this.metroSetButton3.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetButton3.StyleManager = this.styleManager1;
            this.metroSetButton3.TabIndex = 1;
            this.metroSetButton3.Text = "Normal Message";
            this.metroSetButton3.ThemeAuthor = "Narwin";
            this.metroSetButton3.ThemeName = "MetroLite";
            this.metroSetButton3.Click += new System.EventHandler(this.MetroSetButton3_Click);
            // 
            // metroSetLabel18
            // 
            this.metroSetLabel18.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.metroSetLabel18.Location = new System.Drawing.Point(15, 59);
            this.metroSetLabel18.Name = "metroSetLabel18";
            this.metroSetLabel18.Size = new System.Drawing.Size(100, 23);
            this.metroSetLabel18.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetLabel18.StyleManager = this.styleManager1;
            this.metroSetLabel18.TabIndex = 0;
            this.metroSetLabel18.Text = "MessageBox";
            this.metroSetLabel18.ThemeAuthor = "Narwin";
            this.metroSetLabel18.ThemeName = "MetroLite";
            // 
            // metroSetControlBox1
            // 
            this.metroSetControlBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.metroSetControlBox1.BackColor = System.Drawing.Color.Transparent;
            this.metroSetControlBox1.CloseHoverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(183)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.metroSetControlBox1.CloseHoverForeColor = System.Drawing.Color.White;
            this.metroSetControlBox1.CloseNormalForeColor = System.Drawing.Color.Gray;
            this.metroSetControlBox1.DisabledForeColor = System.Drawing.Color.DimGray;
            this.metroSetControlBox1.Location = new System.Drawing.Point(1026, 13);
            this.metroSetControlBox1.MaximizeBox = true;
            this.metroSetControlBox1.MaximizeHoverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.metroSetControlBox1.MaximizeHoverForeColor = System.Drawing.Color.Gray;
            this.metroSetControlBox1.MaximizeNormalForeColor = System.Drawing.Color.Gray;
            this.metroSetControlBox1.MinimizeBox = true;
            this.metroSetControlBox1.MinimizeHoverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.metroSetControlBox1.MinimizeHoverForeColor = System.Drawing.Color.Gray;
            this.metroSetControlBox1.MinimizeNormalForeColor = System.Drawing.Color.Gray;
            this.metroSetControlBox1.Name = "metroSetControlBox1";
            this.metroSetControlBox1.Size = new System.Drawing.Size(100, 25);
            this.metroSetControlBox1.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetControlBox1.StyleManager = this.styleManager1;
            this.metroSetControlBox1.TabIndex = 1;
            this.metroSetControlBox1.Text = "metroSetControlBox1";
            this.metroSetControlBox1.ThemeAuthor = "Narwin";
            this.metroSetControlBox1.ThemeName = "MetroLite";
            // 
            // metroSetToolTip1
            // 
            this.metroSetToolTip1.BackColor = System.Drawing.Color.White;
            this.metroSetToolTip1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.metroSetToolTip1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.metroSetToolTip1.OwnerDraw = true;
            this.metroSetToolTip1.Style = MetroSet_UI.Design.Style.Light;
            this.metroSetToolTip1.StyleManager = null;
            this.metroSetToolTip1.ThemeAuthor = "Narwin";
            this.metroSetToolTip1.ThemeName = "MetroLite";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1138, 698);
            this.Controls.Add(this.metroSetControlBox1);
            this.Controls.Add(this.metroSetTabControl1);
            this.Name = "Form1";
            this.SmallRectThickness = 2;
            this.StyleManager = this.styleManager1;
            this.Text = "METROSET UI";
            this.metroSetTabControl1.ResumeLayout(false);
            this.metroSetTabPage2.ResumeLayout(false);
            this.metroSetTabPage1.ResumeLayout(false);
            this.metroSetTabPage3.ResumeLayout(false);
            this.metroSetContextMenuStrip1.ResumeLayout(false);
            this.metroSetTabPage4.ResumeLayout(false);
            this.metroSetTabPage5.ResumeLayout(false);
            this.metroSetTabPage6.ResumeLayout(false);
            this.metroSetTabPage7.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private MetroSet_UI.Controls.MetroSetTabControl metroSetTabControl1;
        private MetroSet_UI.Child.MetroSetTabPage metroSetTabPage2;
        private MetroSet_UI.Child.MetroSetTabPage metroSetTabPage3;
        private MetroSet_UI.Child.MetroSetTabPage metroSetTabPage4;
        private MetroSet_UI.Child.MetroSetTabPage metroSetTabPage5;
        private MetroSet_UI.Child.MetroSetTabPage metroSetTabPage6;
        private MetroSet_UI.Child.MetroSetTabPage metroSetTabPage7;
        private MetroSet_UI.Controls.MetroSetControlBox metroSetControlBox1;
        private MetroSet_UI.Controls.MetroDefaultSetButton metroSetDefaultButton1;
        private MetroSet_UI.Controls.MetroSetBadge metroSetBadge1;
        private MetroSet_UI.Controls.MetroSetLabel metroSetLabel2;
        private MetroSet_UI.Controls.MetroSetLabel metroSetLabel1;
        private MetroSet_UI.Controls.MetroDefaultSetButton metroSetDefaultButton2;
        private MetroSet_UI.Controls.MetroSetBadge metroSetBadge2;
        private MetroSet_UI.Controls.MetroSetEllipse metroSetEllipse3;
        private MetroSet_UI.Controls.MetroSetEllipse metroSetEllipse2;
        private MetroSet_UI.Controls.MetroSetEllipse metroSetEllipse1;
        private MetroSet_UI.Controls.MetroSetLabel metroSetLabel3;
        private MetroSet_UI.Controls.MetroSetTextBox metroSetTextBox1;
        private MetroSet_UI.Controls.MetroSetLabel metroSetLabel5;
        private MetroSet_UI.Controls.MetroSetTextBox metroSetTextBox2;
        private MetroSet_UI.Controls.MetroSetNumeric metroSetNumeric2;
        private MetroSet_UI.Controls.MetroSetRichTextBox metroSetRichTextBox1;
        private MetroSet_UI.Controls.MetroSetTextBox metroSetTextBox3;
        private MetroSet_UI.Controls.MetroSetLabel metroSetLabel6;
        private MetroSet_UI.Controls.MetroSetLabel metroSetLabel7;
        private MetroSet_UI.Controls.MetroSetNumeric metroSetNumeric3;
        private MetroSet_UI.Controls.MetroSetComboBox metroSetComboBox2;
        private MetroSet_UI.Controls.MetroSetComboBox metroSetComboBox1;
        private MetroSet_UI.Controls.MetroSetLabel metroSetLabel8;
        private MetroSet_UI.Controls.MetroSetLabel metroSetLabel9;
        private MetroSet_UI.Controls.MetroSetListBox metroSetListBox2;
        private MetroSet_UI.Controls.MetroSetCheckBox metroSetCheckBox5;
        private MetroSet_UI.Controls.MetroSetCheckBox metroSetCheckBox4;
        private MetroSet_UI.Controls.MetroSetCheckBox metroSetCheckBox3;
        private MetroSet_UI.Controls.MetroSetCheckBox metroSetCheckBox2;
        private MetroSet_UI.Controls.MetroSetCheckBox metroSetCheckBox1;
        private MetroSet_UI.Controls.MetroSetLabel metroSetLabel10;
        private MetroSet_UI.Controls.MetroSetCheckBox metroSetCheckBox6;
        private MetroSet_UI.Controls.MetroSetRadioButton metroSetRadioButton4;
        private MetroSet_UI.Controls.MetroSetRadioButton metroSetRadioButton3;
        private MetroSet_UI.Controls.MetroSetRadioButton metroSetRadioButton2;
        private MetroSet_UI.Controls.MetroSetRadioButton metroSetRadioButton1;
        private MetroSet_UI.Controls.MetroSetLabel metroSetLabel11;
        private MetroSet_UI.Controls.MetroSetSwitch metroSetSwitch3;
        private MetroSet_UI.Controls.MetroSetSwitch metroSetSwitch2;
        private MetroSet_UI.Controls.MetroSetSwitch metroSetSwitch1;
        private MetroSet_UI.Controls.MetroSetLabel metroSetLabel12;
        private MetroSet_UI.Controls.MetroSetLabel metroSetLabel13;
        private MetroSet_UI.Controls.MetroSetProgressBar metroSetProgressBar2;
        private MetroSet_UI.Controls.MetroSetProgressBar metroSetProgressBar1;
        private MetroSet_UI.Controls.MetroSetProgressBar metroSetProgressBar3;
        private MetroSet_UI.Controls.MetroSetProgressBar metroSetProgressBar4;
        private MetroSet_UI.Controls.MetroSetLabel metroSetLabel14;
        private MetroSet_UI.Controls.MetroSetTrackBar metroSetTrackBar2;
        private MetroSet_UI.Controls.MetroSetTrackBar metroSetTrackBar1;
        private MetroSet_UI.Controls.MetroSetLabel metroSetLabel15;
        private MetroSet_UI.Controls.MetroSetLink metroSetLink2;
        private MetroSet_UI.Controls.MetroSetLink metroSetLink1;
        private MetroSet_UI.Controls.MetroSetLabel metroSetLabel17;
        private MetroSet_UI.Controls.MetroSetLabel metroSetLabel16;
        private MetroSet_UI.Controls.MetroDefaultSetButton metroSetButton6;
        private MetroSet_UI.Controls.MetroDefaultSetButton metroSetButton5;
        private MetroSet_UI.Controls.MetroDefaultSetButton metroSetButton4;
        private MetroSet_UI.Controls.MetroDefaultSetButton metroSetButton3;
        private MetroSet_UI.Controls.MetroSetLabel metroSetLabel18;
        private MetroSet_UI.Controls.MetroDefaultSetButton metroSetButton7;
        private MetroSet_UI.Controls.MetroSetSwitch metroSetSwitch4;
        private MetroSet_UI.Controls.MetroSetTextBox metroSetTextBox4;
        private MetroSet_UI.Controls.MetroSetButton metroSetButton2;
        private MetroSet_UI.Controls.MetroSetButton metroSetButton1;
        private MetroSet_UI.Controls.MetroSetLabel metroSetLabel19;
        private MetroSet_UI.Child.MetroSetTabPage metroSetTabPage1;
        private MetroSet_UI.Controls.MetroSetTile metroSetTile4;
        private MetroSet_UI.Controls.MetroSetTile metroSetTile2;
        private MetroSet_UI.Controls.MetroSetTile metroSetTile3;
        private MetroSet_UI.Controls.MetroSetTile metroSetTile1;
        private MetroSet_UI.Controls.MetroSetLabel metroSetLabel4;
        private MetroSet_UI.Controls.MetroSetTile metroSetTile8;
        private MetroSet_UI.Controls.MetroSetTile metroSetTile7;
        private MetroSet_UI.Controls.MetroSetTile metroSetTile6;
        private MetroSet_UI.Controls.MetroSetTile metroSetTile5;
        private MetroSet_UI.StyleManager styleManager1;
        private MetroSet_UI.Components.MetroSetToolTip metroSetToolTip1;
        private MetroSet_UI.Controls.MetroSetContextMenuStrip metroSetContextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem textBoxToolStripMenuItem;
    }
}