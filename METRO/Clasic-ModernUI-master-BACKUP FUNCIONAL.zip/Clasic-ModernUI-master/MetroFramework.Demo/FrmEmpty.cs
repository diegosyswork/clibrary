﻿using MetroFramework.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MetroFramework.Demo
{
    public partial class FrmEmpty : MetroForm
    {
        public FrmEmpty()
        {
            InitializeComponent();
        }
    }
}
