lambda-sql-builder
==================

A small independent library that will let you use standard C# and Linq to produce SQL queries
